<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-12 06:32:35 --> Config Class Initialized
INFO - 2020-02-12 06:32:35 --> Hooks Class Initialized
DEBUG - 2020-02-12 06:32:35 --> UTF-8 Support Enabled
INFO - 2020-02-12 06:32:35 --> Utf8 Class Initialized
INFO - 2020-02-12 06:32:35 --> URI Class Initialized
DEBUG - 2020-02-12 06:32:35 --> No URI present. Default controller set.
INFO - 2020-02-12 06:32:35 --> Router Class Initialized
INFO - 2020-02-12 06:32:35 --> Output Class Initialized
INFO - 2020-02-12 06:32:35 --> Security Class Initialized
DEBUG - 2020-02-12 06:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-12 06:32:35 --> Input Class Initialized
INFO - 2020-02-12 06:32:35 --> Language Class Initialized
INFO - 2020-02-12 06:32:35 --> Loader Class Initialized
INFO - 2020-02-12 06:32:35 --> Helper loaded: url_helper
INFO - 2020-02-12 06:32:35 --> Helper loaded: form_helper
INFO - 2020-02-12 06:32:35 --> Helper loaded: file_helper
INFO - 2020-02-12 06:32:35 --> Database Driver Class Initialized
ERROR - 2020-02-12 06:32:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'flegigs' C:\xampp\htdocs\Flegigs\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-02-12 06:32:36 --> Unable to connect to the database
INFO - 2020-02-12 06:32:36 --> Language file loaded: language/english/db_lang.php
