INFO - 2020-01-30 10:33:15 --> Config Class Initialized
INFO - 2020-01-30 10:33:15 --> Hooks Class Initialized
DEBUG - 2020-01-30 10:33:15 --> UTF-8 Support Enabled
INFO - 2020-01-30 10:33:15 --> Utf8 Class Initialized
INFO - 2020-01-30 10:33:15 --> URI Class Initialized
INFO - 2020-01-30 10:33:15 --> Router Class Initialized
INFO - 2020-01-30 10:33:15 --> Output Class Initialized
INFO - 2020-01-30 10:33:15 --> Security Class Initialized
DEBUG - 2020-01-30 10:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-30 10:33:15 --> Input Class Initialized
INFO - 2020-01-30 10:33:15 --> Language Class Initialized
INFO - 2020-01-30 10:33:15 --> Loader Class Initialized
INFO - 2020-01-30 10:33:15 --> Helper loaded: url_helper
INFO - 2020-01-30 10:33:15 --> Helper loaded: form_helper
INFO - 2020-01-30 10:33:15 --> Helper loaded: file_helper
INFO - 2020-01-30 10:33:15 --> Database Driver Class Initialized
DEBUG - 2020-01-30 10:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-30 10:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-30 10:33:15 --> Form Validation Class Initialized
INFO - 2020-01-30 10:33:15 --> Email Class Initialized
INFO - 2020-01-30 10:33:15 --> Controller Class Initialized
INFO - 2020-01-30 10:33:15 --> Model "Mainpagedata" initialized
DEBUG - 2020-01-30 10:33:15 --> __construct;, {"cache-control":"no-cache","Postman-Token":"5a1906e6-c085-44f8-9ba4-84c37399c3f2","Authorization":"Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMzEiLCJwcm9maWxlX2lkIjoiMiIsImVtYWlsIjoiamVsbGEua2luZy4xMDIzQGhvdG1haWwuY29tIn0.KWT9sutGa0ePGEcAG9MLgxvpZdctIBqluAmKF6OwR6E","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=u7u4vun44j11j091edp7ds51dk79hrn0","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------562395060014298374918109","content-length":"400","Connection":"keep-alive"}
DEBUG - 2020-01-30 10:33:15 --> customer_dashboard;, {"cache-control":"no-cache","Postman-Token":"5a1906e6-c085-44f8-9ba4-84c37399c3f2","Authorization":"Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMzEiLCJwcm9maWxlX2lkIjoiMiIsImVtYWlsIjoiamVsbGEua2luZy4xMDIzQGhvdG1haWwuY29tIn0.KWT9sutGa0ePGEcAG9MLgxvpZdctIBqluAmKF6OwR6E","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=u7u4vun44j11j091edp7ds51dk79hrn0","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------562395060014298374918109","content-length":"400","Connection":"keep-alive"}
ERROR - 2020-01-30 10:33:15 --> Severity: Notice --> Undefined index: token C:\xampp\htdocs\Flegigs\application\controllers\Webservice.php 140
DEBUG - 2020-01-30 10:33:15 --> customer_dashboard;, null
INFO - 2020-01-30 10:33:15 --> Final output sent to browser
DEBUG - 2020-01-30 10:33:15 --> Total execution time: 0.2179
INFO - 2020-01-30 10:34:49 --> Config Class Initialized
INFO - 2020-01-30 10:34:49 --> Hooks Class Initialized
DEBUG - 2020-01-30 10:34:49 --> UTF-8 Support Enabled
INFO - 2020-01-30 10:34:49 --> Utf8 Class Initialized
INFO - 2020-01-30 10:34:49 --> URI Class Initialized
INFO - 2020-01-30 10:34:49 --> Router Class Initialized
INFO - 2020-01-30 10:34:49 --> Output Class Initialized
INFO - 2020-01-30 10:34:49 --> Security Class Initialized
DEBUG - 2020-01-30 10:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-30 10:34:49 --> Input Class Initialized
INFO - 2020-01-30 10:34:49 --> Language Class Initialized
INFO - 2020-01-30 10:34:49 --> Loader Class Initialized
INFO - 2020-01-30 10:34:49 --> Helper loaded: url_helper
INFO - 2020-01-30 10:34:49 --> Helper loaded: form_helper
INFO - 2020-01-30 10:34:49 --> Helper loaded: file_helper
INFO - 2020-01-30 10:34:49 --> Database Driver Class Initialized
DEBUG - 2020-01-30 10:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-30 10:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-30 10:34:49 --> Form Validation Class Initialized
INFO - 2020-01-30 10:34:49 --> Email Class Initialized
INFO - 2020-01-30 10:34:49 --> Controller Class Initialized
INFO - 2020-01-30 10:34:49 --> Model "Mainpagedata" initialized
DEBUG - 2020-01-30 10:34:49 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMzEiLCJwcm9maWxlX2lkIjoiMiIsImVtYWlsIjoiamVsbGEua2luZy4xMDIzQGhvdG1haWwuY29tIn0.KWT9sutGa0ePGEcAG9MLgxvpZdctIBqluAmKF6OwR6E","cache-control":"no-cache","Postman-Token":"d82ddacf-435e-485b-a68e-6949c868291b","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=5jtnlrgk8r4273absrlhp1aqbctfrei4","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------863485733796184713241218","content-length":"400","Connection":"keep-alive"}
DEBUG - 2020-01-30 10:34:49 --> customer_dashboard;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMzEiLCJwcm9maWxlX2lkIjoiMiIsImVtYWlsIjoiamVsbGEua2luZy4xMDIzQGhvdG1haWwuY29tIn0.KWT9sutGa0ePGEcAG9MLgxvpZdctIBqluAmKF6OwR6E","cache-control":"no-cache","Postman-Token":"d82ddacf-435e-485b-a68e-6949c868291b","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=5jtnlrgk8r4273absrlhp1aqbctfrei4","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------863485733796184713241218","content-length":"400","Connection":"keep-alive"}
DEBUG - 2020-01-30 10:34:49 --> customer_dashboard;, "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMzEiLCJwcm9maWxlX2lkIjoiMiIsImVtYWlsIjoiamVsbGEua2luZy4xMDIzQGhvdG1haWwuY29tIn0.KWT9sutGa0ePGEcAG9MLgxvpZdctIBqluAmKF6OwR6E"
INFO - 2020-01-30 10:34:49 --> Final output sent to browser
DEBUG - 2020-01-30 10:34:49 --> Total execution time: 0.2339
INFO - 2020-01-30 16:10:51 --> Config Class Initialized
INFO - 2020-01-30 16:10:51 --> Hooks Class Initialized
DEBUG - 2020-01-30 16:10:51 --> UTF-8 Support Enabled
INFO - 2020-01-30 16:10:51 --> Utf8 Class Initialized
INFO - 2020-01-30 16:10:51 --> URI Class Initialized
INFO - 2020-01-30 16:10:51 --> Router Class Initialized
INFO - 2020-01-30 16:10:51 --> Output Class Initialized
INFO - 2020-01-30 16:10:51 --> Security Class Initialized
DEBUG - 2020-01-30 16:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-30 16:10:51 --> Input Class Initialized
INFO - 2020-01-30 16:10:51 --> Language Class Initialized
ERROR - 2020-01-30 16:10:51 --> 404 Page Not Found: Flegigs/Webservice
INFO - 2020-01-30 16:11:20 --> Config Class Initialized
INFO - 2020-01-30 16:11:20 --> Hooks Class Initialized
DEBUG - 2020-01-30 16:11:20 --> UTF-8 Support Enabled
INFO - 2020-01-30 16:11:20 --> Utf8 Class Initialized
INFO - 2020-01-30 16:11:20 --> URI Class Initialized
INFO - 2020-01-30 16:11:20 --> Router Class Initialized
INFO - 2020-01-30 16:11:20 --> Output Class Initialized
INFO - 2020-01-30 16:11:20 --> Security Class Initialized
DEBUG - 2020-01-30 16:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-30 16:11:20 --> Input Class Initialized
INFO - 2020-01-30 16:11:20 --> Language Class Initialized
INFO - 2020-01-30 16:11:21 --> Loader Class Initialized
INFO - 2020-01-30 16:11:21 --> Helper loaded: url_helper
INFO - 2020-01-30 16:11:21 --> Helper loaded: form_helper
INFO - 2020-01-30 16:11:21 --> Helper loaded: file_helper
INFO - 2020-01-30 16:11:21 --> Database Driver Class Initialized
DEBUG - 2020-01-30 16:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-30 16:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-30 16:11:22 --> Form Validation Class Initialized
INFO - 2020-01-30 16:11:22 --> Email Class Initialized
INFO - 2020-01-30 16:11:22 --> Controller Class Initialized
INFO - 2020-01-30 16:11:22 --> Model "Mainpagedata" initialized
DEBUG - 2020-01-30 16:11:22 --> __construct;, {"Token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMzEiLCJwcm9maWxlX2lkIjoiMiIsImVtYWlsIjoiamVsbGEua2luZy4xMDIzQGhvdG1haWwuY29tIn0.KWT9sutGa0ePGEcAG9MLgxvpZdctIBqluAmKF6OwR6E","cache-control":"no-cache","Postman-Token":"97725b57-d3c2-4969-999c-5fd8ac61cc47","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------623775688319401214712668","content-length":"406","Connection":"keep-alive"}
INFO - 2020-01-30 16:11:22 --> Final output sent to browser
DEBUG - 2020-01-30 16:11:22 --> Total execution time: 1.5966
INFO - 2020-01-30 16:12:06 --> Config Class Initialized
INFO - 2020-01-30 16:12:07 --> Hooks Class Initialized
DEBUG - 2020-01-30 16:12:07 --> UTF-8 Support Enabled
INFO - 2020-01-30 16:12:07 --> Utf8 Class Initialized
INFO - 2020-01-30 16:12:07 --> URI Class Initialized
INFO - 2020-01-30 16:12:07 --> Router Class Initialized
INFO - 2020-01-30 16:12:07 --> Output Class Initialized
INFO - 2020-01-30 16:12:07 --> Security Class Initialized
DEBUG - 2020-01-30 16:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-30 16:12:07 --> Input Class Initialized
INFO - 2020-01-30 16:12:07 --> Language Class Initialized
INFO - 2020-01-30 16:12:07 --> Loader Class Initialized
INFO - 2020-01-30 16:12:07 --> Helper loaded: url_helper
INFO - 2020-01-30 16:12:07 --> Helper loaded: form_helper
INFO - 2020-01-30 16:12:07 --> Helper loaded: file_helper
INFO - 2020-01-30 16:12:07 --> Database Driver Class Initialized
DEBUG - 2020-01-30 16:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-30 16:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-30 16:12:07 --> Form Validation Class Initialized
INFO - 2020-01-30 16:12:07 --> Email Class Initialized
INFO - 2020-01-30 16:12:07 --> Controller Class Initialized
INFO - 2020-01-30 16:12:07 --> Model "Mainpagedata" initialized
DEBUG - 2020-01-30 16:12:07 --> __construct;, {"Token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMyIsInByb2ZpbGVfaWQiOiIzIiwiZW1haWwiOiJ2aXZlay5tbGluZGlhQGdtYWlsLmNvbSJ9.vqCIzw-9Is74ZpoP6_LnOW-eiN_6MkIEJOvtTBtVaD0","cache-control":"no-cache","Postman-Token":"a9e55456-fffd-42c2-b229-f5c5989893c4","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=0qicq5e9a3fes3drgbdmi9caeg93bcac","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------631914780570839523865723","content-length":"512","Connection":"keep-alive"}
INFO - 2020-01-30 16:12:07 --> Final output sent to browser
DEBUG - 2020-01-30 16:12:07 --> Total execution time: 0.2255
INFO - 2020-01-30 17:38:52 --> Config Class Initialized
INFO - 2020-01-30 17:38:52 --> Hooks Class Initialized
DEBUG - 2020-01-30 17:38:52 --> UTF-8 Support Enabled
INFO - 2020-01-30 17:38:52 --> Utf8 Class Initialized
INFO - 2020-01-30 17:38:52 --> URI Class Initialized
INFO - 2020-01-30 17:38:52 --> Router Class Initialized
INFO - 2020-01-30 17:38:52 --> Output Class Initialized
INFO - 2020-01-30 17:38:52 --> Security Class Initialized
DEBUG - 2020-01-30 17:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-30 17:38:52 --> Input Class Initialized
INFO - 2020-01-30 17:38:52 --> Language Class Initialized
INFO - 2020-01-30 17:38:52 --> Loader Class Initialized
INFO - 2020-01-30 17:38:52 --> Helper loaded: url_helper
INFO - 2020-01-30 17:38:52 --> Helper loaded: form_helper
INFO - 2020-01-30 17:38:52 --> Helper loaded: file_helper
INFO - 2020-01-30 17:38:53 --> Database Driver Class Initialized
DEBUG - 2020-01-30 17:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-30 17:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-30 17:38:53 --> Form Validation Class Initialized
INFO - 2020-01-30 17:38:53 --> Email Class Initialized
INFO - 2020-01-30 17:38:53 --> Controller Class Initialized
INFO - 2020-01-30 17:38:53 --> Model "Mainpagedata" initialized
DEBUG - 2020-01-30 17:38:53 --> __construct;, {"Token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMyIsInByb2ZpbGVfaWQiOiIzIiwiZW1haWwiOiJ2aXZlay5tbGluZGlhQGdtYWlsLmNvbSJ9.vqCIzw-9Is74ZpoP6_LnOW-eiN_6MkIEJOvtTBtVaD0","cache-control":"no-cache","Postman-Token":"188a1981-0732-42e0-b1a6-f40ef9ed04fd","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=0qicq5e9a3fes3drgbdmi9caeg93bcac","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------932501753090427086318573","content-length":"512","Connection":"keep-alive"}
INFO - 2020-01-30 17:38:53 --> Final output sent to browser
DEBUG - 2020-01-30 17:38:53 --> Total execution time: 1.1026
INFO - 2020-01-30 17:39:00 --> Config Class Initialized
INFO - 2020-01-30 17:39:00 --> Hooks Class Initialized
DEBUG - 2020-01-30 17:39:00 --> UTF-8 Support Enabled
INFO - 2020-01-30 17:39:00 --> Utf8 Class Initialized
INFO - 2020-01-30 17:39:00 --> URI Class Initialized
INFO - 2020-01-30 17:39:00 --> Router Class Initialized
INFO - 2020-01-30 17:39:00 --> Output Class Initialized
INFO - 2020-01-30 17:39:00 --> Security Class Initialized
DEBUG - 2020-01-30 17:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-30 17:39:00 --> Input Class Initialized
INFO - 2020-01-30 17:39:00 --> Language Class Initialized
INFO - 2020-01-30 17:39:00 --> Loader Class Initialized
INFO - 2020-01-30 17:39:00 --> Helper loaded: url_helper
INFO - 2020-01-30 17:39:00 --> Helper loaded: form_helper
INFO - 2020-01-30 17:39:00 --> Helper loaded: file_helper
INFO - 2020-01-30 17:39:00 --> Database Driver Class Initialized
DEBUG - 2020-01-30 17:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-30 17:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-30 17:39:00 --> Form Validation Class Initialized
INFO - 2020-01-30 17:39:00 --> Email Class Initialized
INFO - 2020-01-30 17:39:00 --> Controller Class Initialized
INFO - 2020-01-30 17:39:00 --> Model "Mainpagedata" initialized
DEBUG - 2020-01-30 17:39:00 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMyIsInByb2ZpbGVfaWQiOiIzIiwiZW1haWwiOiJ2aXZlay5tbGluZGlhQGdtYWlsLmNvbSJ9.vqCIzw-9Is74ZpoP6_LnOW-eiN_6MkIEJOvtTBtVaD0","cache-control":"no-cache","Postman-Token":"8ff0d12d-11be-4ecf-b49b-c6377925b980","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=f2ec8tt07lpgbfg2bf6aav0a3qidgdbb","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------138446999540347576741332","content-length":"512","Connection":"keep-alive"}
INFO - 2020-01-30 17:39:02 --> Final output sent to browser
DEBUG - 2020-01-30 17:39:02 --> Total execution time: 1.5227
