<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-01-31 02:50:13 --> Config Class Initialized
INFO - 2020-01-31 02:50:13 --> Hooks Class Initialized
DEBUG - 2020-01-31 02:50:13 --> UTF-8 Support Enabled
INFO - 2020-01-31 02:50:13 --> Utf8 Class Initialized
INFO - 2020-01-31 02:50:13 --> URI Class Initialized
INFO - 2020-01-31 02:50:13 --> Router Class Initialized
INFO - 2020-01-31 02:50:13 --> Output Class Initialized
INFO - 2020-01-31 02:50:13 --> Security Class Initialized
DEBUG - 2020-01-31 02:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 02:50:13 --> Input Class Initialized
INFO - 2020-01-31 02:50:13 --> Language Class Initialized
INFO - 2020-01-31 02:50:15 --> Loader Class Initialized
INFO - 2020-01-31 02:50:15 --> Helper loaded: url_helper
INFO - 2020-01-31 02:50:15 --> Helper loaded: form_helper
INFO - 2020-01-31 02:50:15 --> Helper loaded: file_helper
INFO - 2020-01-31 02:50:15 --> Database Driver Class Initialized
DEBUG - 2020-01-31 02:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 02:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 02:50:15 --> Form Validation Class Initialized
INFO - 2020-01-31 02:50:15 --> Email Class Initialized
INFO - 2020-01-31 02:50:15 --> Controller Class Initialized
INFO - 2020-01-31 02:50:15 --> Model "Mainpagedata" initialized
DEBUG - 2020-01-31 02:50:15 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMyIsInByb2ZpbGVfaWQiOiIzIiwiZW1haWwiOiJ2aXZlay5tbGluZGlhQGdtYWlsLmNvbSJ9.vqCIzw-9Is74ZpoP6_LnOW-eiN_6MkIEJOvtTBtVaD0","cache-control":"no-cache","Postman-Token":"e51717a1-3d2f-4c89-8465-740deabdf0e6","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------323650445736196737735717","content-length":"512","Connection":"keep-alive"}
INFO - 2020-01-31 02:50:15 --> Final output sent to browser
DEBUG - 2020-01-31 02:50:15 --> Total execution time: 2.1512
INFO - 2020-01-31 02:51:55 --> Config Class Initialized
INFO - 2020-01-31 02:51:55 --> Hooks Class Initialized
DEBUG - 2020-01-31 02:51:55 --> UTF-8 Support Enabled
INFO - 2020-01-31 02:51:55 --> Utf8 Class Initialized
INFO - 2020-01-31 02:51:55 --> URI Class Initialized
INFO - 2020-01-31 02:51:55 --> Router Class Initialized
INFO - 2020-01-31 02:51:55 --> Output Class Initialized
INFO - 2020-01-31 02:51:55 --> Security Class Initialized
DEBUG - 2020-01-31 02:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 02:51:55 --> Input Class Initialized
INFO - 2020-01-31 02:51:55 --> Language Class Initialized
INFO - 2020-01-31 02:51:55 --> Loader Class Initialized
INFO - 2020-01-31 02:51:56 --> Helper loaded: url_helper
INFO - 2020-01-31 02:51:56 --> Helper loaded: form_helper
INFO - 2020-01-31 02:51:56 --> Helper loaded: file_helper
INFO - 2020-01-31 02:51:56 --> Database Driver Class Initialized
DEBUG - 2020-01-31 02:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 02:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 02:51:56 --> Form Validation Class Initialized
INFO - 2020-01-31 02:51:56 --> Email Class Initialized
INFO - 2020-01-31 02:51:56 --> Controller Class Initialized
INFO - 2020-01-31 02:51:56 --> Model "Mainpagedata" initialized
DEBUG - 2020-01-31 02:51:56 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMyIsInByb2ZpbGVfaWQiOiIzIiwiZW1haWwiOiJ2aXZlay5tbGluZGlhQGdtYWlsLmNvbSJ9.vqCIzw-9Is74ZpoP6_LnOW-eiN_6MkIEJOvtTBtVaD0","cache-control":"no-cache","Postman-Token":"3d81a421-46fc-4125-83ea-169bcfe84cff","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=81m11oh6c9v4q42j60p8aa2rqjirfq26","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------540016681703294595184095","content-length":"512","Connection":"keep-alive"}
INFO - 2020-01-31 02:51:56 --> Final output sent to browser
DEBUG - 2020-01-31 02:51:56 --> Total execution time: 0.2893
INFO - 2020-01-31 02:52:17 --> Config Class Initialized
INFO - 2020-01-31 02:52:17 --> Hooks Class Initialized
DEBUG - 2020-01-31 02:52:17 --> UTF-8 Support Enabled
INFO - 2020-01-31 02:52:17 --> Utf8 Class Initialized
INFO - 2020-01-31 02:52:17 --> URI Class Initialized
INFO - 2020-01-31 02:52:17 --> Router Class Initialized
INFO - 2020-01-31 02:52:17 --> Output Class Initialized
INFO - 2020-01-31 02:52:17 --> Security Class Initialized
DEBUG - 2020-01-31 02:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 02:52:17 --> Input Class Initialized
INFO - 2020-01-31 02:52:17 --> Language Class Initialized
INFO - 2020-01-31 02:52:17 --> Loader Class Initialized
INFO - 2020-01-31 02:52:17 --> Helper loaded: url_helper
INFO - 2020-01-31 02:52:17 --> Helper loaded: form_helper
INFO - 2020-01-31 02:52:17 --> Helper loaded: file_helper
INFO - 2020-01-31 02:52:17 --> Database Driver Class Initialized
DEBUG - 2020-01-31 02:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 02:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 02:52:17 --> Form Validation Class Initialized
INFO - 2020-01-31 02:52:17 --> Email Class Initialized
INFO - 2020-01-31 02:52:17 --> Controller Class Initialized
INFO - 2020-01-31 02:52:17 --> Model "Mainpagedata" initialized
DEBUG - 2020-01-31 02:52:17 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNCIsInByb2ZpbGVfaWQiOiIyIiwiZW1haWwiOiJ2aXZlay5zeXNhbGdvQGdtYWlsLmNvbSJ9.fSiNpWSVx8aPo3VwlFssHzupsqpShdYIY3eKUScRAWU","cache-control":"no-cache","Postman-Token":"927fd01a-9322-4301-ad50-25b595301e63","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=81m11oh6c9v4q42j60p8aa2rqjirfq26","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------602029929665988422037422","content-length":"512","Connection":"keep-alive"}
INFO - 2020-01-31 02:52:17 --> Final output sent to browser
DEBUG - 2020-01-31 02:52:17 --> Total execution time: 0.2601
INFO - 2020-01-31 02:53:35 --> Config Class Initialized
INFO - 2020-01-31 02:53:35 --> Hooks Class Initialized
DEBUG - 2020-01-31 02:53:35 --> UTF-8 Support Enabled
INFO - 2020-01-31 02:53:35 --> Utf8 Class Initialized
INFO - 2020-01-31 02:53:35 --> URI Class Initialized
INFO - 2020-01-31 02:53:35 --> Router Class Initialized
INFO - 2020-01-31 02:53:35 --> Output Class Initialized
INFO - 2020-01-31 02:53:35 --> Security Class Initialized
DEBUG - 2020-01-31 02:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 02:53:35 --> Input Class Initialized
INFO - 2020-01-31 02:53:35 --> Language Class Initialized
INFO - 2020-01-31 02:53:35 --> Loader Class Initialized
INFO - 2020-01-31 02:53:35 --> Helper loaded: url_helper
INFO - 2020-01-31 02:53:35 --> Helper loaded: form_helper
INFO - 2020-01-31 02:53:35 --> Helper loaded: file_helper
INFO - 2020-01-31 02:53:35 --> Database Driver Class Initialized
DEBUG - 2020-01-31 02:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 02:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 02:53:35 --> Form Validation Class Initialized
INFO - 2020-01-31 02:53:35 --> Email Class Initialized
INFO - 2020-01-31 02:53:35 --> Controller Class Initialized
INFO - 2020-01-31 02:53:35 --> Model "Mainpagedata" initialized
DEBUG - 2020-01-31 02:53:35 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNCIsInByb2ZpbGVfaWQiOiIyIiwiZW1haWwiOiJ2aXZlay5zeXNhbGdvQGdtYWlsLmNvbSJ9.fSiNpWSVx8aPo3VwlFssHzupsqpShdYIY3eKUScRAWU","cache-control":"no-cache","Postman-Token":"03b2867b-6cf9-4ce2-9039-2fbd749cecc7","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=81m11oh6c9v4q42j60p8aa2rqjirfq26","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------245046235985229346698356","content-length":"512","Connection":"keep-alive"}
INFO - 2020-01-31 02:53:35 --> Final output sent to browser
DEBUG - 2020-01-31 02:53:35 --> Total execution time: 0.2906
INFO - 2020-01-31 02:59:25 --> Config Class Initialized
INFO - 2020-01-31 02:59:25 --> Hooks Class Initialized
DEBUG - 2020-01-31 02:59:25 --> UTF-8 Support Enabled
INFO - 2020-01-31 02:59:25 --> Utf8 Class Initialized
INFO - 2020-01-31 02:59:25 --> URI Class Initialized
INFO - 2020-01-31 02:59:25 --> Router Class Initialized
INFO - 2020-01-31 02:59:25 --> Output Class Initialized
INFO - 2020-01-31 02:59:25 --> Security Class Initialized
DEBUG - 2020-01-31 02:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 02:59:25 --> Input Class Initialized
INFO - 2020-01-31 02:59:25 --> Language Class Initialized
INFO - 2020-01-31 02:59:25 --> Loader Class Initialized
INFO - 2020-01-31 02:59:25 --> Helper loaded: url_helper
INFO - 2020-01-31 02:59:25 --> Helper loaded: form_helper
INFO - 2020-01-31 02:59:25 --> Helper loaded: file_helper
INFO - 2020-01-31 02:59:25 --> Database Driver Class Initialized
DEBUG - 2020-01-31 02:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 02:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 02:59:25 --> Form Validation Class Initialized
INFO - 2020-01-31 02:59:25 --> Email Class Initialized
INFO - 2020-01-31 02:59:25 --> Controller Class Initialized
INFO - 2020-01-31 02:59:25 --> Model "Mainpagedata" initialized
DEBUG - 2020-01-31 02:59:25 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNCIsInByb2ZpbGVfaWQiOiIyIiwiZW1haWwiOiJ2aXZlay5zeXNhbGdvQGdtYWlsLmNvbSJ9.fSiNpWSVx8aPo3VwlFssHzupsqpShdYIY3eKUScRAWU","cache-control":"no-cache","Postman-Token":"f1300be3-19cf-4bce-a079-9cb1c089e0bc","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=81m11oh6c9v4q42j60p8aa2rqjirfq26","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------229865784295009968285243","content-length":"512","Connection":"keep-alive"}
INFO - 2020-01-31 02:59:25 --> Final output sent to browser
DEBUG - 2020-01-31 02:59:25 --> Total execution time: 0.2666
