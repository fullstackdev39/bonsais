<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-03-03 02:37:04 --> Config Class Initialized
INFO - 2020-03-03 02:37:04 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:37:04 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:37:04 --> Utf8 Class Initialized
INFO - 2020-03-03 02:37:04 --> URI Class Initialized
DEBUG - 2020-03-03 02:37:04 --> No URI present. Default controller set.
INFO - 2020-03-03 02:37:04 --> Router Class Initialized
INFO - 2020-03-03 02:37:04 --> Output Class Initialized
INFO - 2020-03-03 02:37:04 --> Security Class Initialized
DEBUG - 2020-03-03 02:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:37:04 --> Input Class Initialized
INFO - 2020-03-03 02:37:04 --> Language Class Initialized
INFO - 2020-03-03 02:37:04 --> Loader Class Initialized
INFO - 2020-03-03 02:37:04 --> Helper loaded: url_helper
INFO - 2020-03-03 02:37:04 --> Helper loaded: form_helper
INFO - 2020-03-03 02:37:04 --> Helper loaded: file_helper
INFO - 2020-03-03 02:37:04 --> Database Driver Class Initialized
DEBUG - 2020-03-03 02:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 02:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 02:37:04 --> Form Validation Class Initialized
INFO - 2020-03-03 02:37:05 --> Email Class Initialized
INFO - 2020-03-03 02:37:05 --> Controller Class Initialized
INFO - 2020-03-03 02:37:05 --> Model "Adminmodel" initialized
INFO - 2020-03-03 02:37:05 --> File loaded: C:\xampp\htdocs\Flegigs\application\views\login.php
INFO - 2020-03-03 02:37:05 --> Final output sent to browser
DEBUG - 2020-03-03 02:37:05 --> Total execution time: 0.6251
INFO - 2020-03-03 02:37:51 --> Config Class Initialized
INFO - 2020-03-03 02:37:51 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:37:51 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:37:51 --> Utf8 Class Initialized
INFO - 2020-03-03 02:37:51 --> URI Class Initialized
INFO - 2020-03-03 02:37:51 --> Router Class Initialized
INFO - 2020-03-03 02:37:51 --> Output Class Initialized
INFO - 2020-03-03 02:37:51 --> Security Class Initialized
DEBUG - 2020-03-03 02:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:37:51 --> Input Class Initialized
INFO - 2020-03-03 02:37:51 --> Language Class Initialized
INFO - 2020-03-03 02:37:51 --> Loader Class Initialized
INFO - 2020-03-03 02:37:51 --> Helper loaded: url_helper
INFO - 2020-03-03 02:37:51 --> Helper loaded: form_helper
INFO - 2020-03-03 02:37:51 --> Helper loaded: file_helper
INFO - 2020-03-03 02:37:51 --> Database Driver Class Initialized
DEBUG - 2020-03-03 02:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 02:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 02:37:51 --> Form Validation Class Initialized
INFO - 2020-03-03 02:37:51 --> Email Class Initialized
INFO - 2020-03-03 02:37:51 --> Controller Class Initialized
INFO - 2020-03-03 02:37:51 --> Model "Adminmodel" initialized
INFO - 2020-03-03 02:37:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-03-03 02:37:51 --> Config Class Initialized
INFO - 2020-03-03 02:37:51 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:37:51 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:37:51 --> Utf8 Class Initialized
INFO - 2020-03-03 02:37:51 --> URI Class Initialized
INFO - 2020-03-03 02:37:51 --> Router Class Initialized
INFO - 2020-03-03 02:37:51 --> Output Class Initialized
INFO - 2020-03-03 02:37:51 --> Security Class Initialized
DEBUG - 2020-03-03 02:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:37:51 --> Input Class Initialized
INFO - 2020-03-03 02:37:51 --> Language Class Initialized
INFO - 2020-03-03 02:37:51 --> Loader Class Initialized
INFO - 2020-03-03 02:37:51 --> Helper loaded: url_helper
INFO - 2020-03-03 02:37:51 --> Helper loaded: form_helper
INFO - 2020-03-03 02:37:51 --> Helper loaded: file_helper
INFO - 2020-03-03 02:37:51 --> Database Driver Class Initialized
DEBUG - 2020-03-03 02:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 02:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 02:37:51 --> Form Validation Class Initialized
INFO - 2020-03-03 02:37:51 --> Email Class Initialized
INFO - 2020-03-03 02:37:51 --> Controller Class Initialized
INFO - 2020-03-03 02:37:51 --> Model "Adminmodel" initialized
INFO - 2020-03-03 02:37:51 --> File loaded: C:\xampp\htdocs\Flegigs\application\views\incl/header.php
INFO - 2020-03-03 02:37:51 --> File loaded: C:\xampp\htdocs\Flegigs\application\views\incl/menu.php
INFO - 2020-03-03 02:37:51 --> File loaded: C:\xampp\htdocs\Flegigs\application\views\menu/user_manage.php
INFO - 2020-03-03 02:37:51 --> File loaded: C:\xampp\htdocs\Flegigs\application\views\incl/footer.php
INFO - 2020-03-03 02:37:51 --> Final output sent to browser
DEBUG - 2020-03-03 02:37:51 --> Total execution time: 0.3442
INFO - 2020-03-03 02:38:10 --> Config Class Initialized
INFO - 2020-03-03 02:38:10 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:38:10 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:38:10 --> Utf8 Class Initialized
INFO - 2020-03-03 02:38:10 --> URI Class Initialized
DEBUG - 2020-03-03 02:38:10 --> No URI present. Default controller set.
INFO - 2020-03-03 02:38:10 --> Router Class Initialized
INFO - 2020-03-03 02:38:10 --> Output Class Initialized
INFO - 2020-03-03 02:38:10 --> Security Class Initialized
DEBUG - 2020-03-03 02:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:38:10 --> Input Class Initialized
INFO - 2020-03-03 02:38:10 --> Language Class Initialized
INFO - 2020-03-03 02:38:10 --> Loader Class Initialized
INFO - 2020-03-03 02:38:10 --> Helper loaded: url_helper
INFO - 2020-03-03 02:38:10 --> Helper loaded: form_helper
INFO - 2020-03-03 02:38:11 --> Helper loaded: file_helper
INFO - 2020-03-03 02:38:11 --> Database Driver Class Initialized
DEBUG - 2020-03-03 02:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 02:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 02:38:11 --> Form Validation Class Initialized
INFO - 2020-03-03 02:38:11 --> Email Class Initialized
INFO - 2020-03-03 02:38:11 --> Controller Class Initialized
INFO - 2020-03-03 02:38:11 --> Model "Adminmodel" initialized
INFO - 2020-03-03 02:38:11 --> File loaded: C:\xampp\htdocs\Flegigs\application\views\login.php
INFO - 2020-03-03 02:38:11 --> Final output sent to browser
DEBUG - 2020-03-03 02:38:11 --> Total execution time: 0.2654
INFO - 2020-03-03 02:39:31 --> Config Class Initialized
INFO - 2020-03-03 02:39:31 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:39:31 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:39:31 --> Utf8 Class Initialized
INFO - 2020-03-03 02:39:31 --> URI Class Initialized
INFO - 2020-03-03 02:39:31 --> Router Class Initialized
INFO - 2020-03-03 02:39:31 --> Output Class Initialized
INFO - 2020-03-03 02:39:31 --> Security Class Initialized
DEBUG - 2020-03-03 02:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:39:31 --> Input Class Initialized
INFO - 2020-03-03 02:39:31 --> Language Class Initialized
INFO - 2020-03-03 02:39:32 --> Loader Class Initialized
INFO - 2020-03-03 02:39:32 --> Helper loaded: url_helper
INFO - 2020-03-03 02:39:32 --> Helper loaded: form_helper
INFO - 2020-03-03 02:39:32 --> Helper loaded: file_helper
INFO - 2020-03-03 02:39:32 --> Database Driver Class Initialized
DEBUG - 2020-03-03 02:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 02:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 02:39:32 --> Form Validation Class Initialized
INFO - 2020-03-03 02:39:32 --> Email Class Initialized
INFO - 2020-03-03 02:39:32 --> Controller Class Initialized
INFO - 2020-03-03 02:39:32 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 02:39:32 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMyIsInByb2ZpbGVfaWQiOiIzIiwiZW1haWwiOiJ2aXZlay5tbGluZGlhQGdtYWlsLmNvbSJ9.vqCIzw-9Is74ZpoP6_LnOW-eiN_6MkIEJOvtTBtVaD0","cache-control":"no-cache","Postman-Token":"604d7c55-aeba-403e-8a27-518578eab089","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------862391841982981935248938","content-length":"870","Connection":"keep-alive"}
INFO - 2020-03-03 02:39:33 --> Final output sent to browser
DEBUG - 2020-03-03 02:39:33 --> Total execution time: 1.4310
INFO - 2020-03-03 02:41:30 --> Config Class Initialized
INFO - 2020-03-03 02:41:30 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:41:30 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:41:30 --> Utf8 Class Initialized
INFO - 2020-03-03 02:41:30 --> URI Class Initialized
INFO - 2020-03-03 02:41:30 --> Router Class Initialized
INFO - 2020-03-03 02:41:30 --> Output Class Initialized
INFO - 2020-03-03 02:41:30 --> Security Class Initialized
DEBUG - 2020-03-03 02:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:41:30 --> Input Class Initialized
INFO - 2020-03-03 02:41:30 --> Language Class Initialized
INFO - 2020-03-03 02:41:30 --> Loader Class Initialized
INFO - 2020-03-03 02:41:30 --> Helper loaded: url_helper
INFO - 2020-03-03 02:41:30 --> Helper loaded: form_helper
INFO - 2020-03-03 02:41:30 --> Helper loaded: file_helper
INFO - 2020-03-03 02:41:30 --> Database Driver Class Initialized
DEBUG - 2020-03-03 02:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 02:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 02:41:30 --> Form Validation Class Initialized
INFO - 2020-03-03 02:41:30 --> Email Class Initialized
INFO - 2020-03-03 02:41:30 --> Controller Class Initialized
INFO - 2020-03-03 02:41:30 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 02:41:30 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMyIsInByb2ZpbGVfaWQiOiIzIiwiZW1haWwiOiJ2aXZlay5tbGluZGlhQGdtYWlsLmNvbSJ9.vqCIzw-9Is74ZpoP6_LnOW-eiN_6MkIEJOvtTBtVaD0","cache-control":"no-cache","Postman-Token":"7f18dc30-7279-49a2-9cb2-b37acb776eb3","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=82f4v7nf9l41v6uft6b2j1klohcuk2kr","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------254679728269557602526343","content-length":"870","Connection":"keep-alive"}
INFO - 2020-03-03 02:41:30 --> Final output sent to browser
DEBUG - 2020-03-03 02:41:30 --> Total execution time: 0.2500
INFO - 2020-03-03 02:43:14 --> Config Class Initialized
INFO - 2020-03-03 02:43:14 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:43:15 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:43:15 --> Utf8 Class Initialized
INFO - 2020-03-03 02:43:15 --> URI Class Initialized
INFO - 2020-03-03 02:43:15 --> Router Class Initialized
INFO - 2020-03-03 02:43:15 --> Output Class Initialized
INFO - 2020-03-03 02:43:15 --> Security Class Initialized
DEBUG - 2020-03-03 02:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:43:15 --> Input Class Initialized
INFO - 2020-03-03 02:43:15 --> Language Class Initialized
INFO - 2020-03-03 02:43:15 --> Loader Class Initialized
INFO - 2020-03-03 02:43:15 --> Helper loaded: url_helper
INFO - 2020-03-03 02:43:15 --> Helper loaded: form_helper
INFO - 2020-03-03 02:43:15 --> Helper loaded: file_helper
INFO - 2020-03-03 02:43:15 --> Database Driver Class Initialized
DEBUG - 2020-03-03 02:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 02:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 02:43:15 --> Form Validation Class Initialized
INFO - 2020-03-03 02:43:15 --> Email Class Initialized
INFO - 2020-03-03 02:43:15 --> Controller Class Initialized
INFO - 2020-03-03 02:43:15 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 02:43:15 --> __construct;, {"cache-control":"no-cache","Postman-Token":"6919819a-b64b-4ba3-b539-5460b6a23b33","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=82f4v7nf9l41v6uft6b2j1klohcuk2kr","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------844488936309089624039240","content-length":"870","Connection":"keep-alive"}
INFO - 2020-03-03 02:43:15 --> Final output sent to browser
DEBUG - 2020-03-03 02:43:15 --> Total execution time: 0.4031
INFO - 2020-03-03 02:43:42 --> Config Class Initialized
INFO - 2020-03-03 02:43:42 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:43:42 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:43:42 --> Utf8 Class Initialized
INFO - 2020-03-03 02:43:42 --> URI Class Initialized
INFO - 2020-03-03 02:43:42 --> Router Class Initialized
INFO - 2020-03-03 02:43:42 --> Output Class Initialized
INFO - 2020-03-03 02:43:42 --> Security Class Initialized
DEBUG - 2020-03-03 02:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:43:42 --> Input Class Initialized
INFO - 2020-03-03 02:43:42 --> Language Class Initialized
INFO - 2020-03-03 02:43:42 --> Loader Class Initialized
INFO - 2020-03-03 02:43:42 --> Helper loaded: url_helper
INFO - 2020-03-03 02:43:42 --> Helper loaded: form_helper
INFO - 2020-03-03 02:43:42 --> Helper loaded: file_helper
INFO - 2020-03-03 02:43:42 --> Database Driver Class Initialized
DEBUG - 2020-03-03 02:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 02:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 02:43:42 --> Form Validation Class Initialized
INFO - 2020-03-03 02:43:42 --> Email Class Initialized
INFO - 2020-03-03 02:43:42 --> Controller Class Initialized
INFO - 2020-03-03 02:43:43 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 02:43:43 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMyIsInByb2ZpbGVfaWQiOiIzIiwiZW1haWwiOiJ2aXZlay5tbGluZGlhQGdtYWlsLmNvbSJ9.vqCIzw-9Is74ZpoP6_LnOW-eiN_6MkIEJOvtTBtVaD0","cache-control":"no-cache","Postman-Token":"bf5ee451-e9bb-4938-9fa9-734cb70125be","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=82f4v7nf9l41v6uft6b2j1klohcuk2kr","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------352221814361082954626268","content-length":"870","Connection":"keep-alive"}
INFO - 2020-03-03 02:43:43 --> Final output sent to browser
DEBUG - 2020-03-03 02:43:43 --> Total execution time: 0.2678
INFO - 2020-03-03 02:44:39 --> Config Class Initialized
INFO - 2020-03-03 02:44:39 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:44:39 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:44:39 --> Utf8 Class Initialized
INFO - 2020-03-03 02:44:39 --> URI Class Initialized
INFO - 2020-03-03 02:44:39 --> Router Class Initialized
INFO - 2020-03-03 02:44:39 --> Output Class Initialized
INFO - 2020-03-03 02:44:39 --> Security Class Initialized
DEBUG - 2020-03-03 02:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:44:39 --> Input Class Initialized
INFO - 2020-03-03 02:44:39 --> Language Class Initialized
INFO - 2020-03-03 02:44:39 --> Loader Class Initialized
INFO - 2020-03-03 02:44:39 --> Helper loaded: url_helper
INFO - 2020-03-03 02:44:39 --> Helper loaded: form_helper
INFO - 2020-03-03 02:44:39 --> Helper loaded: file_helper
INFO - 2020-03-03 02:44:39 --> Database Driver Class Initialized
DEBUG - 2020-03-03 02:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 02:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 02:44:39 --> Form Validation Class Initialized
INFO - 2020-03-03 02:44:39 --> Email Class Initialized
INFO - 2020-03-03 02:44:39 --> Controller Class Initialized
INFO - 2020-03-03 02:44:39 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 02:44:39 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMyIsInByb2ZpbGVfaWQiOiIzIiwiZW1haWwiOiJ2aXZlay5tbGluZGlhQGdtYWlsLmNvbSJ9.vqCIzw-9Is74ZpoP6_LnOW-eiN_6MkIEJOvtTBtVaD0","cache-control":"no-cache","Postman-Token":"361e137e-049b-4169-ba3b-2f0f41c4e1f3","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=82f4v7nf9l41v6uft6b2j1klohcuk2kr","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------295117097628707493291622","content-length":"870","Connection":"keep-alive"}
INFO - 2020-03-03 02:44:39 --> Final output sent to browser
DEBUG - 2020-03-03 02:44:39 --> Total execution time: 0.2725
INFO - 2020-03-03 02:44:46 --> Config Class Initialized
INFO - 2020-03-03 02:44:46 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:44:46 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:44:46 --> Utf8 Class Initialized
INFO - 2020-03-03 02:44:46 --> URI Class Initialized
INFO - 2020-03-03 02:44:46 --> Router Class Initialized
INFO - 2020-03-03 02:44:46 --> Output Class Initialized
INFO - 2020-03-03 02:44:46 --> Security Class Initialized
DEBUG - 2020-03-03 02:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:44:46 --> Input Class Initialized
INFO - 2020-03-03 02:44:46 --> Language Class Initialized
INFO - 2020-03-03 02:44:46 --> Loader Class Initialized
INFO - 2020-03-03 02:44:46 --> Helper loaded: url_helper
INFO - 2020-03-03 02:44:46 --> Helper loaded: form_helper
INFO - 2020-03-03 02:44:46 --> Helper loaded: file_helper
INFO - 2020-03-03 02:44:46 --> Database Driver Class Initialized
DEBUG - 2020-03-03 02:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 02:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 02:44:46 --> Form Validation Class Initialized
INFO - 2020-03-03 02:44:46 --> Email Class Initialized
INFO - 2020-03-03 02:44:46 --> Controller Class Initialized
INFO - 2020-03-03 02:44:46 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 02:44:46 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMyIsInByb2ZpbGVfaWQiOiIzIiwiZW1haWwiOiJ2aXZlay5tbGluZGlhQGdtYWlsLmNvbSJ9.vqCIzw-9Is74ZpoP6_LnOW-eiN_6MkIEJOvtTBtVaD0","cache-control":"no-cache","Postman-Token":"e2e3162b-d173-4b14-9196-a9d702a7edd1","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=i929mmfn26rq8ob4o0e350nr8ugcrse5","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------239910199694093507293043","content-length":"870","Connection":"keep-alive"}
INFO - 2020-03-03 02:44:46 --> Final output sent to browser
DEBUG - 2020-03-03 02:44:46 --> Total execution time: 0.2576
INFO - 2020-03-03 02:44:53 --> Config Class Initialized
INFO - 2020-03-03 02:44:53 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:44:53 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:44:53 --> Utf8 Class Initialized
INFO - 2020-03-03 02:44:53 --> URI Class Initialized
INFO - 2020-03-03 02:44:53 --> Router Class Initialized
INFO - 2020-03-03 02:44:53 --> Output Class Initialized
INFO - 2020-03-03 02:44:53 --> Security Class Initialized
DEBUG - 2020-03-03 02:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:44:53 --> Input Class Initialized
INFO - 2020-03-03 02:44:53 --> Language Class Initialized
INFO - 2020-03-03 02:44:53 --> Loader Class Initialized
INFO - 2020-03-03 02:44:53 --> Helper loaded: url_helper
INFO - 2020-03-03 02:44:53 --> Helper loaded: form_helper
INFO - 2020-03-03 02:44:53 --> Helper loaded: file_helper
INFO - 2020-03-03 02:44:53 --> Database Driver Class Initialized
DEBUG - 2020-03-03 02:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 02:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 02:44:53 --> Form Validation Class Initialized
INFO - 2020-03-03 02:44:53 --> Email Class Initialized
INFO - 2020-03-03 02:44:53 --> Controller Class Initialized
INFO - 2020-03-03 02:44:53 --> Model "Mainpagedata" initialized
ERROR - 2020-03-03 02:44:53 --> Severity: Notice --> Undefined index: Token C:\xampp\htdocs\Flegigs\application\controllers\Webservice.php 21
DEBUG - 2020-03-03 02:44:53 --> __construct;, {"cache-control":"no-cache","Postman-Token":"247b14ef-1bfa-4067-ab67-e83f1cc30e6b","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=i929mmfn26rq8ob4o0e350nr8ugcrse5","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------091979859352091302099066","content-length":"870","Connection":"keep-alive","token":null}
INFO - 2020-03-03 02:44:53 --> Final output sent to browser
DEBUG - 2020-03-03 02:44:53 --> Total execution time: 0.3146
INFO - 2020-03-03 02:45:09 --> Config Class Initialized
INFO - 2020-03-03 02:45:09 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:45:09 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:45:09 --> Utf8 Class Initialized
INFO - 2020-03-03 02:45:09 --> URI Class Initialized
INFO - 2020-03-03 02:45:09 --> Router Class Initialized
INFO - 2020-03-03 02:45:09 --> Output Class Initialized
INFO - 2020-03-03 02:45:09 --> Security Class Initialized
DEBUG - 2020-03-03 02:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:45:09 --> Input Class Initialized
INFO - 2020-03-03 02:45:09 --> Language Class Initialized
INFO - 2020-03-03 02:45:09 --> Loader Class Initialized
INFO - 2020-03-03 02:45:09 --> Helper loaded: url_helper
INFO - 2020-03-03 02:45:09 --> Helper loaded: form_helper
INFO - 2020-03-03 02:45:09 --> Helper loaded: file_helper
INFO - 2020-03-03 02:45:09 --> Database Driver Class Initialized
DEBUG - 2020-03-03 02:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 02:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 02:45:09 --> Form Validation Class Initialized
INFO - 2020-03-03 02:45:09 --> Email Class Initialized
INFO - 2020-03-03 02:45:09 --> Controller Class Initialized
INFO - 2020-03-03 02:45:09 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 02:45:09 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMyIsInByb2ZpbGVfaWQiOiIzIiwiZW1haWwiOiJ2aXZlay5tbGluZGlhQGdtYWlsLmNvbSJ9.vqCIzw-9Is74ZpoP6_LnOW-eiN_6MkIEJOvtTBtVaD0","cache-control":"no-cache","Postman-Token":"07e05d1e-2291-41ad-9966-fe19a03e2722","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=i929mmfn26rq8ob4o0e350nr8ugcrse5","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------124550110503152433281084","content-length":"870","Connection":"keep-alive"}
INFO - 2020-03-03 02:45:09 --> Final output sent to browser
DEBUG - 2020-03-03 02:45:09 --> Total execution time: 0.2804
INFO - 2020-03-03 02:47:28 --> Config Class Initialized
INFO - 2020-03-03 02:47:28 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:47:28 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:47:28 --> Utf8 Class Initialized
INFO - 2020-03-03 02:47:28 --> URI Class Initialized
INFO - 2020-03-03 02:47:28 --> Router Class Initialized
INFO - 2020-03-03 02:47:28 --> Output Class Initialized
INFO - 2020-03-03 02:47:28 --> Security Class Initialized
DEBUG - 2020-03-03 02:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:47:28 --> Input Class Initialized
INFO - 2020-03-03 02:47:28 --> Language Class Initialized
INFO - 2020-03-03 02:47:28 --> Loader Class Initialized
INFO - 2020-03-03 02:47:28 --> Helper loaded: url_helper
INFO - 2020-03-03 02:47:28 --> Helper loaded: form_helper
INFO - 2020-03-03 02:47:28 --> Helper loaded: file_helper
INFO - 2020-03-03 02:47:28 --> Database Driver Class Initialized
DEBUG - 2020-03-03 02:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 02:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 02:47:28 --> Form Validation Class Initialized
INFO - 2020-03-03 02:47:28 --> Email Class Initialized
INFO - 2020-03-03 02:47:28 --> Controller Class Initialized
INFO - 2020-03-03 02:47:28 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 02:47:28 --> __construct;, {"cache-control":"no-cache","Postman-Token":"11af74d3-08a7-4719-9c16-e791d0b4fbef","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=i929mmfn26rq8ob4o0e350nr8ugcrse5","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------315997310995926020075345","content-length":"870","Connection":"keep-alive"}
INFO - 2020-03-03 02:47:28 --> Final output sent to browser
DEBUG - 2020-03-03 02:47:28 --> Total execution time: 0.2726
INFO - 2020-03-03 02:47:40 --> Config Class Initialized
INFO - 2020-03-03 02:47:40 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:47:40 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:47:40 --> Utf8 Class Initialized
INFO - 2020-03-03 02:47:40 --> URI Class Initialized
INFO - 2020-03-03 02:47:40 --> Router Class Initialized
INFO - 2020-03-03 02:47:41 --> Output Class Initialized
INFO - 2020-03-03 02:47:41 --> Security Class Initialized
DEBUG - 2020-03-03 02:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:47:41 --> Input Class Initialized
INFO - 2020-03-03 02:47:41 --> Language Class Initialized
INFO - 2020-03-03 02:47:41 --> Loader Class Initialized
INFO - 2020-03-03 02:47:41 --> Helper loaded: url_helper
INFO - 2020-03-03 02:47:41 --> Helper loaded: form_helper
INFO - 2020-03-03 02:47:41 --> Helper loaded: file_helper
INFO - 2020-03-03 02:47:41 --> Database Driver Class Initialized
DEBUG - 2020-03-03 02:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 02:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 02:47:41 --> Form Validation Class Initialized
INFO - 2020-03-03 02:47:41 --> Email Class Initialized
INFO - 2020-03-03 02:47:41 --> Controller Class Initialized
INFO - 2020-03-03 02:47:41 --> Model "Mainpagedata" initialized
ERROR - 2020-03-03 02:47:41 --> Severity: Notice --> Undefined index: Token C:\xampp\htdocs\Flegigs\application\controllers\Webservice.php 22
DEBUG - 2020-03-03 02:47:41 --> __construct;, {"cache-control":"no-cache","Postman-Token":"b1e0593b-d61d-48b2-a7fe-ea43d1b86b1a","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=i929mmfn26rq8ob4o0e350nr8ugcrse5","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------969386378914351732227445","content-length":"870","Connection":"keep-alive","token":null}
INFO - 2020-03-03 02:47:41 --> Final output sent to browser
DEBUG - 2020-03-03 02:47:41 --> Total execution time: 0.3018
INFO - 2020-03-03 02:47:49 --> Config Class Initialized
INFO - 2020-03-03 02:47:49 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:47:49 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:47:49 --> Utf8 Class Initialized
INFO - 2020-03-03 02:47:49 --> URI Class Initialized
INFO - 2020-03-03 02:47:49 --> Router Class Initialized
INFO - 2020-03-03 02:47:49 --> Output Class Initialized
INFO - 2020-03-03 02:47:49 --> Security Class Initialized
DEBUG - 2020-03-03 02:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:47:49 --> Input Class Initialized
INFO - 2020-03-03 02:47:49 --> Language Class Initialized
INFO - 2020-03-03 02:47:49 --> Loader Class Initialized
INFO - 2020-03-03 02:47:49 --> Helper loaded: url_helper
INFO - 2020-03-03 02:47:49 --> Helper loaded: form_helper
INFO - 2020-03-03 02:47:49 --> Helper loaded: file_helper
INFO - 2020-03-03 02:47:49 --> Database Driver Class Initialized
DEBUG - 2020-03-03 02:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 02:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 02:47:49 --> Form Validation Class Initialized
INFO - 2020-03-03 02:47:49 --> Email Class Initialized
INFO - 2020-03-03 02:47:49 --> Controller Class Initialized
INFO - 2020-03-03 02:47:49 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 02:47:49 --> __construct;, {"cache-control":"no-cache","Postman-Token":"7450901b-e186-460b-9c7d-9af18f0ac23e","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=i929mmfn26rq8ob4o0e350nr8ugcrse5","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------287427060801323073755242","content-length":"870","Connection":"keep-alive"}
INFO - 2020-03-03 02:47:49 --> Final output sent to browser
DEBUG - 2020-03-03 02:47:49 --> Total execution time: 0.2905
INFO - 2020-03-03 02:48:10 --> Config Class Initialized
INFO - 2020-03-03 02:48:10 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:48:10 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:48:10 --> Utf8 Class Initialized
INFO - 2020-03-03 02:48:10 --> URI Class Initialized
INFO - 2020-03-03 02:48:10 --> Router Class Initialized
INFO - 2020-03-03 02:48:10 --> Output Class Initialized
INFO - 2020-03-03 02:48:10 --> Security Class Initialized
DEBUG - 2020-03-03 02:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:48:10 --> Input Class Initialized
INFO - 2020-03-03 02:48:10 --> Language Class Initialized
INFO - 2020-03-03 02:48:10 --> Loader Class Initialized
INFO - 2020-03-03 02:48:10 --> Helper loaded: url_helper
INFO - 2020-03-03 02:48:10 --> Helper loaded: form_helper
INFO - 2020-03-03 02:48:10 --> Helper loaded: file_helper
INFO - 2020-03-03 02:48:10 --> Database Driver Class Initialized
DEBUG - 2020-03-03 02:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 02:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 02:48:10 --> Form Validation Class Initialized
INFO - 2020-03-03 02:48:10 --> Email Class Initialized
INFO - 2020-03-03 02:48:10 --> Controller Class Initialized
INFO - 2020-03-03 02:48:10 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 02:48:10 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMyIsInByb2ZpbGVfaWQiOiIzIiwiZW1haWwiOiJ2aXZlay5tbGluZGlhQGdtYWlsLmNvbSJ9.vqCIzw-9Is74ZpoP6_LnOW-eiN_6MkIEJOvtTBtVaD0","cache-control":"no-cache","Postman-Token":"f03b900c-13da-4cae-b051-c7b0853224fc","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=i929mmfn26rq8ob4o0e350nr8ugcrse5","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------258219757239136730272206","content-length":"870","Connection":"keep-alive"}
INFO - 2020-03-03 02:48:10 --> Final output sent to browser
DEBUG - 2020-03-03 02:48:10 --> Total execution time: 0.2734
INFO - 2020-03-03 02:49:25 --> Config Class Initialized
INFO - 2020-03-03 02:49:25 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:49:25 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:49:25 --> Utf8 Class Initialized
INFO - 2020-03-03 02:49:25 --> URI Class Initialized
INFO - 2020-03-03 02:49:25 --> Router Class Initialized
INFO - 2020-03-03 02:49:25 --> Output Class Initialized
INFO - 2020-03-03 02:49:25 --> Security Class Initialized
DEBUG - 2020-03-03 02:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:49:25 --> Input Class Initialized
INFO - 2020-03-03 02:49:25 --> Language Class Initialized
INFO - 2020-03-03 02:49:25 --> Loader Class Initialized
INFO - 2020-03-03 02:49:25 --> Helper loaded: url_helper
INFO - 2020-03-03 02:49:25 --> Helper loaded: form_helper
INFO - 2020-03-03 02:49:25 --> Helper loaded: file_helper
INFO - 2020-03-03 02:49:25 --> Database Driver Class Initialized
DEBUG - 2020-03-03 02:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 02:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 02:49:25 --> Form Validation Class Initialized
INFO - 2020-03-03 02:49:25 --> Email Class Initialized
INFO - 2020-03-03 02:49:25 --> Controller Class Initialized
INFO - 2020-03-03 02:49:25 --> Model "Mainpagedata" initialized
ERROR - 2020-03-03 02:49:25 --> Severity: Notice --> Undefined index: token C:\xampp\htdocs\Flegigs\application\controllers\Webservice.php 23
DEBUG - 2020-03-03 02:49:25 --> __construct;, {"cache-control":"no-cache","Postman-Token":"c15d0627-b66b-4980-bf8f-f790eea05a25","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=i929mmfn26rq8ob4o0e350nr8ugcrse5","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------619336592573474193473102","content-length":"870","Connection":"keep-alive","token":null}
INFO - 2020-03-03 02:49:25 --> Final output sent to browser
DEBUG - 2020-03-03 02:49:25 --> Total execution time: 0.2808
INFO - 2020-03-03 02:49:51 --> Config Class Initialized
INFO - 2020-03-03 02:49:51 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:49:51 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:49:51 --> Utf8 Class Initialized
INFO - 2020-03-03 02:49:51 --> URI Class Initialized
INFO - 2020-03-03 02:49:51 --> Router Class Initialized
INFO - 2020-03-03 02:49:51 --> Output Class Initialized
INFO - 2020-03-03 02:49:51 --> Security Class Initialized
DEBUG - 2020-03-03 02:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:49:51 --> Input Class Initialized
INFO - 2020-03-03 02:49:51 --> Language Class Initialized
INFO - 2020-03-03 02:49:51 --> Loader Class Initialized
INFO - 2020-03-03 02:49:51 --> Helper loaded: url_helper
INFO - 2020-03-03 02:49:51 --> Helper loaded: form_helper
INFO - 2020-03-03 02:49:51 --> Helper loaded: file_helper
INFO - 2020-03-03 02:49:51 --> Database Driver Class Initialized
DEBUG - 2020-03-03 02:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 02:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 02:49:51 --> Form Validation Class Initialized
INFO - 2020-03-03 02:49:51 --> Email Class Initialized
INFO - 2020-03-03 02:49:51 --> Controller Class Initialized
INFO - 2020-03-03 02:49:51 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 02:49:51 --> __construct;, {"cache-control":"no-cache","Postman-Token":"b0e58052-2434-4d76-87ef-a7a67376a0f1","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=i929mmfn26rq8ob4o0e350nr8ugcrse5","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------004162274313919373335129","content-length":"870","Connection":"keep-alive"}
INFO - 2020-03-03 02:49:51 --> Final output sent to browser
DEBUG - 2020-03-03 02:49:51 --> Total execution time: 0.2993
INFO - 2020-03-03 02:50:01 --> Config Class Initialized
INFO - 2020-03-03 02:50:01 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:50:01 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:50:01 --> Utf8 Class Initialized
INFO - 2020-03-03 02:50:01 --> URI Class Initialized
INFO - 2020-03-03 02:50:01 --> Router Class Initialized
INFO - 2020-03-03 02:50:01 --> Output Class Initialized
INFO - 2020-03-03 02:50:01 --> Security Class Initialized
DEBUG - 2020-03-03 02:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:50:01 --> Input Class Initialized
INFO - 2020-03-03 02:50:01 --> Language Class Initialized
INFO - 2020-03-03 02:50:01 --> Loader Class Initialized
INFO - 2020-03-03 02:50:01 --> Helper loaded: url_helper
INFO - 2020-03-03 02:50:01 --> Helper loaded: form_helper
INFO - 2020-03-03 02:50:01 --> Helper loaded: file_helper
INFO - 2020-03-03 02:50:01 --> Database Driver Class Initialized
DEBUG - 2020-03-03 02:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 02:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 02:50:01 --> Form Validation Class Initialized
INFO - 2020-03-03 02:50:01 --> Email Class Initialized
INFO - 2020-03-03 02:50:01 --> Controller Class Initialized
INFO - 2020-03-03 02:50:01 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 02:50:01 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMyIsInByb2ZpbGVfaWQiOiIzIiwiZW1haWwiOiJ2aXZlay5tbGluZGlhQGdtYWlsLmNvbSJ9.vqCIzw-9Is74ZpoP6_LnOW-eiN_6MkIEJOvtTBtVaD0","cache-control":"no-cache","Postman-Token":"5ffb1e1c-ca25-4467-99ab-e7a3a79e7f48","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=phcpgf4ca13go9f3siqoru2jthi3crk6","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------016608854819480123322178","content-length":"870","Connection":"keep-alive"}
INFO - 2020-03-03 02:50:01 --> Final output sent to browser
DEBUG - 2020-03-03 02:50:01 --> Total execution time: 0.2756
INFO - 2020-03-03 02:50:06 --> Config Class Initialized
INFO - 2020-03-03 02:50:06 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:50:06 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:50:06 --> Utf8 Class Initialized
INFO - 2020-03-03 02:50:06 --> URI Class Initialized
INFO - 2020-03-03 02:50:06 --> Router Class Initialized
INFO - 2020-03-03 02:50:06 --> Output Class Initialized
INFO - 2020-03-03 02:50:06 --> Security Class Initialized
DEBUG - 2020-03-03 02:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:50:06 --> Input Class Initialized
INFO - 2020-03-03 02:50:06 --> Language Class Initialized
INFO - 2020-03-03 02:50:06 --> Loader Class Initialized
INFO - 2020-03-03 02:50:06 --> Helper loaded: url_helper
INFO - 2020-03-03 02:50:06 --> Helper loaded: form_helper
INFO - 2020-03-03 02:50:06 --> Helper loaded: file_helper
INFO - 2020-03-03 02:50:06 --> Database Driver Class Initialized
DEBUG - 2020-03-03 02:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 02:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 02:50:06 --> Form Validation Class Initialized
INFO - 2020-03-03 02:50:06 --> Email Class Initialized
INFO - 2020-03-03 02:50:06 --> Controller Class Initialized
INFO - 2020-03-03 02:50:06 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 02:50:06 --> __construct;, {"Token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMyIsInByb2ZpbGVfaWQiOiIzIiwiZW1haWwiOiJ2aXZlay5tbGluZGlhQGdtYWlsLmNvbSJ9.vqCIzw-9Is74ZpoP6_LnOW-eiN_6MkIEJOvtTBtVaD0","cache-control":"no-cache","Postman-Token":"552a94bc-41d9-4542-8e92-615d3d28cecd","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=phcpgf4ca13go9f3siqoru2jthi3crk6","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------882878395187885125629993","content-length":"870","Connection":"keep-alive","token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMyIsInByb2ZpbGVfaWQiOiIzIiwiZW1haWwiOiJ2aXZlay5tbGluZGlhQGdtYWlsLmNvbSJ9.vqCIzw-9Is74ZpoP6_LnOW-eiN_6MkIEJOvtTBtVaD0"}
INFO - 2020-03-03 02:50:06 --> Final output sent to browser
DEBUG - 2020-03-03 02:50:06 --> Total execution time: 0.3063
INFO - 2020-03-03 02:51:56 --> Config Class Initialized
INFO - 2020-03-03 02:51:56 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:51:56 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:51:56 --> Utf8 Class Initialized
INFO - 2020-03-03 02:51:56 --> URI Class Initialized
INFO - 2020-03-03 02:51:56 --> Router Class Initialized
INFO - 2020-03-03 02:51:56 --> Output Class Initialized
INFO - 2020-03-03 02:51:56 --> Security Class Initialized
DEBUG - 2020-03-03 02:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:51:56 --> Input Class Initialized
INFO - 2020-03-03 02:51:56 --> Language Class Initialized
INFO - 2020-03-03 02:51:56 --> Loader Class Initialized
INFO - 2020-03-03 02:51:56 --> Helper loaded: url_helper
INFO - 2020-03-03 02:51:56 --> Helper loaded: form_helper
INFO - 2020-03-03 02:51:56 --> Helper loaded: file_helper
INFO - 2020-03-03 02:51:56 --> Database Driver Class Initialized
DEBUG - 2020-03-03 02:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 02:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 02:51:56 --> Form Validation Class Initialized
INFO - 2020-03-03 02:51:56 --> Email Class Initialized
INFO - 2020-03-03 02:51:56 --> Controller Class Initialized
INFO - 2020-03-03 02:51:56 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 02:51:56 --> __construct;, {"cache-control":"no-cache","Postman-Token":"b8e144d4-f3da-4599-bb87-4c1af30848ef","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=phcpgf4ca13go9f3siqoru2jthi3crk6","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------114314258912254616465370","content-length":"870","Connection":"keep-alive"}
INFO - 2020-03-03 02:51:56 --> Final output sent to browser
DEBUG - 2020-03-03 02:51:56 --> Total execution time: 0.3004
INFO - 2020-03-03 02:52:20 --> Config Class Initialized
INFO - 2020-03-03 02:52:20 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:52:20 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:52:20 --> Utf8 Class Initialized
INFO - 2020-03-03 02:52:20 --> URI Class Initialized
INFO - 2020-03-03 02:52:20 --> Router Class Initialized
INFO - 2020-03-03 02:52:20 --> Output Class Initialized
INFO - 2020-03-03 02:52:20 --> Security Class Initialized
DEBUG - 2020-03-03 02:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:52:20 --> Input Class Initialized
INFO - 2020-03-03 02:52:20 --> Language Class Initialized
INFO - 2020-03-03 02:52:20 --> Loader Class Initialized
INFO - 2020-03-03 02:52:20 --> Helper loaded: url_helper
INFO - 2020-03-03 02:52:20 --> Helper loaded: form_helper
INFO - 2020-03-03 02:52:20 --> Helper loaded: file_helper
INFO - 2020-03-03 02:52:20 --> Database Driver Class Initialized
DEBUG - 2020-03-03 02:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 02:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 02:52:20 --> Form Validation Class Initialized
INFO - 2020-03-03 02:52:20 --> Email Class Initialized
INFO - 2020-03-03 02:52:20 --> Controller Class Initialized
INFO - 2020-03-03 02:52:20 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 02:52:20 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMyIsInByb2ZpbGVfaWQiOiIzIiwiZW1haWwiOiJ2aXZlay5tbGluZGlhQGdtYWlsLmNvbSJ9.vqCIzw-9Is74ZpoP6_LnOW-eiN_6MkIEJOvtTBtVaD0","cache-control":"no-cache","Postman-Token":"7bc3c779-4c40-4665-82ed-57c897b71676","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=phcpgf4ca13go9f3siqoru2jthi3crk6","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------598715737686820673910139","content-length":"870","Connection":"keep-alive"}
INFO - 2020-03-03 02:52:20 --> Final output sent to browser
DEBUG - 2020-03-03 02:52:20 --> Total execution time: 0.2944
INFO - 2020-03-03 02:53:59 --> Config Class Initialized
INFO - 2020-03-03 02:53:59 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:53:59 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:53:59 --> Utf8 Class Initialized
INFO - 2020-03-03 02:53:59 --> URI Class Initialized
INFO - 2020-03-03 02:53:59 --> Router Class Initialized
INFO - 2020-03-03 02:53:59 --> Output Class Initialized
INFO - 2020-03-03 02:53:59 --> Security Class Initialized
DEBUG - 2020-03-03 02:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:53:59 --> Input Class Initialized
INFO - 2020-03-03 02:53:59 --> Language Class Initialized
ERROR - 2020-03-03 02:53:59 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF) C:\xampp\htdocs\Flegigs\application\controllers\Webservice.php 20
INFO - 2020-03-03 02:54:15 --> Config Class Initialized
INFO - 2020-03-03 02:54:15 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:54:16 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:54:16 --> Utf8 Class Initialized
INFO - 2020-03-03 02:54:16 --> URI Class Initialized
INFO - 2020-03-03 02:54:16 --> Router Class Initialized
INFO - 2020-03-03 02:54:16 --> Output Class Initialized
INFO - 2020-03-03 02:54:16 --> Security Class Initialized
DEBUG - 2020-03-03 02:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:54:16 --> Input Class Initialized
INFO - 2020-03-03 02:54:16 --> Language Class Initialized
INFO - 2020-03-03 02:54:16 --> Loader Class Initialized
INFO - 2020-03-03 02:54:16 --> Helper loaded: url_helper
INFO - 2020-03-03 02:54:16 --> Helper loaded: form_helper
INFO - 2020-03-03 02:54:16 --> Helper loaded: file_helper
INFO - 2020-03-03 02:54:16 --> Database Driver Class Initialized
DEBUG - 2020-03-03 02:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 02:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 02:54:16 --> Form Validation Class Initialized
INFO - 2020-03-03 02:54:16 --> Email Class Initialized
INFO - 2020-03-03 02:54:16 --> Controller Class Initialized
INFO - 2020-03-03 02:54:16 --> Model "Mainpagedata" initialized
ERROR - 2020-03-03 02:54:16 --> Severity: Notice --> Undefined index: token C:\xampp\htdocs\Flegigs\application\controllers\Webservice.php 24
DEBUG - 2020-03-03 02:54:16 --> __construct;, {"cache-control":"no-cache","Postman-Token":"58caef4d-84ff-4ae1-896d-7c13083d3e8b","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=phcpgf4ca13go9f3siqoru2jthi3crk6","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------885537030766762320215450","content-length":"870","Connection":"keep-alive","token":null}
INFO - 2020-03-03 02:54:16 --> Final output sent to browser
DEBUG - 2020-03-03 02:54:16 --> Total execution time: 0.3086
INFO - 2020-03-03 02:56:02 --> Config Class Initialized
INFO - 2020-03-03 02:56:02 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:56:02 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:56:02 --> Utf8 Class Initialized
INFO - 2020-03-03 02:56:02 --> URI Class Initialized
INFO - 2020-03-03 02:56:02 --> Router Class Initialized
INFO - 2020-03-03 02:56:02 --> Output Class Initialized
INFO - 2020-03-03 02:56:02 --> Security Class Initialized
DEBUG - 2020-03-03 02:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:56:02 --> Input Class Initialized
INFO - 2020-03-03 02:56:02 --> Language Class Initialized
INFO - 2020-03-03 02:56:02 --> Loader Class Initialized
INFO - 2020-03-03 02:56:02 --> Helper loaded: url_helper
INFO - 2020-03-03 02:56:02 --> Helper loaded: form_helper
INFO - 2020-03-03 02:56:02 --> Helper loaded: file_helper
INFO - 2020-03-03 02:56:02 --> Database Driver Class Initialized
DEBUG - 2020-03-03 02:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 02:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 02:56:02 --> Form Validation Class Initialized
INFO - 2020-03-03 02:56:02 --> Email Class Initialized
INFO - 2020-03-03 02:56:02 --> Controller Class Initialized
INFO - 2020-03-03 02:56:02 --> Model "Mainpagedata" initialized
ERROR - 2020-03-03 02:56:02 --> Severity: Notice --> Undefined index: token C:\xampp\htdocs\Flegigs\application\controllers\Webservice.php 23
DEBUG - 2020-03-03 02:56:02 --> __construct;, {"cache-control":"no-cache","Postman-Token":"3e04424a-3979-4fce-85ec-de362b401df7","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=phcpgf4ca13go9f3siqoru2jthi3crk6","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------571390692069394312656947","content-length":"870","Connection":"keep-alive","token":null}
INFO - 2020-03-03 02:56:02 --> Final output sent to browser
DEBUG - 2020-03-03 02:56:02 --> Total execution time: 0.3008
INFO - 2020-03-03 02:56:39 --> Config Class Initialized
INFO - 2020-03-03 02:56:39 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:56:39 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:56:39 --> Utf8 Class Initialized
INFO - 2020-03-03 02:56:39 --> URI Class Initialized
INFO - 2020-03-03 02:56:39 --> Router Class Initialized
INFO - 2020-03-03 02:56:39 --> Output Class Initialized
INFO - 2020-03-03 02:56:39 --> Security Class Initialized
DEBUG - 2020-03-03 02:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:56:39 --> Input Class Initialized
INFO - 2020-03-03 02:56:39 --> Language Class Initialized
INFO - 2020-03-03 02:56:39 --> Loader Class Initialized
INFO - 2020-03-03 02:56:39 --> Helper loaded: url_helper
INFO - 2020-03-03 02:56:39 --> Helper loaded: form_helper
INFO - 2020-03-03 02:56:39 --> Helper loaded: file_helper
INFO - 2020-03-03 02:56:39 --> Database Driver Class Initialized
DEBUG - 2020-03-03 02:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 02:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 02:56:40 --> Form Validation Class Initialized
INFO - 2020-03-03 02:56:40 --> Email Class Initialized
INFO - 2020-03-03 02:56:40 --> Controller Class Initialized
INFO - 2020-03-03 02:56:40 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 02:56:40 --> __construct;, {"cache-control":"no-cache","Postman-Token":"a723eb35-30fe-40be-b75c-c17bc9a1318c","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=f63bhgjsuken253202h8fdpn3vcff7gp","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------049030021118827328280675","content-length":"870","Connection":"keep-alive"}
INFO - 2020-03-03 02:56:40 --> Final output sent to browser
DEBUG - 2020-03-03 02:56:40 --> Total execution time: 0.3183
INFO - 2020-03-03 02:57:09 --> Config Class Initialized
INFO - 2020-03-03 02:57:09 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:57:09 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:57:09 --> Utf8 Class Initialized
INFO - 2020-03-03 02:57:09 --> URI Class Initialized
INFO - 2020-03-03 02:57:09 --> Router Class Initialized
INFO - 2020-03-03 02:57:09 --> Output Class Initialized
INFO - 2020-03-03 02:57:09 --> Security Class Initialized
DEBUG - 2020-03-03 02:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:57:09 --> Input Class Initialized
INFO - 2020-03-03 02:57:09 --> Language Class Initialized
INFO - 2020-03-03 02:57:09 --> Loader Class Initialized
INFO - 2020-03-03 02:57:09 --> Helper loaded: url_helper
INFO - 2020-03-03 02:57:09 --> Helper loaded: form_helper
INFO - 2020-03-03 02:57:09 --> Helper loaded: file_helper
INFO - 2020-03-03 02:57:09 --> Database Driver Class Initialized
DEBUG - 2020-03-03 02:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 02:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 02:57:09 --> Form Validation Class Initialized
INFO - 2020-03-03 02:57:09 --> Email Class Initialized
INFO - 2020-03-03 02:57:09 --> Controller Class Initialized
INFO - 2020-03-03 02:57:09 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 02:57:09 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMyIsInByb2ZpbGVfaWQiOiIzIiwiZW1haWwiOiJ2aXZlay5tbGluZGlhQGdtYWlsLmNvbSJ9.vqCIzw-9Is74ZpoP6_LnOW-eiN_6MkIEJOvtTBtVaD0","cache-control":"no-cache","Postman-Token":"046d77de-3c60-413f-acd4-70259ad5773e","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=f63bhgjsuken253202h8fdpn3vcff7gp","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------175622664090462464685552","content-length":"870","Connection":"keep-alive"}
INFO - 2020-03-03 02:57:09 --> Final output sent to browser
DEBUG - 2020-03-03 02:57:09 --> Total execution time: 0.2966
INFO - 2020-03-03 02:57:19 --> Config Class Initialized
INFO - 2020-03-03 02:57:19 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:57:19 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:57:19 --> Utf8 Class Initialized
INFO - 2020-03-03 02:57:19 --> URI Class Initialized
INFO - 2020-03-03 02:57:19 --> Router Class Initialized
INFO - 2020-03-03 02:57:19 --> Output Class Initialized
INFO - 2020-03-03 02:57:19 --> Security Class Initialized
DEBUG - 2020-03-03 02:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:57:19 --> Input Class Initialized
INFO - 2020-03-03 02:57:19 --> Language Class Initialized
INFO - 2020-03-03 02:57:19 --> Loader Class Initialized
INFO - 2020-03-03 02:57:19 --> Helper loaded: url_helper
INFO - 2020-03-03 02:57:19 --> Helper loaded: form_helper
INFO - 2020-03-03 02:57:19 --> Helper loaded: file_helper
INFO - 2020-03-03 02:57:19 --> Database Driver Class Initialized
DEBUG - 2020-03-03 02:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 02:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 02:57:19 --> Form Validation Class Initialized
INFO - 2020-03-03 02:57:19 --> Email Class Initialized
INFO - 2020-03-03 02:57:19 --> Controller Class Initialized
INFO - 2020-03-03 02:57:19 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 02:57:19 --> __construct;, {"Token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMyIsInByb2ZpbGVfaWQiOiIzIiwiZW1haWwiOiJ2aXZlay5tbGluZGlhQGdtYWlsLmNvbSJ9.vqCIzw-9Is74ZpoP6_LnOW-eiN_6MkIEJOvtTBtVaD0","cache-control":"no-cache","Postman-Token":"cb37b3a0-3c9b-4b67-894c-6876a95fb26d","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=f63bhgjsuken253202h8fdpn3vcff7gp","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------921305983346154298308057","content-length":"870","Connection":"keep-alive","token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMyIsInByb2ZpbGVfaWQiOiIzIiwiZW1haWwiOiJ2aXZlay5tbGluZGlhQGdtYWlsLmNvbSJ9.vqCIzw-9Is74ZpoP6_LnOW-eiN_6MkIEJOvtTBtVaD0"}
INFO - 2020-03-03 02:57:19 --> Final output sent to browser
DEBUG - 2020-03-03 02:57:19 --> Total execution time: 0.2932
INFO - 2020-03-03 02:57:45 --> Config Class Initialized
INFO - 2020-03-03 02:57:45 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:57:45 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:57:45 --> Utf8 Class Initialized
INFO - 2020-03-03 02:57:45 --> URI Class Initialized
INFO - 2020-03-03 02:57:45 --> Router Class Initialized
INFO - 2020-03-03 02:57:45 --> Output Class Initialized
INFO - 2020-03-03 02:57:45 --> Security Class Initialized
DEBUG - 2020-03-03 02:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:57:45 --> Input Class Initialized
INFO - 2020-03-03 02:57:45 --> Language Class Initialized
INFO - 2020-03-03 02:57:45 --> Loader Class Initialized
INFO - 2020-03-03 02:57:45 --> Helper loaded: url_helper
INFO - 2020-03-03 02:57:45 --> Helper loaded: form_helper
INFO - 2020-03-03 02:57:45 --> Helper loaded: file_helper
INFO - 2020-03-03 02:57:45 --> Database Driver Class Initialized
DEBUG - 2020-03-03 02:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 02:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 02:57:46 --> Form Validation Class Initialized
INFO - 2020-03-03 02:57:46 --> Email Class Initialized
INFO - 2020-03-03 02:57:46 --> Controller Class Initialized
INFO - 2020-03-03 02:57:46 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 02:57:46 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNCIsInByb2ZpbGVfaWQiOiIyIiwiZW1haWwiOiJ2aXZlay5zeXNhbGdvQGdtYWlsLmNvbSJ9.fSiNpWSVx8aPo3VwlFssHzupsqpShdYIY3eKUScRAWU","cache-control":"no-cache","Postman-Token":"d41bcd65-ab6e-4da5-90bd-8a8ee1452d5f","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=f63bhgjsuken253202h8fdpn3vcff7gp","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------804275044880841500541294","content-length":"512","Connection":"keep-alive"}
INFO - 2020-03-03 02:57:46 --> Final output sent to browser
DEBUG - 2020-03-03 02:57:46 --> Total execution time: 0.2845
INFO - 2020-03-03 02:58:02 --> Config Class Initialized
INFO - 2020-03-03 02:58:02 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:58:02 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:58:02 --> Utf8 Class Initialized
INFO - 2020-03-03 02:58:02 --> URI Class Initialized
INFO - 2020-03-03 02:58:02 --> Router Class Initialized
INFO - 2020-03-03 02:58:02 --> Output Class Initialized
INFO - 2020-03-03 02:58:02 --> Security Class Initialized
DEBUG - 2020-03-03 02:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:58:02 --> Input Class Initialized
INFO - 2020-03-03 02:58:02 --> Language Class Initialized
INFO - 2020-03-03 02:58:02 --> Loader Class Initialized
INFO - 2020-03-03 02:58:02 --> Helper loaded: url_helper
INFO - 2020-03-03 02:58:02 --> Helper loaded: form_helper
INFO - 2020-03-03 02:58:02 --> Helper loaded: file_helper
INFO - 2020-03-03 02:58:02 --> Database Driver Class Initialized
DEBUG - 2020-03-03 02:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 02:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 02:58:02 --> Form Validation Class Initialized
INFO - 2020-03-03 02:58:02 --> Email Class Initialized
INFO - 2020-03-03 02:58:02 --> Controller Class Initialized
INFO - 2020-03-03 02:58:02 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 02:58:02 --> __construct;, {"cache-control":"no-cache","Postman-Token":"78ad9e78-61b3-4cdd-b8fa-9e2044ac00dd","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=f63bhgjsuken253202h8fdpn3vcff7gp","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------929045566485115421968018","content-length":"512","Connection":"keep-alive"}
INFO - 2020-03-03 02:58:02 --> Final output sent to browser
DEBUG - 2020-03-03 02:58:02 --> Total execution time: 0.3213
INFO - 2020-03-03 02:58:08 --> Config Class Initialized
INFO - 2020-03-03 02:58:08 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:58:08 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:58:08 --> Utf8 Class Initialized
INFO - 2020-03-03 02:58:08 --> URI Class Initialized
INFO - 2020-03-03 02:58:08 --> Router Class Initialized
INFO - 2020-03-03 02:58:08 --> Output Class Initialized
INFO - 2020-03-03 02:58:08 --> Security Class Initialized
DEBUG - 2020-03-03 02:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:58:08 --> Input Class Initialized
INFO - 2020-03-03 02:58:08 --> Language Class Initialized
INFO - 2020-03-03 02:58:08 --> Loader Class Initialized
INFO - 2020-03-03 02:58:08 --> Helper loaded: url_helper
INFO - 2020-03-03 02:58:08 --> Helper loaded: form_helper
INFO - 2020-03-03 02:58:08 --> Helper loaded: file_helper
INFO - 2020-03-03 02:58:08 --> Database Driver Class Initialized
DEBUG - 2020-03-03 02:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 02:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 02:58:08 --> Form Validation Class Initialized
INFO - 2020-03-03 02:58:08 --> Email Class Initialized
INFO - 2020-03-03 02:58:08 --> Controller Class Initialized
INFO - 2020-03-03 02:58:08 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 02:58:08 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNCIsInByb2ZpbGVfaWQiOiIyIiwiZW1haWwiOiJ2aXZlay5zeXNhbGdvQGdtYWlsLmNvbSJ9.fSiNpWSVx8aPo3VwlFssHzupsqpShdYIY3eKUScRAWU","cache-control":"no-cache","Postman-Token":"9f606e4c-d2e7-4f35-b610-b39ec2defe33","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=f63bhgjsuken253202h8fdpn3vcff7gp","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------273673394230112615729695","content-length":"512","Connection":"keep-alive"}
INFO - 2020-03-03 02:58:08 --> Final output sent to browser
DEBUG - 2020-03-03 02:58:08 --> Total execution time: 0.2795
INFO - 2020-03-03 02:58:13 --> Config Class Initialized
INFO - 2020-03-03 02:58:13 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:58:13 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:58:13 --> Utf8 Class Initialized
INFO - 2020-03-03 02:58:13 --> URI Class Initialized
INFO - 2020-03-03 02:58:13 --> Router Class Initialized
INFO - 2020-03-03 02:58:13 --> Output Class Initialized
INFO - 2020-03-03 02:58:13 --> Security Class Initialized
DEBUG - 2020-03-03 02:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:58:13 --> Input Class Initialized
INFO - 2020-03-03 02:58:13 --> Language Class Initialized
INFO - 2020-03-03 02:58:13 --> Loader Class Initialized
INFO - 2020-03-03 02:58:13 --> Helper loaded: url_helper
INFO - 2020-03-03 02:58:13 --> Helper loaded: form_helper
INFO - 2020-03-03 02:58:13 --> Helper loaded: file_helper
INFO - 2020-03-03 02:58:13 --> Database Driver Class Initialized
DEBUG - 2020-03-03 02:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 02:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 02:58:13 --> Form Validation Class Initialized
INFO - 2020-03-03 02:58:13 --> Email Class Initialized
INFO - 2020-03-03 02:58:13 --> Controller Class Initialized
INFO - 2020-03-03 02:58:13 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 02:58:13 --> __construct;, {"Token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNCIsInByb2ZpbGVfaWQiOiIyIiwiZW1haWwiOiJ2aXZlay5zeXNhbGdvQGdtYWlsLmNvbSJ9.fSiNpWSVx8aPo3VwlFssHzupsqpShdYIY3eKUScRAWU","cache-control":"no-cache","Postman-Token":"0d275bc3-e3ba-4ea0-8b80-140e9ba57bce","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=f63bhgjsuken253202h8fdpn3vcff7gp","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------007589908429802309264941","content-length":"512","Connection":"keep-alive","token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNCIsInByb2ZpbGVfaWQiOiIyIiwiZW1haWwiOiJ2aXZlay5zeXNhbGdvQGdtYWlsLmNvbSJ9.fSiNpWSVx8aPo3VwlFssHzupsqpShdYIY3eKUScRAWU"}
INFO - 2020-03-03 02:58:13 --> Final output sent to browser
DEBUG - 2020-03-03 02:58:13 --> Total execution time: 0.3183
INFO - 2020-03-03 02:58:21 --> Config Class Initialized
INFO - 2020-03-03 02:58:22 --> Hooks Class Initialized
DEBUG - 2020-03-03 02:58:22 --> UTF-8 Support Enabled
INFO - 2020-03-03 02:58:22 --> Utf8 Class Initialized
INFO - 2020-03-03 02:58:22 --> URI Class Initialized
INFO - 2020-03-03 02:58:22 --> Router Class Initialized
INFO - 2020-03-03 02:58:22 --> Output Class Initialized
INFO - 2020-03-03 02:58:22 --> Security Class Initialized
DEBUG - 2020-03-03 02:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 02:58:22 --> Input Class Initialized
INFO - 2020-03-03 02:58:22 --> Language Class Initialized
INFO - 2020-03-03 02:58:22 --> Loader Class Initialized
INFO - 2020-03-03 02:58:22 --> Helper loaded: url_helper
INFO - 2020-03-03 02:58:22 --> Helper loaded: form_helper
INFO - 2020-03-03 02:58:22 --> Helper loaded: file_helper
INFO - 2020-03-03 02:58:22 --> Database Driver Class Initialized
DEBUG - 2020-03-03 02:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 02:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 02:58:22 --> Form Validation Class Initialized
INFO - 2020-03-03 02:58:22 --> Email Class Initialized
INFO - 2020-03-03 02:58:22 --> Controller Class Initialized
INFO - 2020-03-03 02:58:22 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 02:58:22 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNCIsInByb2ZpbGVfaWQiOiIyIiwiZW1haWwiOiJ2aXZlay5zeXNhbGdvQGdtYWlsLmNvbSJ9.fSiNpWSVx8aPo3VwlFssHzupsqpShdYIY3eKUScRAWU","cache-control":"no-cache","Postman-Token":"ca4396c0-5e27-48c1-af4b-81799739d64c","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=f63bhgjsuken253202h8fdpn3vcff7gp","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------158553078660528418245388","content-length":"512","Connection":"keep-alive"}
INFO - 2020-03-03 02:58:22 --> Final output sent to browser
DEBUG - 2020-03-03 02:58:22 --> Total execution time: 0.3156
INFO - 2020-03-03 03:03:18 --> Config Class Initialized
INFO - 2020-03-03 03:03:18 --> Hooks Class Initialized
DEBUG - 2020-03-03 03:03:18 --> UTF-8 Support Enabled
INFO - 2020-03-03 03:03:18 --> Utf8 Class Initialized
INFO - 2020-03-03 03:03:18 --> URI Class Initialized
INFO - 2020-03-03 03:03:18 --> Router Class Initialized
INFO - 2020-03-03 03:03:18 --> Output Class Initialized
INFO - 2020-03-03 03:03:18 --> Security Class Initialized
DEBUG - 2020-03-03 03:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 03:03:19 --> Input Class Initialized
INFO - 2020-03-03 03:03:19 --> Language Class Initialized
INFO - 2020-03-03 03:03:19 --> Loader Class Initialized
INFO - 2020-03-03 03:03:19 --> Helper loaded: url_helper
INFO - 2020-03-03 03:03:19 --> Helper loaded: form_helper
INFO - 2020-03-03 03:03:19 --> Helper loaded: file_helper
INFO - 2020-03-03 03:03:19 --> Database Driver Class Initialized
DEBUG - 2020-03-03 03:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 03:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 03:03:19 --> Form Validation Class Initialized
INFO - 2020-03-03 03:03:19 --> Email Class Initialized
INFO - 2020-03-03 03:03:19 --> Controller Class Initialized
INFO - 2020-03-03 03:03:19 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 03:03:19 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNCIsInByb2ZpbGVfaWQiOiIyIiwiZW1haWwiOiJ2aXZlay5zeXNhbGdvQGdtYWlsLmNvbSJ9.fSiNpWSVx8aPo3VwlFssHzupsqpShdYIY3eKUScRAWU","cache-control":"no-cache","Postman-Token":"2b5a2373-498c-499f-89fe-81576226af59","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=f63bhgjsuken253202h8fdpn3vcff7gp","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------838059307313156329210152","content-length":"512","Connection":"keep-alive"}
INFO - 2020-03-03 03:03:19 --> Final output sent to browser
DEBUG - 2020-03-03 03:03:19 --> Total execution time: 0.3277
INFO - 2020-03-03 03:03:58 --> Config Class Initialized
INFO - 2020-03-03 03:03:58 --> Hooks Class Initialized
DEBUG - 2020-03-03 03:03:58 --> UTF-8 Support Enabled
INFO - 2020-03-03 03:03:58 --> Utf8 Class Initialized
INFO - 2020-03-03 03:03:58 --> URI Class Initialized
INFO - 2020-03-03 03:03:58 --> Router Class Initialized
INFO - 2020-03-03 03:03:58 --> Output Class Initialized
INFO - 2020-03-03 03:03:58 --> Security Class Initialized
DEBUG - 2020-03-03 03:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 03:03:58 --> Input Class Initialized
INFO - 2020-03-03 03:03:58 --> Language Class Initialized
INFO - 2020-03-03 03:03:58 --> Loader Class Initialized
INFO - 2020-03-03 03:03:58 --> Helper loaded: url_helper
INFO - 2020-03-03 03:03:58 --> Helper loaded: form_helper
INFO - 2020-03-03 03:03:58 --> Helper loaded: file_helper
INFO - 2020-03-03 03:03:58 --> Database Driver Class Initialized
DEBUG - 2020-03-03 03:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 03:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 03:03:58 --> Form Validation Class Initialized
INFO - 2020-03-03 03:03:58 --> Email Class Initialized
INFO - 2020-03-03 03:03:58 --> Controller Class Initialized
INFO - 2020-03-03 03:03:58 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 03:03:58 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNCIsInByb2ZpbGVfaWQiOiIyIiwiZW1haWwiOiJ2aXZlay5zeXNhbGdvQGdtYWlsLmNvbSJ9.fSiNpWSVx8aPo3VwlFssHzupsqpShdYIY3eKUScRAWU","cache-control":"no-cache","Postman-Token":"8aab1839-f844-4451-ba29-51b6cfeec686","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=0qf5o7m9sshidehb6665rjml0qcrhi2o","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------089807726486426016052188","content-length":"512","Connection":"keep-alive"}
INFO - 2020-03-03 03:03:58 --> Final output sent to browser
DEBUG - 2020-03-03 03:03:58 --> Total execution time: 0.2900
INFO - 2020-03-03 03:04:04 --> Config Class Initialized
INFO - 2020-03-03 03:04:04 --> Hooks Class Initialized
DEBUG - 2020-03-03 03:04:04 --> UTF-8 Support Enabled
INFO - 2020-03-03 03:04:04 --> Utf8 Class Initialized
INFO - 2020-03-03 03:04:04 --> URI Class Initialized
INFO - 2020-03-03 03:04:04 --> Router Class Initialized
INFO - 2020-03-03 03:04:04 --> Output Class Initialized
INFO - 2020-03-03 03:04:04 --> Security Class Initialized
DEBUG - 2020-03-03 03:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 03:04:04 --> Input Class Initialized
INFO - 2020-03-03 03:04:04 --> Language Class Initialized
INFO - 2020-03-03 03:04:04 --> Loader Class Initialized
INFO - 2020-03-03 03:04:04 --> Helper loaded: url_helper
INFO - 2020-03-03 03:04:04 --> Helper loaded: form_helper
INFO - 2020-03-03 03:04:04 --> Helper loaded: file_helper
INFO - 2020-03-03 03:04:04 --> Database Driver Class Initialized
DEBUG - 2020-03-03 03:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 03:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 03:04:04 --> Form Validation Class Initialized
INFO - 2020-03-03 03:04:04 --> Email Class Initialized
INFO - 2020-03-03 03:04:04 --> Controller Class Initialized
INFO - 2020-03-03 03:04:04 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 03:04:04 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNCIsInByb2ZpbGVfaWQiOiIyIiwiZW1haWwiOiJ2aXZlay5zeXNhbGdvQGdtYWlsLmNvbSJ9.fSiNpWSVx8aPo3VwlFssHzupsqpShdYIY3eKUScRAWU","cache-control":"no-cache","Postman-Token":"274d9e15-998e-44d0-be56-e75fc252c927","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=0qf5o7m9sshidehb6665rjml0qcrhi2o","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------693528756300057659811434","content-length":"512","Connection":"keep-alive"}
INFO - 2020-03-03 03:04:04 --> Final output sent to browser
DEBUG - 2020-03-03 03:04:04 --> Total execution time: 0.3174
INFO - 2020-03-03 03:04:11 --> Config Class Initialized
INFO - 2020-03-03 03:04:11 --> Hooks Class Initialized
DEBUG - 2020-03-03 03:04:11 --> UTF-8 Support Enabled
INFO - 2020-03-03 03:04:11 --> Utf8 Class Initialized
INFO - 2020-03-03 03:04:11 --> URI Class Initialized
INFO - 2020-03-03 03:04:11 --> Router Class Initialized
INFO - 2020-03-03 03:04:11 --> Output Class Initialized
INFO - 2020-03-03 03:04:11 --> Security Class Initialized
DEBUG - 2020-03-03 03:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 03:04:11 --> Input Class Initialized
INFO - 2020-03-03 03:04:11 --> Language Class Initialized
INFO - 2020-03-03 03:04:11 --> Loader Class Initialized
INFO - 2020-03-03 03:04:11 --> Helper loaded: url_helper
INFO - 2020-03-03 03:04:11 --> Helper loaded: form_helper
INFO - 2020-03-03 03:04:11 --> Helper loaded: file_helper
INFO - 2020-03-03 03:04:11 --> Database Driver Class Initialized
DEBUG - 2020-03-03 03:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 03:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 03:04:11 --> Form Validation Class Initialized
INFO - 2020-03-03 03:04:11 --> Email Class Initialized
INFO - 2020-03-03 03:04:11 --> Controller Class Initialized
INFO - 2020-03-03 03:04:11 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 03:04:11 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNCIsInByb2ZpbGVfaWQiOiIyIiwiZW1haWwiOiJ2aXZlay5zeXNhbGdvQGdtYWlsLmNvbSJ9.fSiNpWSVx8aPo3VwlFssHzupsqpShdYIY3eKUScRAWU","cache-control":"no-cache","Postman-Token":"6606af64-d3f3-487c-93db-6d73e4085a4a","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=0qf5o7m9sshidehb6665rjml0qcrhi2o","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------088945673312608794890121","content-length":"512","Connection":"keep-alive"}
INFO - 2020-03-03 03:04:11 --> Final output sent to browser
DEBUG - 2020-03-03 03:04:11 --> Total execution time: 0.3151
INFO - 2020-03-03 03:04:20 --> Config Class Initialized
INFO - 2020-03-03 03:04:20 --> Hooks Class Initialized
DEBUG - 2020-03-03 03:04:20 --> UTF-8 Support Enabled
INFO - 2020-03-03 03:04:20 --> Utf8 Class Initialized
INFO - 2020-03-03 03:04:20 --> URI Class Initialized
INFO - 2020-03-03 03:04:20 --> Router Class Initialized
INFO - 2020-03-03 03:04:20 --> Output Class Initialized
INFO - 2020-03-03 03:04:20 --> Security Class Initialized
DEBUG - 2020-03-03 03:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 03:04:20 --> Input Class Initialized
INFO - 2020-03-03 03:04:20 --> Language Class Initialized
INFO - 2020-03-03 03:04:20 --> Loader Class Initialized
INFO - 2020-03-03 03:04:20 --> Helper loaded: url_helper
INFO - 2020-03-03 03:04:20 --> Helper loaded: form_helper
INFO - 2020-03-03 03:04:20 --> Helper loaded: file_helper
INFO - 2020-03-03 03:04:20 --> Database Driver Class Initialized
DEBUG - 2020-03-03 03:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 03:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 03:04:20 --> Form Validation Class Initialized
INFO - 2020-03-03 03:04:20 --> Email Class Initialized
INFO - 2020-03-03 03:04:20 --> Controller Class Initialized
INFO - 2020-03-03 03:04:20 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 03:04:20 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNCIsInByb2ZpbGVfaWQiOiIyIiwiZW1haWwiOiJ2aXZlay5zeXNhbGdvQGdtYWlsLmNvbSJ9.fSiNpWSVx8aPo3VwlFssHzupsqpShdYIY3eKUScRAWU","cache-control":"no-cache","Postman-Token":"39b4e93d-df83-4a49-8f58-4c65140de9b7","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=0qf5o7m9sshidehb6665rjml0qcrhi2o","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------423051899608121422641361","content-length":"512","Connection":"keep-alive"}
INFO - 2020-03-03 03:04:20 --> Final output sent to browser
DEBUG - 2020-03-03 03:04:20 --> Total execution time: 0.3182
INFO - 2020-03-03 03:04:42 --> Config Class Initialized
INFO - 2020-03-03 03:04:42 --> Hooks Class Initialized
DEBUG - 2020-03-03 03:04:42 --> UTF-8 Support Enabled
INFO - 2020-03-03 03:04:42 --> Utf8 Class Initialized
INFO - 2020-03-03 03:04:42 --> URI Class Initialized
INFO - 2020-03-03 03:04:42 --> Router Class Initialized
INFO - 2020-03-03 03:04:42 --> Output Class Initialized
INFO - 2020-03-03 03:04:42 --> Security Class Initialized
DEBUG - 2020-03-03 03:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 03:04:42 --> Input Class Initialized
INFO - 2020-03-03 03:04:42 --> Language Class Initialized
INFO - 2020-03-03 03:04:42 --> Loader Class Initialized
INFO - 2020-03-03 03:04:42 --> Helper loaded: url_helper
INFO - 2020-03-03 03:04:42 --> Helper loaded: form_helper
INFO - 2020-03-03 03:04:42 --> Helper loaded: file_helper
INFO - 2020-03-03 03:04:42 --> Database Driver Class Initialized
DEBUG - 2020-03-03 03:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 03:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 03:04:42 --> Form Validation Class Initialized
INFO - 2020-03-03 03:04:42 --> Email Class Initialized
INFO - 2020-03-03 03:04:42 --> Controller Class Initialized
INFO - 2020-03-03 03:04:42 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 03:04:42 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNCIsInByb2ZpbGVfaWQiOiIyIiwiZW1haWwiOiJ2aXZlay5zeXNhbGdvQGdtYWlsLmNvbSJ9.fSiNpWSVx8aPo3VwlFssHzupsqpShdYIY3eKUScRAWU","cache-control":"no-cache","Postman-Token":"2856a7dd-8e52-4dc1-b143-66cc2a2e1c5d","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=0qf5o7m9sshidehb6665rjml0qcrhi2o","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------544621137588930465599222","content-length":"512","Connection":"keep-alive"}
INFO - 2020-03-03 03:04:43 --> Final output sent to browser
DEBUG - 2020-03-03 03:04:43 --> Total execution time: 0.2872
INFO - 2020-03-03 03:05:02 --> Config Class Initialized
INFO - 2020-03-03 03:05:02 --> Hooks Class Initialized
DEBUG - 2020-03-03 03:05:02 --> UTF-8 Support Enabled
INFO - 2020-03-03 03:05:02 --> Utf8 Class Initialized
INFO - 2020-03-03 03:05:02 --> URI Class Initialized
INFO - 2020-03-03 03:05:02 --> Router Class Initialized
INFO - 2020-03-03 03:05:02 --> Output Class Initialized
INFO - 2020-03-03 03:05:02 --> Security Class Initialized
DEBUG - 2020-03-03 03:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 03:05:03 --> Input Class Initialized
INFO - 2020-03-03 03:05:03 --> Language Class Initialized
INFO - 2020-03-03 03:05:03 --> Loader Class Initialized
INFO - 2020-03-03 03:05:03 --> Helper loaded: url_helper
INFO - 2020-03-03 03:05:03 --> Helper loaded: form_helper
INFO - 2020-03-03 03:05:03 --> Helper loaded: file_helper
INFO - 2020-03-03 03:05:03 --> Database Driver Class Initialized
DEBUG - 2020-03-03 03:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 03:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 03:05:03 --> Form Validation Class Initialized
INFO - 2020-03-03 03:05:03 --> Email Class Initialized
INFO - 2020-03-03 03:05:03 --> Controller Class Initialized
INFO - 2020-03-03 03:05:03 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 03:05:03 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNCIsInByb2ZpbGVfaWQiOiIyIiwiZW1haWwiOiJ2aXZlay5zeXNhbGdvQGdtYWlsLmNvbSJ9.fSiNpWSVx8aPo3VwlFssHzupsqpShdYIY3eKUScRAWU","cache-control":"no-cache","Postman-Token":"758fc8c1-bbf3-4e2b-9f2c-8d5e6ff417b7","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=0qf5o7m9sshidehb6665rjml0qcrhi2o","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------572069612343868989125961","content-length":"512","Connection":"keep-alive"}
INFO - 2020-03-03 03:05:03 --> Final output sent to browser
DEBUG - 2020-03-03 03:05:03 --> Total execution time: 0.2856
INFO - 2020-03-03 03:05:45 --> Config Class Initialized
INFO - 2020-03-03 03:05:45 --> Hooks Class Initialized
DEBUG - 2020-03-03 03:05:45 --> UTF-8 Support Enabled
INFO - 2020-03-03 03:05:45 --> Utf8 Class Initialized
INFO - 2020-03-03 03:05:45 --> URI Class Initialized
INFO - 2020-03-03 03:05:45 --> Router Class Initialized
INFO - 2020-03-03 03:05:45 --> Output Class Initialized
INFO - 2020-03-03 03:05:45 --> Security Class Initialized
DEBUG - 2020-03-03 03:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 03:05:46 --> Input Class Initialized
INFO - 2020-03-03 03:05:46 --> Language Class Initialized
INFO - 2020-03-03 03:05:46 --> Loader Class Initialized
INFO - 2020-03-03 03:05:46 --> Helper loaded: url_helper
INFO - 2020-03-03 03:05:46 --> Helper loaded: form_helper
INFO - 2020-03-03 03:05:46 --> Helper loaded: file_helper
INFO - 2020-03-03 03:05:46 --> Database Driver Class Initialized
DEBUG - 2020-03-03 03:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 03:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 03:05:46 --> Form Validation Class Initialized
INFO - 2020-03-03 03:05:46 --> Email Class Initialized
INFO - 2020-03-03 03:05:46 --> Controller Class Initialized
INFO - 2020-03-03 03:05:46 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 03:05:46 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNCIsInByb2ZpbGVfaWQiOiIyIiwiZW1haWwiOiJ2aXZlay5zeXNhbGdvQGdtYWlsLmNvbSJ9.fSiNpWSVx8aPo3VwlFssHzupsqpShdYIY3eKUScRAWU","cache-control":"no-cache","Postman-Token":"afb6523b-c021-4b7f-937b-aa182ac79576","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=0qf5o7m9sshidehb6665rjml0qcrhi2o","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------703043801810473044340839","content-length":"512","Connection":"keep-alive"}
INFO - 2020-03-03 03:05:46 --> Final output sent to browser
DEBUG - 2020-03-03 03:05:46 --> Total execution time: 0.2907
INFO - 2020-03-03 03:06:53 --> Config Class Initialized
INFO - 2020-03-03 03:06:53 --> Hooks Class Initialized
DEBUG - 2020-03-03 03:06:53 --> UTF-8 Support Enabled
INFO - 2020-03-03 03:06:53 --> Utf8 Class Initialized
INFO - 2020-03-03 03:06:53 --> URI Class Initialized
INFO - 2020-03-03 03:06:53 --> Router Class Initialized
INFO - 2020-03-03 03:06:53 --> Output Class Initialized
INFO - 2020-03-03 03:06:53 --> Security Class Initialized
DEBUG - 2020-03-03 03:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 03:06:53 --> Input Class Initialized
INFO - 2020-03-03 03:06:53 --> Language Class Initialized
INFO - 2020-03-03 03:06:53 --> Loader Class Initialized
INFO - 2020-03-03 03:06:53 --> Helper loaded: url_helper
INFO - 2020-03-03 03:06:53 --> Helper loaded: form_helper
INFO - 2020-03-03 03:06:53 --> Helper loaded: file_helper
INFO - 2020-03-03 03:06:54 --> Database Driver Class Initialized
DEBUG - 2020-03-03 03:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 03:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 03:06:54 --> Form Validation Class Initialized
INFO - 2020-03-03 03:06:54 --> Email Class Initialized
INFO - 2020-03-03 03:06:54 --> Controller Class Initialized
INFO - 2020-03-03 03:06:54 --> Model "Adminmodel" initialized
INFO - 2020-03-03 03:06:54 --> File loaded: C:\xampp\htdocs\Flegigs\application\views\incl/header.php
INFO - 2020-03-03 03:06:54 --> File loaded: C:\xampp\htdocs\Flegigs\application\views\incl/menu.php
INFO - 2020-03-03 03:06:54 --> File loaded: C:\xampp\htdocs\Flegigs\application\views\menu/user_manage.php
INFO - 2020-03-03 03:06:54 --> File loaded: C:\xampp\htdocs\Flegigs\application\views\incl/footer.php
INFO - 2020-03-03 03:06:54 --> Final output sent to browser
DEBUG - 2020-03-03 03:06:54 --> Total execution time: 0.3298
INFO - 2020-03-03 03:08:14 --> Config Class Initialized
INFO - 2020-03-03 03:08:14 --> Hooks Class Initialized
DEBUG - 2020-03-03 03:08:14 --> UTF-8 Support Enabled
INFO - 2020-03-03 03:08:14 --> Utf8 Class Initialized
INFO - 2020-03-03 03:08:14 --> URI Class Initialized
INFO - 2020-03-03 03:08:14 --> Router Class Initialized
INFO - 2020-03-03 03:08:14 --> Output Class Initialized
INFO - 2020-03-03 03:08:14 --> Security Class Initialized
DEBUG - 2020-03-03 03:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 03:08:14 --> Input Class Initialized
INFO - 2020-03-03 03:08:14 --> Language Class Initialized
INFO - 2020-03-03 03:08:14 --> Loader Class Initialized
INFO - 2020-03-03 03:08:14 --> Helper loaded: url_helper
INFO - 2020-03-03 03:08:14 --> Helper loaded: form_helper
INFO - 2020-03-03 03:08:14 --> Helper loaded: file_helper
INFO - 2020-03-03 03:08:14 --> Database Driver Class Initialized
DEBUG - 2020-03-03 03:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 03:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 03:08:14 --> Form Validation Class Initialized
INFO - 2020-03-03 03:08:14 --> Email Class Initialized
INFO - 2020-03-03 03:08:14 --> Controller Class Initialized
INFO - 2020-03-03 03:08:14 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 03:08:14 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNCIsInByb2ZpbGVfaWQiOiIyIiwiZW1haWwiOiJ2aXZlay5zeXNhbGdvQGdtYWlsLmNvbSJ9.fSiNpWSVx8aPo3VwlFssHzupsqpShdYIY3eKUScRAWU","cache-control":"no-cache","Postman-Token":"4564bd78-56cc-4a0e-9f04-d2fd9ebc4e8d","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=0qf5o7m9sshidehb6665rjml0qcrhi2o","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------533836514547713149681549","content-length":"512","Connection":"keep-alive"}
INFO - 2020-03-03 03:08:14 --> Final output sent to browser
DEBUG - 2020-03-03 03:08:14 --> Total execution time: 0.2950
INFO - 2020-03-03 03:08:28 --> Config Class Initialized
INFO - 2020-03-03 03:08:28 --> Hooks Class Initialized
DEBUG - 2020-03-03 03:08:28 --> UTF-8 Support Enabled
INFO - 2020-03-03 03:08:28 --> Utf8 Class Initialized
INFO - 2020-03-03 03:08:28 --> URI Class Initialized
INFO - 2020-03-03 03:08:28 --> Router Class Initialized
INFO - 2020-03-03 03:08:28 --> Output Class Initialized
INFO - 2020-03-03 03:08:28 --> Security Class Initialized
DEBUG - 2020-03-03 03:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 03:08:28 --> Input Class Initialized
INFO - 2020-03-03 03:08:28 --> Language Class Initialized
INFO - 2020-03-03 03:08:28 --> Loader Class Initialized
INFO - 2020-03-03 03:08:28 --> Helper loaded: url_helper
INFO - 2020-03-03 03:08:28 --> Helper loaded: form_helper
INFO - 2020-03-03 03:08:28 --> Helper loaded: file_helper
INFO - 2020-03-03 03:08:28 --> Database Driver Class Initialized
DEBUG - 2020-03-03 03:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 03:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 03:08:28 --> Form Validation Class Initialized
INFO - 2020-03-03 03:08:28 --> Email Class Initialized
INFO - 2020-03-03 03:08:28 --> Controller Class Initialized
INFO - 2020-03-03 03:08:28 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 03:08:28 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNCIsInByb2ZpbGVfaWQiOiIyIiwiZW1haWwiOiJ2aXZlay5zeXNhbGdvQGdtYWlsLmNvbSJ9.fSiNpWSVx8aPo3VwlFssHzupsqpShdYIY3eKUScRAWU","cache-control":"no-cache","Postman-Token":"ff77a397-fa2c-4086-a89f-763b9add92e6","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=0qf5o7m9sshidehb6665rjml0qcrhi2o","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------541854192201459569433635","content-length":"512","Connection":"keep-alive"}
INFO - 2020-03-03 03:08:28 --> Final output sent to browser
DEBUG - 2020-03-03 03:08:28 --> Total execution time: 0.3187
INFO - 2020-03-03 03:08:36 --> Config Class Initialized
INFO - 2020-03-03 03:08:36 --> Hooks Class Initialized
DEBUG - 2020-03-03 03:08:36 --> UTF-8 Support Enabled
INFO - 2020-03-03 03:08:36 --> Utf8 Class Initialized
INFO - 2020-03-03 03:08:36 --> URI Class Initialized
INFO - 2020-03-03 03:08:36 --> Router Class Initialized
INFO - 2020-03-03 03:08:36 --> Output Class Initialized
INFO - 2020-03-03 03:08:36 --> Security Class Initialized
DEBUG - 2020-03-03 03:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 03:08:36 --> Input Class Initialized
INFO - 2020-03-03 03:08:36 --> Language Class Initialized
INFO - 2020-03-03 03:08:36 --> Loader Class Initialized
INFO - 2020-03-03 03:08:36 --> Helper loaded: url_helper
INFO - 2020-03-03 03:08:36 --> Helper loaded: form_helper
INFO - 2020-03-03 03:08:36 --> Helper loaded: file_helper
INFO - 2020-03-03 03:08:36 --> Database Driver Class Initialized
DEBUG - 2020-03-03 03:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 03:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 03:08:36 --> Form Validation Class Initialized
INFO - 2020-03-03 03:08:36 --> Email Class Initialized
INFO - 2020-03-03 03:08:36 --> Controller Class Initialized
INFO - 2020-03-03 03:08:36 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 03:08:36 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNCIsInByb2ZpbGVfaWQiOiIyIiwiZW1haWwiOiJ2aXZlay5zeXNhbGdvQGdtYWlsLmNvbSJ9.fSiNpWSVx8aPo3VwlFssHzupsqpShdYIY3eKUScRAWU","cache-control":"no-cache","Postman-Token":"7382f248-1f36-4f6a-bfdf-d4dedd01fb81","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=adg5oo601uojjafn2060qaip4de5jee0","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------142689445272233031913031","content-length":"512","Connection":"keep-alive"}
INFO - 2020-03-03 03:08:36 --> Final output sent to browser
DEBUG - 2020-03-03 03:08:36 --> Total execution time: 0.3035
INFO - 2020-03-03 03:08:57 --> Config Class Initialized
INFO - 2020-03-03 03:08:57 --> Hooks Class Initialized
DEBUG - 2020-03-03 03:08:57 --> UTF-8 Support Enabled
INFO - 2020-03-03 03:08:57 --> Utf8 Class Initialized
INFO - 2020-03-03 03:08:57 --> URI Class Initialized
INFO - 2020-03-03 03:08:57 --> Router Class Initialized
INFO - 2020-03-03 03:08:57 --> Output Class Initialized
INFO - 2020-03-03 03:08:57 --> Security Class Initialized
DEBUG - 2020-03-03 03:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 03:08:57 --> Input Class Initialized
INFO - 2020-03-03 03:08:57 --> Language Class Initialized
INFO - 2020-03-03 03:08:57 --> Loader Class Initialized
INFO - 2020-03-03 03:08:57 --> Helper loaded: url_helper
INFO - 2020-03-03 03:08:57 --> Helper loaded: form_helper
INFO - 2020-03-03 03:08:57 --> Helper loaded: file_helper
INFO - 2020-03-03 03:08:57 --> Database Driver Class Initialized
DEBUG - 2020-03-03 03:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 03:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 03:08:57 --> Form Validation Class Initialized
INFO - 2020-03-03 03:08:57 --> Email Class Initialized
INFO - 2020-03-03 03:08:57 --> Controller Class Initialized
INFO - 2020-03-03 03:08:57 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 03:08:57 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNCIsInByb2ZpbGVfaWQiOiIyIiwiZW1haWwiOiJ2aXZlay5zeXNhbGdvQGdtYWlsLmNvbSJ9.fSiNpWSVx8aPo3VwlFssHzupsqpShdYIY3eKUScRAWU","cache-control":"no-cache","Postman-Token":"7a9c5da0-9acc-4ab2-93a4-6ab504dec4ce","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=adg5oo601uojjafn2060qaip4de5jee0","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------948388742701997171677773","content-length":"512","Connection":"keep-alive"}
INFO - 2020-03-03 03:08:57 --> Final output sent to browser
DEBUG - 2020-03-03 03:08:57 --> Total execution time: 0.3182
INFO - 2020-03-03 03:09:10 --> Config Class Initialized
INFO - 2020-03-03 03:09:10 --> Hooks Class Initialized
DEBUG - 2020-03-03 03:09:10 --> UTF-8 Support Enabled
INFO - 2020-03-03 03:09:10 --> Utf8 Class Initialized
INFO - 2020-03-03 03:09:10 --> URI Class Initialized
INFO - 2020-03-03 03:09:10 --> Router Class Initialized
INFO - 2020-03-03 03:09:10 --> Output Class Initialized
INFO - 2020-03-03 03:09:10 --> Security Class Initialized
DEBUG - 2020-03-03 03:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 03:09:10 --> Input Class Initialized
INFO - 2020-03-03 03:09:10 --> Language Class Initialized
INFO - 2020-03-03 03:09:10 --> Loader Class Initialized
INFO - 2020-03-03 03:09:10 --> Helper loaded: url_helper
INFO - 2020-03-03 03:09:10 --> Helper loaded: form_helper
INFO - 2020-03-03 03:09:10 --> Helper loaded: file_helper
INFO - 2020-03-03 03:09:10 --> Database Driver Class Initialized
DEBUG - 2020-03-03 03:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 03:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 03:09:10 --> Form Validation Class Initialized
INFO - 2020-03-03 03:09:10 --> Email Class Initialized
INFO - 2020-03-03 03:09:10 --> Controller Class Initialized
INFO - 2020-03-03 03:09:10 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 03:09:10 --> __construct;, {"cache-control":"no-cache","Postman-Token":"eeb32c46-ccbd-4864-82fe-af4e8dc9b7be","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=adg5oo601uojjafn2060qaip4de5jee0","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------743487670628362250855096","content-length":"512","Connection":"keep-alive"}
INFO - 2020-03-03 03:09:10 --> Final output sent to browser
DEBUG - 2020-03-03 03:09:10 --> Total execution time: 0.3132
INFO - 2020-03-03 03:09:24 --> Config Class Initialized
INFO - 2020-03-03 03:09:24 --> Hooks Class Initialized
DEBUG - 2020-03-03 03:09:24 --> UTF-8 Support Enabled
INFO - 2020-03-03 03:09:24 --> Utf8 Class Initialized
INFO - 2020-03-03 03:09:24 --> URI Class Initialized
INFO - 2020-03-03 03:09:24 --> Router Class Initialized
INFO - 2020-03-03 03:09:24 --> Output Class Initialized
INFO - 2020-03-03 03:09:24 --> Security Class Initialized
DEBUG - 2020-03-03 03:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 03:09:24 --> Input Class Initialized
INFO - 2020-03-03 03:09:24 --> Language Class Initialized
INFO - 2020-03-03 03:09:24 --> Loader Class Initialized
INFO - 2020-03-03 03:09:24 --> Helper loaded: url_helper
INFO - 2020-03-03 03:09:24 --> Helper loaded: form_helper
INFO - 2020-03-03 03:09:24 --> Helper loaded: file_helper
INFO - 2020-03-03 03:09:24 --> Database Driver Class Initialized
DEBUG - 2020-03-03 03:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 03:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 03:09:24 --> Form Validation Class Initialized
INFO - 2020-03-03 03:09:24 --> Email Class Initialized
INFO - 2020-03-03 03:09:24 --> Controller Class Initialized
INFO - 2020-03-03 03:09:25 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 03:09:25 --> __construct;, {"cache-control":"no-cache","Postman-Token":"89544e5d-f470-4038-8eaa-1a9a1eb1c5af","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=adg5oo601uojjafn2060qaip4de5jee0","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------792941584855379785711564","content-length":"512","Connection":"keep-alive"}
INFO - 2020-03-03 03:09:25 --> Final output sent to browser
DEBUG - 2020-03-03 03:09:25 --> Total execution time: 0.3260
INFO - 2020-03-03 03:09:28 --> Config Class Initialized
INFO - 2020-03-03 03:09:28 --> Hooks Class Initialized
DEBUG - 2020-03-03 03:09:28 --> UTF-8 Support Enabled
INFO - 2020-03-03 03:09:28 --> Utf8 Class Initialized
INFO - 2020-03-03 03:09:28 --> URI Class Initialized
INFO - 2020-03-03 03:09:28 --> Router Class Initialized
INFO - 2020-03-03 03:09:28 --> Output Class Initialized
INFO - 2020-03-03 03:09:28 --> Security Class Initialized
DEBUG - 2020-03-03 03:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 03:09:28 --> Input Class Initialized
INFO - 2020-03-03 03:09:28 --> Language Class Initialized
INFO - 2020-03-03 03:09:28 --> Loader Class Initialized
INFO - 2020-03-03 03:09:28 --> Helper loaded: url_helper
INFO - 2020-03-03 03:09:28 --> Helper loaded: form_helper
INFO - 2020-03-03 03:09:28 --> Helper loaded: file_helper
INFO - 2020-03-03 03:09:28 --> Database Driver Class Initialized
DEBUG - 2020-03-03 03:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 03:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 03:09:28 --> Form Validation Class Initialized
INFO - 2020-03-03 03:09:28 --> Email Class Initialized
INFO - 2020-03-03 03:09:28 --> Controller Class Initialized
INFO - 2020-03-03 03:09:28 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 03:09:28 --> __construct;, {"Token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNCIsInByb2ZpbGVfaWQiOiIyIiwiZW1haWwiOiJ2aXZlay5zeXNhbGdvQGdtYWlsLmNvbSJ9.fSiNpWSVx8aPo3VwlFssHzupsqpShdYIY3eKUScRAWU","cache-control":"no-cache","Postman-Token":"e67dc5e8-bf26-4ee0-ae5d-26e6722705ba","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=adg5oo601uojjafn2060qaip4de5jee0","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------350806157134457354394517","content-length":"512","Connection":"keep-alive","token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNCIsInByb2ZpbGVfaWQiOiIyIiwiZW1haWwiOiJ2aXZlay5zeXNhbGdvQGdtYWlsLmNvbSJ9.fSiNpWSVx8aPo3VwlFssHzupsqpShdYIY3eKUScRAWU"}
INFO - 2020-03-03 03:09:28 --> Final output sent to browser
DEBUG - 2020-03-03 03:09:28 --> Total execution time: 0.3045
INFO - 2020-03-03 03:09:31 --> Config Class Initialized
INFO - 2020-03-03 03:09:31 --> Hooks Class Initialized
DEBUG - 2020-03-03 03:09:31 --> UTF-8 Support Enabled
INFO - 2020-03-03 03:09:31 --> Utf8 Class Initialized
INFO - 2020-03-03 03:09:31 --> URI Class Initialized
INFO - 2020-03-03 03:09:31 --> Router Class Initialized
INFO - 2020-03-03 03:09:31 --> Output Class Initialized
INFO - 2020-03-03 03:09:31 --> Security Class Initialized
DEBUG - 2020-03-03 03:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 03:09:32 --> Input Class Initialized
INFO - 2020-03-03 03:09:32 --> Language Class Initialized
INFO - 2020-03-03 03:09:32 --> Loader Class Initialized
INFO - 2020-03-03 03:09:32 --> Helper loaded: url_helper
INFO - 2020-03-03 03:09:32 --> Helper loaded: form_helper
INFO - 2020-03-03 03:09:32 --> Helper loaded: file_helper
INFO - 2020-03-03 03:09:32 --> Database Driver Class Initialized
DEBUG - 2020-03-03 03:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 03:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 03:09:32 --> Form Validation Class Initialized
INFO - 2020-03-03 03:09:32 --> Email Class Initialized
INFO - 2020-03-03 03:09:32 --> Controller Class Initialized
INFO - 2020-03-03 03:09:32 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 03:09:32 --> __construct;, {"Token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNCIsInByb2ZpbGVfaWQiOiIyIiwiZW1haWwiOiJ2aXZlay5zeXNhbGdvQGdtYWlsLmNvbSJ9.fSiNpWSVx8aPo3VwlFssHzupsqpShdYIY3eKUScRAWU","cache-control":"no-cache","Postman-Token":"c5490e4e-d66c-44fb-82a6-6fdfa3f619fb","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=adg5oo601uojjafn2060qaip4de5jee0","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------369635288440058895168668","content-length":"512","Connection":"keep-alive","token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNCIsInByb2ZpbGVfaWQiOiIyIiwiZW1haWwiOiJ2aXZlay5zeXNhbGdvQGdtYWlsLmNvbSJ9.fSiNpWSVx8aPo3VwlFssHzupsqpShdYIY3eKUScRAWU"}
INFO - 2020-03-03 03:09:32 --> Final output sent to browser
DEBUG - 2020-03-03 03:09:32 --> Total execution time: 0.3386
INFO - 2020-03-03 03:10:03 --> Config Class Initialized
INFO - 2020-03-03 03:10:03 --> Hooks Class Initialized
DEBUG - 2020-03-03 03:10:03 --> UTF-8 Support Enabled
INFO - 2020-03-03 03:10:03 --> Utf8 Class Initialized
INFO - 2020-03-03 03:10:03 --> URI Class Initialized
INFO - 2020-03-03 03:10:03 --> Router Class Initialized
INFO - 2020-03-03 03:10:03 --> Output Class Initialized
INFO - 2020-03-03 03:10:03 --> Security Class Initialized
DEBUG - 2020-03-03 03:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 03:10:03 --> Input Class Initialized
INFO - 2020-03-03 03:10:03 --> Language Class Initialized
INFO - 2020-03-03 03:10:03 --> Loader Class Initialized
INFO - 2020-03-03 03:10:03 --> Helper loaded: url_helper
INFO - 2020-03-03 03:10:03 --> Helper loaded: form_helper
INFO - 2020-03-03 03:10:03 --> Helper loaded: file_helper
INFO - 2020-03-03 03:10:03 --> Database Driver Class Initialized
DEBUG - 2020-03-03 03:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 03:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 03:10:03 --> Form Validation Class Initialized
INFO - 2020-03-03 03:10:03 --> Email Class Initialized
INFO - 2020-03-03 03:10:03 --> Controller Class Initialized
INFO - 2020-03-03 03:10:03 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 03:10:03 --> __construct;, {"Token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNCIsInByb2ZpbGVfaWQiOiIyIiwiZW1haWwiOiJ2aXZlay5zeXNhbGdvQGdtYWlsLmNvbSJ9.fSiNpWSVx8aPo3VwlFssHzupsqpShdYIY3eKUScRAWU","cache-control":"no-cache","Postman-Token":"60f86de6-103d-4f88-b064-acb1c699ba10","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=adg5oo601uojjafn2060qaip4de5jee0","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------725958036174817403486614","content-length":"512","Connection":"keep-alive","token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNCIsInByb2ZpbGVfaWQiOiIyIiwiZW1haWwiOiJ2aXZlay5zeXNhbGdvQGdtYWlsLmNvbSJ9.fSiNpWSVx8aPo3VwlFssHzupsqpShdYIY3eKUScRAWU"}
INFO - 2020-03-03 03:10:03 --> Final output sent to browser
DEBUG - 2020-03-03 03:10:03 --> Total execution time: 0.3020
INFO - 2020-03-03 03:10:41 --> Config Class Initialized
INFO - 2020-03-03 03:10:41 --> Hooks Class Initialized
DEBUG - 2020-03-03 03:10:41 --> UTF-8 Support Enabled
INFO - 2020-03-03 03:10:41 --> Utf8 Class Initialized
INFO - 2020-03-03 03:10:41 --> URI Class Initialized
INFO - 2020-03-03 03:10:41 --> Router Class Initialized
INFO - 2020-03-03 03:10:41 --> Output Class Initialized
INFO - 2020-03-03 03:10:41 --> Security Class Initialized
DEBUG - 2020-03-03 03:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 03:10:41 --> Input Class Initialized
INFO - 2020-03-03 03:10:41 --> Language Class Initialized
INFO - 2020-03-03 03:10:41 --> Loader Class Initialized
INFO - 2020-03-03 03:10:41 --> Helper loaded: url_helper
INFO - 2020-03-03 03:10:41 --> Helper loaded: form_helper
INFO - 2020-03-03 03:10:41 --> Helper loaded: file_helper
INFO - 2020-03-03 03:10:41 --> Database Driver Class Initialized
DEBUG - 2020-03-03 03:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 03:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 03:10:41 --> Form Validation Class Initialized
INFO - 2020-03-03 03:10:41 --> Email Class Initialized
INFO - 2020-03-03 03:10:41 --> Controller Class Initialized
INFO - 2020-03-03 03:10:41 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 03:10:41 --> __construct;, {"Token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNCIsInByb2ZpbGVfaWQiOiIyIiwiZW1haWwiOiJ2aXZlay5zeXNhbGdvQGdtYWlsLmNvbSJ9.fSiNpWSVx8aPo3VwlFssHzupsqpShdYIY3eKUScRAWU","cache-control":"no-cache","Postman-Token":"1c081725-9b80-47b4-ae43-476042c9cc63","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=adg5oo601uojjafn2060qaip4de5jee0","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------930180139866431359928052","content-length":"512","Connection":"keep-alive","token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNCIsInByb2ZpbGVfaWQiOiIyIiwiZW1haWwiOiJ2aXZlay5zeXNhbGdvQGdtYWlsLmNvbSJ9.fSiNpWSVx8aPo3VwlFssHzupsqpShdYIY3eKUScRAWU"}
INFO - 2020-03-03 03:10:41 --> Final output sent to browser
DEBUG - 2020-03-03 03:10:41 --> Total execution time: 0.3022
INFO - 2020-03-03 03:11:48 --> Config Class Initialized
INFO - 2020-03-03 03:11:48 --> Hooks Class Initialized
DEBUG - 2020-03-03 03:11:48 --> UTF-8 Support Enabled
INFO - 2020-03-03 03:11:48 --> Utf8 Class Initialized
INFO - 2020-03-03 03:11:48 --> URI Class Initialized
INFO - 2020-03-03 03:11:48 --> Router Class Initialized
INFO - 2020-03-03 03:11:48 --> Output Class Initialized
INFO - 2020-03-03 03:11:48 --> Security Class Initialized
DEBUG - 2020-03-03 03:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-03 03:11:48 --> Input Class Initialized
INFO - 2020-03-03 03:11:48 --> Language Class Initialized
INFO - 2020-03-03 03:11:48 --> Loader Class Initialized
INFO - 2020-03-03 03:11:48 --> Helper loaded: url_helper
INFO - 2020-03-03 03:11:48 --> Helper loaded: form_helper
INFO - 2020-03-03 03:11:48 --> Helper loaded: file_helper
INFO - 2020-03-03 03:11:48 --> Database Driver Class Initialized
DEBUG - 2020-03-03 03:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-03 03:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-03 03:11:48 --> Form Validation Class Initialized
INFO - 2020-03-03 03:11:48 --> Email Class Initialized
INFO - 2020-03-03 03:11:48 --> Controller Class Initialized
INFO - 2020-03-03 03:11:48 --> Model "Mainpagedata" initialized
DEBUG - 2020-03-03 03:11:48 --> __construct;, {"Token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNCIsInByb2ZpbGVfaWQiOiIyIiwiZW1haWwiOiJ2aXZlay5zeXNhbGdvQGdtYWlsLmNvbSJ9.fSiNpWSVx8aPo3VwlFssHzupsqpShdYIY3eKUScRAWU","cache-control":"no-cache","Postman-Token":"184d26a5-3b44-4992-a72a-b00c28a15810","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=adg5oo601uojjafn2060qaip4de5jee0","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------989578231337747209366950","content-length":"512","Connection":"keep-alive","token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNCIsInByb2ZpbGVfaWQiOiIyIiwiZW1haWwiOiJ2aXZlay5zeXNhbGdvQGdtYWlsLmNvbSJ9.fSiNpWSVx8aPo3VwlFssHzupsqpShdYIY3eKUScRAWU"}
INFO - 2020-03-03 03:11:49 --> Final output sent to browser
DEBUG - 2020-03-03 03:11:49 --> Total execution time: 0.3159
