<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-11 22:54:27 --> Config Class Initialized
INFO - 2020-02-11 22:54:27 --> Hooks Class Initialized
DEBUG - 2020-02-11 22:54:27 --> UTF-8 Support Enabled
INFO - 2020-02-11 22:54:27 --> Utf8 Class Initialized
INFO - 2020-02-11 22:54:27 --> URI Class Initialized
DEBUG - 2020-02-11 22:54:27 --> No URI present. Default controller set.
INFO - 2020-02-11 22:54:27 --> Router Class Initialized
INFO - 2020-02-11 22:54:27 --> Output Class Initialized
INFO - 2020-02-11 22:54:27 --> Security Class Initialized
DEBUG - 2020-02-11 22:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 22:54:27 --> Input Class Initialized
INFO - 2020-02-11 22:54:27 --> Language Class Initialized
INFO - 2020-02-11 22:54:27 --> Loader Class Initialized
INFO - 2020-02-11 22:54:27 --> Helper loaded: url_helper
INFO - 2020-02-11 22:54:27 --> Helper loaded: form_helper
INFO - 2020-02-11 22:54:27 --> Helper loaded: file_helper
INFO - 2020-02-11 22:54:27 --> Database Driver Class Initialized
DEBUG - 2020-02-11 22:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 22:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 22:54:27 --> Form Validation Class Initialized
INFO - 2020-02-11 22:54:27 --> Email Class Initialized
INFO - 2020-02-11 22:54:27 --> Controller Class Initialized
INFO - 2020-02-11 22:54:27 --> Model "Adminmodel" initialized
INFO - 2020-02-11 22:54:27 --> File loaded: C:\xampp\htdocs\Flegigs\application\views\login.php
INFO - 2020-02-11 22:54:27 --> Final output sent to browser
DEBUG - 2020-02-11 22:54:27 --> Total execution time: 0.7811
