INFO - 2020-01-29 17:40:50 --> Config Class Initialized
INFO - 2020-01-29 17:40:50 --> Hooks Class Initialized
DEBUG - 2020-01-29 17:40:50 --> UTF-8 Support Enabled
INFO - 2020-01-29 17:40:50 --> Utf8 Class Initialized
INFO - 2020-01-29 17:40:50 --> URI Class Initialized
INFO - 2020-01-29 17:40:50 --> Router Class Initialized
INFO - 2020-01-29 17:40:50 --> Output Class Initialized
INFO - 2020-01-29 17:40:50 --> Security Class Initialized
DEBUG - 2020-01-29 17:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-29 17:40:50 --> Input Class Initialized
INFO - 2020-01-29 17:40:50 --> Language Class Initialized
INFO - 2020-01-29 17:40:50 --> Loader Class Initialized
INFO - 2020-01-29 17:40:50 --> Helper loaded: url_helper
INFO - 2020-01-29 17:40:50 --> Helper loaded: form_helper
INFO - 2020-01-29 17:40:50 --> Helper loaded: file_helper
INFO - 2020-01-29 17:40:50 --> Database Driver Class Initialized
DEBUG - 2020-01-29 17:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-29 17:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-29 17:40:50 --> Form Validation Class Initialized
INFO - 2020-01-29 17:40:50 --> Email Class Initialized
INFO - 2020-01-29 17:40:50 --> Controller Class Initialized
INFO - 2020-01-29 17:40:50 --> Model "Mainpagedata" initialized
DEBUG - 2020-01-29 17:40:50 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMzEiLCJwcm9maWxlX2lkIjoiMiIsImVtYWlsIjoiamVsbGEua2luZy4xMDIzQGhvdG1haWwuY29tIn0.KWT9sutGa0ePGEcAG9MLgxvpZdctIBqluAmKF6OwR6E","cache-control":"no-cache","Postman-Token":"a0b65eac-fc53-4c35-b0ff-30a7779c312f","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=qb3brctnf8bvlaj3lc2i31tm52s4n19t","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------477281889641365953747135","content-length":"400","Connection":"keep-alive"}
INFO - 2020-01-29 17:40:50 --> Final output sent to browser
DEBUG - 2020-01-29 17:40:50 --> Total execution time: 0.2027
INFO - 2020-01-29 18:15:01 --> Config Class Initialized
INFO - 2020-01-29 18:15:01 --> Hooks Class Initialized
DEBUG - 2020-01-29 18:15:01 --> UTF-8 Support Enabled
INFO - 2020-01-29 18:15:01 --> Utf8 Class Initialized
INFO - 2020-01-29 18:15:01 --> URI Class Initialized
INFO - 2020-01-29 18:15:01 --> Router Class Initialized
INFO - 2020-01-29 18:15:01 --> Output Class Initialized
INFO - 2020-01-29 18:15:01 --> Security Class Initialized
DEBUG - 2020-01-29 18:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-29 18:15:01 --> Input Class Initialized
INFO - 2020-01-29 18:15:01 --> Language Class Initialized
INFO - 2020-01-29 18:15:01 --> Loader Class Initialized
INFO - 2020-01-29 18:15:01 --> Helper loaded: url_helper
INFO - 2020-01-29 18:15:01 --> Helper loaded: form_helper
INFO - 2020-01-29 18:15:01 --> Helper loaded: file_helper
INFO - 2020-01-29 18:15:01 --> Database Driver Class Initialized
DEBUG - 2020-01-29 18:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-29 18:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-29 18:15:01 --> Form Validation Class Initialized
INFO - 2020-01-29 18:15:01 --> Email Class Initialized
INFO - 2020-01-29 18:15:01 --> Controller Class Initialized
INFO - 2020-01-29 18:15:01 --> Model "Mainpagedata" initialized
DEBUG - 2020-01-29 18:15:01 --> __construct;, {"Token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMzEiLCJwcm9maWxlX2lkIjoiMiIsImVtYWlsIjoiamVsbGEua2luZy4xMDIzQGhvdG1haWwuY29tIn0.KWT9sutGa0ePGEcAG9MLgxvpZdctIBqluAmKF6OwR6E","cache-control":"no-cache","Postman-Token":"d8ddb137-487b-4c4f-8419-de32bddd2aec","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=qb3brctnf8bvlaj3lc2i31tm52s4n19t","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------624014865004144460494542","content-length":"400","Connection":"keep-alive"}
INFO - 2020-01-29 18:15:01 --> Final output sent to browser
DEBUG - 2020-01-29 18:15:01 --> Total execution time: 0.2241
INFO - 2020-01-29 18:15:18 --> Config Class Initialized
INFO - 2020-01-29 18:15:18 --> Hooks Class Initialized
DEBUG - 2020-01-29 18:15:18 --> UTF-8 Support Enabled
INFO - 2020-01-29 18:15:18 --> Utf8 Class Initialized
INFO - 2020-01-29 18:15:18 --> URI Class Initialized
INFO - 2020-01-29 18:15:18 --> Router Class Initialized
INFO - 2020-01-29 18:15:18 --> Output Class Initialized
INFO - 2020-01-29 18:15:18 --> Security Class Initialized
DEBUG - 2020-01-29 18:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-29 18:15:18 --> Input Class Initialized
INFO - 2020-01-29 18:15:18 --> Language Class Initialized
INFO - 2020-01-29 18:15:18 --> Loader Class Initialized
INFO - 2020-01-29 18:15:18 --> Helper loaded: url_helper
INFO - 2020-01-29 18:15:18 --> Helper loaded: form_helper
INFO - 2020-01-29 18:15:18 --> Helper loaded: file_helper
INFO - 2020-01-29 18:15:18 --> Database Driver Class Initialized
DEBUG - 2020-01-29 18:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-29 18:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-29 18:15:18 --> Form Validation Class Initialized
INFO - 2020-01-29 18:15:18 --> Email Class Initialized
INFO - 2020-01-29 18:15:18 --> Controller Class Initialized
INFO - 2020-01-29 18:15:18 --> Model "Mainpagedata" initialized
DEBUG - 2020-01-29 18:15:18 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMzEiLCJwcm9maWxlX2lkIjoiMiIsImVtYWlsIjoiamVsbGEua2luZy4xMDIzQGhvdG1haWwuY29tIn0.KWT9sutGa0ePGEcAG9MLgxvpZdctIBqluAmKF6OwR6E","cache-control":"no-cache","Postman-Token":"0aefb385-5c65-416a-bccf-7149201c7c37","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=eebm1q5out7u5pa257qdutq1lndrbsfj","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------978408135192494246776183","content-length":"400","Connection":"keep-alive"}
INFO - 2020-01-29 18:15:18 --> Final output sent to browser
DEBUG - 2020-01-29 18:15:18 --> Total execution time: 0.2267
INFO - 2020-01-29 18:30:03 --> Config Class Initialized
INFO - 2020-01-29 18:30:03 --> Hooks Class Initialized
DEBUG - 2020-01-29 18:30:03 --> UTF-8 Support Enabled
INFO - 2020-01-29 18:30:03 --> Utf8 Class Initialized
INFO - 2020-01-29 18:30:03 --> URI Class Initialized
INFO - 2020-01-29 18:30:03 --> Router Class Initialized
INFO - 2020-01-29 18:30:03 --> Output Class Initialized
INFO - 2020-01-29 18:30:03 --> Security Class Initialized
DEBUG - 2020-01-29 18:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-29 18:30:03 --> Input Class Initialized
INFO - 2020-01-29 18:30:03 --> Language Class Initialized
INFO - 2020-01-29 18:30:05 --> Loader Class Initialized
INFO - 2020-01-29 18:30:05 --> Helper loaded: url_helper
INFO - 2020-01-29 18:30:05 --> Helper loaded: form_helper
INFO - 2020-01-29 18:30:05 --> Helper loaded: file_helper
INFO - 2020-01-29 18:30:05 --> Database Driver Class Initialized
ERROR - 2020-01-29 18:30:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\Flegigs\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-01-29 18:30:09 --> Unable to connect to the database
INFO - 2020-01-29 18:30:09 --> Language file loaded: language/english/db_lang.php
INFO - 2020-01-29 18:30:17 --> Config Class Initialized
INFO - 2020-01-29 18:30:17 --> Hooks Class Initialized
DEBUG - 2020-01-29 18:30:17 --> UTF-8 Support Enabled
INFO - 2020-01-29 18:30:17 --> Utf8 Class Initialized
INFO - 2020-01-29 18:30:17 --> URI Class Initialized
INFO - 2020-01-29 18:30:17 --> Router Class Initialized
INFO - 2020-01-29 18:30:17 --> Output Class Initialized
INFO - 2020-01-29 18:30:17 --> Security Class Initialized
DEBUG - 2020-01-29 18:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-29 18:30:17 --> Input Class Initialized
INFO - 2020-01-29 18:30:17 --> Language Class Initialized
INFO - 2020-01-29 18:30:17 --> Loader Class Initialized
INFO - 2020-01-29 18:30:17 --> Helper loaded: url_helper
INFO - 2020-01-29 18:30:17 --> Helper loaded: form_helper
INFO - 2020-01-29 18:30:17 --> Helper loaded: file_helper
INFO - 2020-01-29 18:30:17 --> Database Driver Class Initialized
DEBUG - 2020-01-29 18:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-29 18:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-29 18:30:18 --> Form Validation Class Initialized
INFO - 2020-01-29 18:30:18 --> Email Class Initialized
INFO - 2020-01-29 18:30:18 --> Controller Class Initialized
INFO - 2020-01-29 18:30:18 --> Model "Mainpagedata" initialized
DEBUG - 2020-01-29 18:30:18 --> __construct;, {"Content-Type":"multipart\/form-data; boundary=--------------------------255041404434011247184809","cache-control":"no-cache","Postman-Token":"0f936688-2261-424b-8b81-d3d22ad0172e","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=eebm1q5out7u5pa257qdutq1lndrbsfj","accept-encoding":"gzip, deflate","content-length":"400","Connection":"keep-alive"}
INFO - 2020-01-29 18:30:18 --> Final output sent to browser
DEBUG - 2020-01-29 18:30:18 --> Total execution time: 0.4439
INFO - 2020-01-29 18:33:02 --> Config Class Initialized
INFO - 2020-01-29 18:33:02 --> Hooks Class Initialized
DEBUG - 2020-01-29 18:33:02 --> UTF-8 Support Enabled
INFO - 2020-01-29 18:33:02 --> Utf8 Class Initialized
INFO - 2020-01-29 18:33:02 --> URI Class Initialized
INFO - 2020-01-29 18:33:02 --> Router Class Initialized
INFO - 2020-01-29 18:33:02 --> Output Class Initialized
INFO - 2020-01-29 18:33:02 --> Security Class Initialized
DEBUG - 2020-01-29 18:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-29 18:33:02 --> Input Class Initialized
INFO - 2020-01-29 18:33:02 --> Language Class Initialized
INFO - 2020-01-29 18:33:02 --> Loader Class Initialized
INFO - 2020-01-29 18:33:02 --> Helper loaded: url_helper
INFO - 2020-01-29 18:33:02 --> Helper loaded: form_helper
INFO - 2020-01-29 18:33:02 --> Helper loaded: file_helper
INFO - 2020-01-29 18:33:02 --> Database Driver Class Initialized
DEBUG - 2020-01-29 18:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-29 18:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-29 18:33:02 --> Form Validation Class Initialized
INFO - 2020-01-29 18:33:02 --> Email Class Initialized
INFO - 2020-01-29 18:33:02 --> Controller Class Initialized
INFO - 2020-01-29 18:33:02 --> Model "Mainpagedata" initialized
DEBUG - 2020-01-29 18:33:02 --> __construct;, {"Content-Type":"multipart\/form-data; boundary=--------------------------758787331551954405822758","cache-control":"no-cache","Postman-Token":"49c0bab8-c0d3-48fa-b269-1156e5c7e847","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=bmlnaeoiib01pqrd30ceo63h18o8n1al","accept-encoding":"gzip, deflate","content-length":"406","Connection":"keep-alive"}
INFO - 2020-01-29 18:33:02 --> Final output sent to browser
DEBUG - 2020-01-29 18:33:02 --> Total execution time: 0.2176
INFO - 2020-01-29 18:33:53 --> Config Class Initialized
INFO - 2020-01-29 18:33:53 --> Hooks Class Initialized
DEBUG - 2020-01-29 18:33:53 --> UTF-8 Support Enabled
INFO - 2020-01-29 18:33:53 --> Utf8 Class Initialized
INFO - 2020-01-29 18:33:53 --> URI Class Initialized
INFO - 2020-01-29 18:33:53 --> Router Class Initialized
INFO - 2020-01-29 18:33:53 --> Output Class Initialized
INFO - 2020-01-29 18:33:53 --> Security Class Initialized
DEBUG - 2020-01-29 18:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-29 18:33:53 --> Input Class Initialized
INFO - 2020-01-29 18:33:53 --> Language Class Initialized
INFO - 2020-01-29 18:33:53 --> Loader Class Initialized
INFO - 2020-01-29 18:33:53 --> Helper loaded: url_helper
INFO - 2020-01-29 18:33:53 --> Helper loaded: form_helper
INFO - 2020-01-29 18:33:53 --> Helper loaded: file_helper
INFO - 2020-01-29 18:33:53 --> Database Driver Class Initialized
DEBUG - 2020-01-29 18:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-29 18:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-29 18:33:53 --> Form Validation Class Initialized
INFO - 2020-01-29 18:33:53 --> Email Class Initialized
INFO - 2020-01-29 18:33:53 --> Controller Class Initialized
INFO - 2020-01-29 18:33:53 --> Model "Mainpagedata" initialized
DEBUG - 2020-01-29 18:33:53 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNCIsInByb2ZpbGVfaWQiOiIyIiwiZW1haWwiOiJ2aXZlay5zeXNhbGdvQGdtYWlsLmNvbSJ9.fSiNpWSVx8aPo3VwlFssHzupsqpShdYIY3eKUScRAWU","cache-control":"no-cache","Postman-Token":"3fe277fb-4a29-40e0-aedd-ac26aa2dad81","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=bmlnaeoiib01pqrd30ceo63h18o8n1al","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------229977055031466574691391","content-length":"406","Connection":"keep-alive"}
INFO - 2020-01-29 18:33:53 --> Final output sent to browser
DEBUG - 2020-01-29 18:33:53 --> Total execution time: 0.2251
INFO - 2020-01-29 18:34:40 --> Config Class Initialized
INFO - 2020-01-29 18:34:40 --> Hooks Class Initialized
DEBUG - 2020-01-29 18:34:40 --> UTF-8 Support Enabled
INFO - 2020-01-29 18:34:40 --> Utf8 Class Initialized
INFO - 2020-01-29 18:34:40 --> URI Class Initialized
INFO - 2020-01-29 18:34:40 --> Router Class Initialized
INFO - 2020-01-29 18:34:40 --> Output Class Initialized
INFO - 2020-01-29 18:34:40 --> Security Class Initialized
DEBUG - 2020-01-29 18:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-29 18:34:40 --> Input Class Initialized
INFO - 2020-01-29 18:34:40 --> Language Class Initialized
INFO - 2020-01-29 18:34:40 --> Loader Class Initialized
INFO - 2020-01-29 18:34:40 --> Helper loaded: url_helper
INFO - 2020-01-29 18:34:40 --> Helper loaded: form_helper
INFO - 2020-01-29 18:34:40 --> Helper loaded: file_helper
INFO - 2020-01-29 18:34:40 --> Database Driver Class Initialized
DEBUG - 2020-01-29 18:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-29 18:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-29 18:34:40 --> Form Validation Class Initialized
INFO - 2020-01-29 18:34:40 --> Email Class Initialized
INFO - 2020-01-29 18:34:40 --> Controller Class Initialized
INFO - 2020-01-29 18:34:40 --> Model "Mainpagedata" initialized
DEBUG - 2020-01-29 18:34:40 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNCIsInByb2ZpbGVfaWQiOiIyIiwiZW1haWwiOiJ2aXZlay5zeXNhbGdvQGdtYWlsLmNvbSJ9.fSiNpWSVx8aPo3VwlFssHzupsqpShdYIY3eKUScRAWU","cache-control":"no-cache","Postman-Token":"5a80d829-7b93-4fb0-9dc8-c1ea0b98660f","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=bmlnaeoiib01pqrd30ceo63h18o8n1al","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------901284998992750913808107","content-length":"406","Connection":"keep-alive"}
INFO - 2020-01-29 18:34:40 --> Final output sent to browser
DEBUG - 2020-01-29 18:34:40 --> Total execution time: 0.2266
INFO - 2020-01-29 18:39:02 --> Config Class Initialized
INFO - 2020-01-29 18:39:02 --> Hooks Class Initialized
DEBUG - 2020-01-29 18:39:02 --> UTF-8 Support Enabled
INFO - 2020-01-29 18:39:02 --> Utf8 Class Initialized
INFO - 2020-01-29 18:39:02 --> URI Class Initialized
INFO - 2020-01-29 18:39:02 --> Router Class Initialized
INFO - 2020-01-29 18:39:02 --> Output Class Initialized
INFO - 2020-01-29 18:39:02 --> Security Class Initialized
DEBUG - 2020-01-29 18:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-29 18:39:02 --> Input Class Initialized
INFO - 2020-01-29 18:39:02 --> Language Class Initialized
INFO - 2020-01-29 18:39:02 --> Loader Class Initialized
INFO - 2020-01-29 18:39:02 --> Helper loaded: url_helper
INFO - 2020-01-29 18:39:02 --> Helper loaded: form_helper
INFO - 2020-01-29 18:39:02 --> Helper loaded: file_helper
INFO - 2020-01-29 18:39:02 --> Database Driver Class Initialized
DEBUG - 2020-01-29 18:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-29 18:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-29 18:39:02 --> Form Validation Class Initialized
INFO - 2020-01-29 18:39:02 --> Email Class Initialized
INFO - 2020-01-29 18:39:02 --> Controller Class Initialized
INFO - 2020-01-29 18:39:02 --> Model "Mainpagedata" initialized
DEBUG - 2020-01-29 18:39:02 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNCIsInByb2ZpbGVfaWQiOiIyIiwiZW1haWwiOiJ2aXZlay5zeXNhbGdvQGdtYWlsLmNvbSJ9.fSiNpWSVx8aPo3VwlFssHzupsqpShdYIY3eKUScRAWU","cache-control":"no-cache","Postman-Token":"acd9b462-b71b-4ab7-b0d6-f87c2324f1a3","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=bmlnaeoiib01pqrd30ceo63h18o8n1al","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------880447665981263807734285","content-length":"406","Connection":"keep-alive"}
INFO - 2020-01-29 18:39:02 --> Final output sent to browser
DEBUG - 2020-01-29 18:39:02 --> Total execution time: 0.2131
