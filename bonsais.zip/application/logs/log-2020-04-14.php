<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-04-14 03:57:39 --> Config Class Initialized
INFO - 2020-04-14 03:57:39 --> Hooks Class Initialized
DEBUG - 2020-04-14 03:57:39 --> UTF-8 Support Enabled
INFO - 2020-04-14 03:57:39 --> Utf8 Class Initialized
INFO - 2020-04-14 03:57:39 --> URI Class Initialized
INFO - 2020-04-14 03:57:39 --> Router Class Initialized
INFO - 2020-04-14 03:57:39 --> Output Class Initialized
INFO - 2020-04-14 03:57:39 --> Security Class Initialized
DEBUG - 2020-04-14 03:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 03:57:39 --> Input Class Initialized
INFO - 2020-04-14 03:57:39 --> Language Class Initialized
ERROR - 2020-04-14 03:57:39 --> 404 Page Not Found: Bonsais/api
INFO - 2020-04-14 03:57:57 --> Config Class Initialized
INFO - 2020-04-14 03:57:57 --> Hooks Class Initialized
DEBUG - 2020-04-14 03:57:57 --> UTF-8 Support Enabled
INFO - 2020-04-14 03:57:57 --> Utf8 Class Initialized
INFO - 2020-04-14 03:57:57 --> URI Class Initialized
DEBUG - 2020-04-14 03:57:57 --> No URI present. Default controller set.
INFO - 2020-04-14 03:57:57 --> Router Class Initialized
INFO - 2020-04-14 03:57:57 --> Output Class Initialized
INFO - 2020-04-14 03:57:57 --> Security Class Initialized
DEBUG - 2020-04-14 03:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 03:57:57 --> Input Class Initialized
INFO - 2020-04-14 03:57:57 --> Language Class Initialized
INFO - 2020-04-14 03:57:57 --> Loader Class Initialized
INFO - 2020-04-14 03:57:57 --> Helper loaded: url_helper
INFO - 2020-04-14 03:57:57 --> Helper loaded: form_helper
INFO - 2020-04-14 03:57:57 --> Helper loaded: file_helper
INFO - 2020-04-14 03:57:57 --> Database Driver Class Initialized
DEBUG - 2020-04-14 03:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-14 03:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-14 03:57:57 --> Form Validation Class Initialized
INFO - 2020-04-14 03:57:57 --> Email Class Initialized
INFO - 2020-04-14 03:57:57 --> Controller Class Initialized
INFO - 2020-04-14 03:57:57 --> Model "Adminmodel" initialized
INFO - 2020-04-14 03:57:57 --> File loaded: C:\xampp\htdocs\bonsais\application\views\login.php
INFO - 2020-04-14 03:57:57 --> Final output sent to browser
DEBUG - 2020-04-14 03:57:57 --> Total execution time: 0.2694
INFO - 2020-04-14 03:58:17 --> Config Class Initialized
INFO - 2020-04-14 03:58:17 --> Hooks Class Initialized
DEBUG - 2020-04-14 03:58:17 --> UTF-8 Support Enabled
INFO - 2020-04-14 03:58:17 --> Utf8 Class Initialized
INFO - 2020-04-14 03:58:17 --> URI Class Initialized
INFO - 2020-04-14 03:58:17 --> Router Class Initialized
INFO - 2020-04-14 03:58:17 --> Output Class Initialized
INFO - 2020-04-14 03:58:17 --> Security Class Initialized
DEBUG - 2020-04-14 03:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 03:58:17 --> Input Class Initialized
INFO - 2020-04-14 03:58:17 --> Language Class Initialized
ERROR - 2020-04-14 03:58:17 --> 404 Page Not Found: Api/register
INFO - 2020-04-14 03:58:33 --> Config Class Initialized
INFO - 2020-04-14 03:58:33 --> Hooks Class Initialized
DEBUG - 2020-04-14 03:58:33 --> UTF-8 Support Enabled
INFO - 2020-04-14 03:58:33 --> Utf8 Class Initialized
INFO - 2020-04-14 03:58:33 --> URI Class Initialized
INFO - 2020-04-14 03:58:33 --> Router Class Initialized
INFO - 2020-04-14 03:58:33 --> Output Class Initialized
INFO - 2020-04-14 03:58:33 --> Security Class Initialized
DEBUG - 2020-04-14 03:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 03:58:33 --> Input Class Initialized
INFO - 2020-04-14 03:58:33 --> Language Class Initialized
ERROR - 2020-04-14 03:58:33 --> 404 Page Not Found: Api/register
INFO - 2020-04-14 03:58:41 --> Config Class Initialized
INFO - 2020-04-14 03:58:41 --> Hooks Class Initialized
DEBUG - 2020-04-14 03:58:41 --> UTF-8 Support Enabled
INFO - 2020-04-14 03:58:41 --> Utf8 Class Initialized
INFO - 2020-04-14 03:58:41 --> URI Class Initialized
INFO - 2020-04-14 03:58:42 --> Router Class Initialized
INFO - 2020-04-14 03:58:42 --> Output Class Initialized
INFO - 2020-04-14 03:58:42 --> Security Class Initialized
DEBUG - 2020-04-14 03:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 03:58:42 --> Input Class Initialized
INFO - 2020-04-14 03:58:42 --> Language Class Initialized
ERROR - 2020-04-14 03:58:42 --> 404 Page Not Found: Api/register
INFO - 2020-04-14 03:58:50 --> Config Class Initialized
INFO - 2020-04-14 03:58:50 --> Hooks Class Initialized
DEBUG - 2020-04-14 03:58:50 --> UTF-8 Support Enabled
INFO - 2020-04-14 03:58:50 --> Utf8 Class Initialized
INFO - 2020-04-14 03:58:50 --> URI Class Initialized
DEBUG - 2020-04-14 03:58:50 --> No URI present. Default controller set.
INFO - 2020-04-14 03:58:50 --> Router Class Initialized
INFO - 2020-04-14 03:58:50 --> Output Class Initialized
INFO - 2020-04-14 03:58:50 --> Security Class Initialized
DEBUG - 2020-04-14 03:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 03:58:50 --> Input Class Initialized
INFO - 2020-04-14 03:58:50 --> Language Class Initialized
INFO - 2020-04-14 03:58:50 --> Loader Class Initialized
INFO - 2020-04-14 03:58:50 --> Helper loaded: url_helper
INFO - 2020-04-14 03:58:50 --> Helper loaded: form_helper
INFO - 2020-04-14 03:58:50 --> Helper loaded: file_helper
INFO - 2020-04-14 03:58:50 --> Database Driver Class Initialized
DEBUG - 2020-04-14 03:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-14 03:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-14 03:58:50 --> Form Validation Class Initialized
INFO - 2020-04-14 03:58:50 --> Email Class Initialized
INFO - 2020-04-14 03:58:50 --> Controller Class Initialized
INFO - 2020-04-14 03:58:50 --> Model "Adminmodel" initialized
INFO - 2020-04-14 03:58:51 --> File loaded: C:\xampp\htdocs\bonsais\application\views\login.php
INFO - 2020-04-14 03:58:51 --> Final output sent to browser
DEBUG - 2020-04-14 03:58:51 --> Total execution time: 0.2675
INFO - 2020-04-14 03:58:55 --> Config Class Initialized
INFO - 2020-04-14 03:58:55 --> Hooks Class Initialized
DEBUG - 2020-04-14 03:58:55 --> UTF-8 Support Enabled
INFO - 2020-04-14 03:58:55 --> Utf8 Class Initialized
INFO - 2020-04-14 03:58:55 --> URI Class Initialized
INFO - 2020-04-14 03:58:55 --> Router Class Initialized
INFO - 2020-04-14 03:58:55 --> Output Class Initialized
INFO - 2020-04-14 03:58:55 --> Security Class Initialized
DEBUG - 2020-04-14 03:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 03:58:55 --> Input Class Initialized
INFO - 2020-04-14 03:58:55 --> Language Class Initialized
ERROR - 2020-04-14 03:58:55 --> 404 Page Not Found: Api/index
INFO - 2020-04-14 03:59:40 --> Config Class Initialized
INFO - 2020-04-14 03:59:40 --> Hooks Class Initialized
DEBUG - 2020-04-14 03:59:40 --> UTF-8 Support Enabled
INFO - 2020-04-14 03:59:40 --> Utf8 Class Initialized
INFO - 2020-04-14 03:59:40 --> URI Class Initialized
INFO - 2020-04-14 03:59:40 --> Router Class Initialized
INFO - 2020-04-14 03:59:40 --> Output Class Initialized
INFO - 2020-04-14 03:59:40 --> Security Class Initialized
DEBUG - 2020-04-14 03:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 03:59:40 --> Input Class Initialized
INFO - 2020-04-14 03:59:40 --> Language Class Initialized
ERROR - 2020-04-14 03:59:40 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF) C:\xampp\htdocs\bonsais\application\controllers\Webservice.php 105
INFO - 2020-04-14 03:59:48 --> Config Class Initialized
INFO - 2020-04-14 03:59:48 --> Hooks Class Initialized
DEBUG - 2020-04-14 03:59:48 --> UTF-8 Support Enabled
INFO - 2020-04-14 03:59:48 --> Utf8 Class Initialized
INFO - 2020-04-14 03:59:48 --> URI Class Initialized
INFO - 2020-04-14 03:59:48 --> Router Class Initialized
INFO - 2020-04-14 03:59:48 --> Output Class Initialized
INFO - 2020-04-14 03:59:48 --> Security Class Initialized
DEBUG - 2020-04-14 03:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 03:59:48 --> Input Class Initialized
INFO - 2020-04-14 03:59:48 --> Language Class Initialized
ERROR - 2020-04-14 03:59:48 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF) C:\xampp\htdocs\bonsais\application\controllers\Webservice.php 105
INFO - 2020-04-14 04:01:33 --> Config Class Initialized
INFO - 2020-04-14 04:01:33 --> Hooks Class Initialized
DEBUG - 2020-04-14 04:01:33 --> UTF-8 Support Enabled
INFO - 2020-04-14 04:01:33 --> Utf8 Class Initialized
INFO - 2020-04-14 04:01:33 --> URI Class Initialized
INFO - 2020-04-14 04:01:33 --> Router Class Initialized
INFO - 2020-04-14 04:01:33 --> Output Class Initialized
INFO - 2020-04-14 04:01:33 --> Security Class Initialized
DEBUG - 2020-04-14 04:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 04:01:33 --> Input Class Initialized
INFO - 2020-04-14 04:01:33 --> Language Class Initialized
ERROR - 2020-04-14 04:01:33 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF) C:\xampp\htdocs\bonsais\application\controllers\Webservice.php 104
INFO - 2020-04-14 04:01:57 --> Config Class Initialized
INFO - 2020-04-14 04:01:57 --> Hooks Class Initialized
DEBUG - 2020-04-14 04:01:57 --> UTF-8 Support Enabled
INFO - 2020-04-14 04:01:57 --> Utf8 Class Initialized
INFO - 2020-04-14 04:01:57 --> URI Class Initialized
INFO - 2020-04-14 04:01:57 --> Router Class Initialized
INFO - 2020-04-14 04:01:57 --> Output Class Initialized
INFO - 2020-04-14 04:01:57 --> Security Class Initialized
DEBUG - 2020-04-14 04:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 04:01:57 --> Input Class Initialized
INFO - 2020-04-14 04:01:57 --> Language Class Initialized
INFO - 2020-04-14 04:01:57 --> Loader Class Initialized
INFO - 2020-04-14 04:01:57 --> Helper loaded: url_helper
INFO - 2020-04-14 04:01:57 --> Helper loaded: form_helper
INFO - 2020-04-14 04:01:57 --> Helper loaded: file_helper
INFO - 2020-04-14 04:01:57 --> Database Driver Class Initialized
DEBUG - 2020-04-14 04:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-14 04:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-14 04:01:57 --> Form Validation Class Initialized
INFO - 2020-04-14 04:01:57 --> Email Class Initialized
INFO - 2020-04-14 04:01:57 --> Controller Class Initialized
INFO - 2020-04-14 04:01:57 --> Model "Mainpagedata" initialized
DEBUG - 2020-04-14 04:01:57 --> __construct;, {"cache-control":"no-cache","Postman-Token":"ca8780cf-2739-4dce-b9e3-23a69e9f0fb2","User-Agent":"PostmanRuntime\/7.3.0","Accept":"*\/*","Host":"localhost","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------489362966698820869678874","content-length":"511","Connection":"close"}
ERROR - 2020-04-14 04:01:57 --> Query error: Table 'bonsais.user_details' doesn't exist - Invalid query: INSERT INTO `user_details` (`user_id`, `name`, `phone`) VALUES (2, 'cheng', '123456789')
INFO - 2020-04-14 04:01:57 --> Language file loaded: language/english/db_lang.php
INFO - 2020-04-14 04:03:30 --> Config Class Initialized
INFO - 2020-04-14 04:03:30 --> Hooks Class Initialized
DEBUG - 2020-04-14 04:03:30 --> UTF-8 Support Enabled
INFO - 2020-04-14 04:03:30 --> Utf8 Class Initialized
INFO - 2020-04-14 04:03:30 --> URI Class Initialized
INFO - 2020-04-14 04:03:30 --> Router Class Initialized
INFO - 2020-04-14 04:03:30 --> Output Class Initialized
INFO - 2020-04-14 04:03:30 --> Security Class Initialized
DEBUG - 2020-04-14 04:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 04:03:30 --> Input Class Initialized
INFO - 2020-04-14 04:03:30 --> Language Class Initialized
INFO - 2020-04-14 04:03:30 --> Loader Class Initialized
INFO - 2020-04-14 04:03:30 --> Helper loaded: url_helper
INFO - 2020-04-14 04:03:30 --> Helper loaded: form_helper
INFO - 2020-04-14 04:03:30 --> Helper loaded: file_helper
INFO - 2020-04-14 04:03:30 --> Database Driver Class Initialized
DEBUG - 2020-04-14 04:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-14 04:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-14 04:03:30 --> Form Validation Class Initialized
INFO - 2020-04-14 04:03:30 --> Email Class Initialized
INFO - 2020-04-14 04:03:30 --> Controller Class Initialized
INFO - 2020-04-14 04:03:31 --> Model "Mainpagedata" initialized
DEBUG - 2020-04-14 04:03:31 --> __construct;, {"cache-control":"no-cache","Postman-Token":"9c9b35dd-6e45-4af3-932d-e4c9f0a4cf37","User-Agent":"PostmanRuntime\/7.3.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=ohr90sjfg9bhcs24ie8njm7j6qsh2t4r","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------450178557271029747242952","content-length":"511","Connection":"close"}
INFO - 2020-04-14 04:03:31 --> Final output sent to browser
DEBUG - 2020-04-14 04:03:31 --> Total execution time: 0.2788
INFO - 2020-04-14 04:04:19 --> Config Class Initialized
INFO - 2020-04-14 04:04:19 --> Hooks Class Initialized
DEBUG - 2020-04-14 04:04:19 --> UTF-8 Support Enabled
INFO - 2020-04-14 04:04:19 --> Utf8 Class Initialized
INFO - 2020-04-14 04:04:19 --> URI Class Initialized
INFO - 2020-04-14 04:04:19 --> Router Class Initialized
INFO - 2020-04-14 04:04:19 --> Output Class Initialized
INFO - 2020-04-14 04:04:19 --> Security Class Initialized
DEBUG - 2020-04-14 04:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 04:04:19 --> Input Class Initialized
INFO - 2020-04-14 04:04:19 --> Language Class Initialized
INFO - 2020-04-14 04:04:19 --> Loader Class Initialized
INFO - 2020-04-14 04:04:19 --> Helper loaded: url_helper
INFO - 2020-04-14 04:04:20 --> Helper loaded: form_helper
INFO - 2020-04-14 04:04:20 --> Helper loaded: file_helper
INFO - 2020-04-14 04:04:20 --> Database Driver Class Initialized
DEBUG - 2020-04-14 04:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-14 04:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-14 04:04:20 --> Form Validation Class Initialized
INFO - 2020-04-14 04:04:20 --> Email Class Initialized
INFO - 2020-04-14 04:04:20 --> Controller Class Initialized
INFO - 2020-04-14 04:04:20 --> Model "Mainpagedata" initialized
DEBUG - 2020-04-14 04:04:20 --> __construct;, {"cache-control":"no-cache","Postman-Token":"bb7b11f4-25e3-401a-b67a-b813f7df8be1","User-Agent":"PostmanRuntime\/7.3.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=ohr90sjfg9bhcs24ie8njm7j6qsh2t4r","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------488360483643745517818669","content-length":"511","Connection":"close"}
ERROR - 2020-04-14 04:04:20 --> Query error: Table 'bonsais.user_details' doesn't exist - Invalid query: INSERT INTO `user_details` (`user_id`, `name`, `phone`) VALUES (3, 'cheng', '123456789')
INFO - 2020-04-14 04:04:20 --> Language file loaded: language/english/db_lang.php
INFO - 2020-04-14 04:10:12 --> Config Class Initialized
INFO - 2020-04-14 04:10:12 --> Hooks Class Initialized
DEBUG - 2020-04-14 04:10:12 --> UTF-8 Support Enabled
INFO - 2020-04-14 04:10:12 --> Utf8 Class Initialized
INFO - 2020-04-14 04:10:12 --> URI Class Initialized
INFO - 2020-04-14 04:10:12 --> Router Class Initialized
INFO - 2020-04-14 04:10:12 --> Output Class Initialized
INFO - 2020-04-14 04:10:12 --> Security Class Initialized
DEBUG - 2020-04-14 04:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 04:10:12 --> Input Class Initialized
INFO - 2020-04-14 04:10:12 --> Language Class Initialized
INFO - 2020-04-14 04:10:12 --> Loader Class Initialized
INFO - 2020-04-14 04:10:12 --> Helper loaded: url_helper
INFO - 2020-04-14 04:10:12 --> Helper loaded: form_helper
INFO - 2020-04-14 04:10:12 --> Helper loaded: file_helper
INFO - 2020-04-14 04:10:12 --> Database Driver Class Initialized
DEBUG - 2020-04-14 04:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-14 04:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-14 04:10:12 --> Form Validation Class Initialized
INFO - 2020-04-14 04:10:12 --> Email Class Initialized
INFO - 2020-04-14 04:10:12 --> Controller Class Initialized
INFO - 2020-04-14 04:10:12 --> Model "Mainpagedata" initialized
DEBUG - 2020-04-14 04:10:12 --> __construct;, {"cache-control":"no-cache","Postman-Token":"b7869237-4ca4-4a83-a88b-c84dc5a7a000","User-Agent":"PostmanRuntime\/7.3.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=ohr90sjfg9bhcs24ie8njm7j6qsh2t4r","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------564170224433912302764783","content-length":"511","Connection":"close"}
INFO - 2020-04-14 04:10:12 --> Final output sent to browser
DEBUG - 2020-04-14 04:10:12 --> Total execution time: 0.2771
INFO - 2020-04-14 04:15:05 --> Config Class Initialized
INFO - 2020-04-14 04:15:05 --> Hooks Class Initialized
DEBUG - 2020-04-14 04:15:05 --> UTF-8 Support Enabled
INFO - 2020-04-14 04:15:05 --> Utf8 Class Initialized
INFO - 2020-04-14 04:15:05 --> URI Class Initialized
INFO - 2020-04-14 04:15:05 --> Router Class Initialized
INFO - 2020-04-14 04:15:05 --> Output Class Initialized
INFO - 2020-04-14 04:15:05 --> Security Class Initialized
DEBUG - 2020-04-14 04:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 04:15:05 --> Input Class Initialized
INFO - 2020-04-14 04:15:05 --> Language Class Initialized
INFO - 2020-04-14 04:15:05 --> Loader Class Initialized
INFO - 2020-04-14 04:15:05 --> Helper loaded: url_helper
INFO - 2020-04-14 04:15:05 --> Helper loaded: form_helper
INFO - 2020-04-14 04:15:05 --> Helper loaded: file_helper
INFO - 2020-04-14 04:15:05 --> Database Driver Class Initialized
DEBUG - 2020-04-14 04:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-14 04:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-14 04:15:05 --> Form Validation Class Initialized
INFO - 2020-04-14 04:15:05 --> Email Class Initialized
INFO - 2020-04-14 04:15:05 --> Controller Class Initialized
INFO - 2020-04-14 04:15:05 --> Model "Mainpagedata" initialized
DEBUG - 2020-04-14 04:15:05 --> __construct;, {"cache-control":"no-cache","Postman-Token":"9f67f243-d719-4d8f-ab65-992b3698c104","User-Agent":"PostmanRuntime\/7.3.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=k5rfu2v1viugh4hrsr4tahrqesulk728","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------243067464089578316255689","content-length":"511","Connection":"close"}
INFO - 2020-04-14 04:15:05 --> Final output sent to browser
DEBUG - 2020-04-14 04:15:05 --> Total execution time: 0.2907
INFO - 2020-04-14 04:17:33 --> Config Class Initialized
INFO - 2020-04-14 04:17:33 --> Hooks Class Initialized
DEBUG - 2020-04-14 04:17:33 --> UTF-8 Support Enabled
INFO - 2020-04-14 04:17:33 --> Utf8 Class Initialized
INFO - 2020-04-14 04:17:33 --> URI Class Initialized
INFO - 2020-04-14 04:17:33 --> Router Class Initialized
INFO - 2020-04-14 04:17:33 --> Output Class Initialized
INFO - 2020-04-14 04:17:33 --> Security Class Initialized
DEBUG - 2020-04-14 04:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 04:17:33 --> Input Class Initialized
INFO - 2020-04-14 04:17:33 --> Language Class Initialized
INFO - 2020-04-14 04:17:33 --> Loader Class Initialized
INFO - 2020-04-14 04:17:33 --> Helper loaded: url_helper
INFO - 2020-04-14 04:17:33 --> Helper loaded: form_helper
INFO - 2020-04-14 04:17:33 --> Helper loaded: file_helper
INFO - 2020-04-14 04:17:33 --> Database Driver Class Initialized
DEBUG - 2020-04-14 04:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-14 04:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-14 04:17:33 --> Form Validation Class Initialized
INFO - 2020-04-14 04:17:33 --> Email Class Initialized
INFO - 2020-04-14 04:17:33 --> Controller Class Initialized
ERROR - 2020-04-14 04:17:33 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ')' C:\xampp\htdocs\bonsais\application\models\Mainpagedata.php 17
INFO - 2020-04-14 04:19:43 --> Config Class Initialized
INFO - 2020-04-14 04:19:43 --> Hooks Class Initialized
DEBUG - 2020-04-14 04:19:43 --> UTF-8 Support Enabled
INFO - 2020-04-14 04:19:43 --> Utf8 Class Initialized
INFO - 2020-04-14 04:19:43 --> URI Class Initialized
INFO - 2020-04-14 04:19:43 --> Router Class Initialized
INFO - 2020-04-14 04:19:43 --> Output Class Initialized
INFO - 2020-04-14 04:19:43 --> Security Class Initialized
DEBUG - 2020-04-14 04:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 04:19:43 --> Input Class Initialized
INFO - 2020-04-14 04:19:43 --> Language Class Initialized
INFO - 2020-04-14 04:19:43 --> Loader Class Initialized
INFO - 2020-04-14 04:19:43 --> Helper loaded: url_helper
INFO - 2020-04-14 04:19:43 --> Helper loaded: form_helper
INFO - 2020-04-14 04:19:43 --> Helper loaded: file_helper
INFO - 2020-04-14 04:19:43 --> Database Driver Class Initialized
DEBUG - 2020-04-14 04:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-14 04:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-14 04:19:43 --> Form Validation Class Initialized
INFO - 2020-04-14 04:19:43 --> Email Class Initialized
INFO - 2020-04-14 04:19:43 --> Controller Class Initialized
INFO - 2020-04-14 04:19:43 --> Model "Mainpagedata" initialized
DEBUG - 2020-04-14 04:19:43 --> __construct;, {"cache-control":"no-cache","Postman-Token":"b318af4f-226f-422c-a38f-77f96dab71a6","User-Agent":"PostmanRuntime\/7.3.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=nlau842tqjjdpi774snadji6nmsc42tk","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------270288607836864365987723","content-length":"511","Connection":"close"}
INFO - 2020-04-14 04:19:43 --> Final output sent to browser
DEBUG - 2020-04-14 04:19:43 --> Total execution time: 0.3383
INFO - 2020-04-14 04:20:57 --> Config Class Initialized
INFO - 2020-04-14 04:20:57 --> Hooks Class Initialized
DEBUG - 2020-04-14 04:20:57 --> UTF-8 Support Enabled
INFO - 2020-04-14 04:20:57 --> Utf8 Class Initialized
INFO - 2020-04-14 04:20:57 --> URI Class Initialized
INFO - 2020-04-14 04:20:57 --> Router Class Initialized
INFO - 2020-04-14 04:20:57 --> Output Class Initialized
INFO - 2020-04-14 04:20:58 --> Security Class Initialized
DEBUG - 2020-04-14 04:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 04:20:58 --> Input Class Initialized
INFO - 2020-04-14 04:20:58 --> Language Class Initialized
INFO - 2020-04-14 04:20:58 --> Loader Class Initialized
INFO - 2020-04-14 04:20:58 --> Helper loaded: url_helper
INFO - 2020-04-14 04:20:58 --> Helper loaded: form_helper
INFO - 2020-04-14 04:20:58 --> Helper loaded: file_helper
INFO - 2020-04-14 04:20:58 --> Database Driver Class Initialized
DEBUG - 2020-04-14 04:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-14 04:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-14 04:20:58 --> Form Validation Class Initialized
INFO - 2020-04-14 04:20:58 --> Email Class Initialized
INFO - 2020-04-14 04:20:58 --> Controller Class Initialized
INFO - 2020-04-14 04:20:58 --> Model "Mainpagedata" initialized
DEBUG - 2020-04-14 04:20:58 --> __construct;, {"cache-control":"no-cache","Postman-Token":"2764d3b3-00f8-46f8-977e-ec0da247b699","User-Agent":"PostmanRuntime\/7.3.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=nlau842tqjjdpi774snadji6nmsc42tk","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------072697995304166220908433","content-length":"511","Connection":"close"}
INFO - 2020-04-14 04:20:58 --> Final output sent to browser
DEBUG - 2020-04-14 04:20:58 --> Total execution time: 0.2873
INFO - 2020-04-14 04:21:19 --> Config Class Initialized
INFO - 2020-04-14 04:21:19 --> Hooks Class Initialized
DEBUG - 2020-04-14 04:21:19 --> UTF-8 Support Enabled
INFO - 2020-04-14 04:21:19 --> Utf8 Class Initialized
INFO - 2020-04-14 04:21:19 --> URI Class Initialized
INFO - 2020-04-14 04:21:19 --> Router Class Initialized
INFO - 2020-04-14 04:21:19 --> Output Class Initialized
INFO - 2020-04-14 04:21:19 --> Security Class Initialized
DEBUG - 2020-04-14 04:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 04:21:19 --> Input Class Initialized
INFO - 2020-04-14 04:21:19 --> Language Class Initialized
INFO - 2020-04-14 04:21:19 --> Loader Class Initialized
INFO - 2020-04-14 04:21:19 --> Helper loaded: url_helper
INFO - 2020-04-14 04:21:19 --> Helper loaded: form_helper
INFO - 2020-04-14 04:21:19 --> Helper loaded: file_helper
INFO - 2020-04-14 04:21:19 --> Database Driver Class Initialized
DEBUG - 2020-04-14 04:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-14 04:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-14 04:21:19 --> Form Validation Class Initialized
INFO - 2020-04-14 04:21:19 --> Email Class Initialized
INFO - 2020-04-14 04:21:19 --> Controller Class Initialized
INFO - 2020-04-14 04:21:19 --> Model "Mainpagedata" initialized
DEBUG - 2020-04-14 04:21:19 --> __construct;, {"cache-control":"no-cache","Postman-Token":"36240d24-122d-4c68-8485-96766c5e076c","User-Agent":"PostmanRuntime\/7.3.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=nlau842tqjjdpi774snadji6nmsc42tk","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------974483805625936294125482","content-length":"290","Connection":"close"}
INFO - 2020-04-14 04:21:19 --> Final output sent to browser
DEBUG - 2020-04-14 04:21:19 --> Total execution time: 0.2956
INFO - 2020-04-14 04:30:39 --> Config Class Initialized
INFO - 2020-04-14 04:30:39 --> Hooks Class Initialized
DEBUG - 2020-04-14 04:30:39 --> UTF-8 Support Enabled
INFO - 2020-04-14 04:30:39 --> Utf8 Class Initialized
INFO - 2020-04-14 04:30:39 --> URI Class Initialized
INFO - 2020-04-14 04:30:39 --> Router Class Initialized
INFO - 2020-04-14 04:30:39 --> Output Class Initialized
INFO - 2020-04-14 04:30:39 --> Security Class Initialized
DEBUG - 2020-04-14 04:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 04:30:39 --> Input Class Initialized
INFO - 2020-04-14 04:30:39 --> Language Class Initialized
INFO - 2020-04-14 04:30:39 --> Loader Class Initialized
INFO - 2020-04-14 04:30:39 --> Helper loaded: url_helper
INFO - 2020-04-14 04:30:39 --> Helper loaded: form_helper
INFO - 2020-04-14 04:30:39 --> Helper loaded: file_helper
INFO - 2020-04-14 04:30:39 --> Database Driver Class Initialized
DEBUG - 2020-04-14 04:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-14 04:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-14 04:30:39 --> Form Validation Class Initialized
INFO - 2020-04-14 04:30:39 --> Email Class Initialized
INFO - 2020-04-14 04:30:39 --> Controller Class Initialized
INFO - 2020-04-14 04:30:39 --> Model "Mainpagedata" initialized
DEBUG - 2020-04-14 04:30:39 --> __construct;, {"cache-control":"no-cache","Postman-Token":"dfbae1e9-cd6a-4bb2-b2f4-918f06e1423b","User-Agent":"PostmanRuntime\/7.3.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=nlau842tqjjdpi774snadji6nmsc42tk","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------207406183480176185357990","content-length":"299","Connection":"close"}
INFO - 2020-04-14 04:30:39 --> Final output sent to browser
DEBUG - 2020-04-14 04:30:39 --> Total execution time: 0.2856
INFO - 2020-04-14 04:31:09 --> Config Class Initialized
INFO - 2020-04-14 04:31:09 --> Hooks Class Initialized
DEBUG - 2020-04-14 04:31:09 --> UTF-8 Support Enabled
INFO - 2020-04-14 04:31:09 --> Utf8 Class Initialized
INFO - 2020-04-14 04:31:09 --> URI Class Initialized
INFO - 2020-04-14 04:31:09 --> Router Class Initialized
INFO - 2020-04-14 04:31:09 --> Output Class Initialized
INFO - 2020-04-14 04:31:09 --> Security Class Initialized
DEBUG - 2020-04-14 04:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 04:31:09 --> Input Class Initialized
INFO - 2020-04-14 04:31:09 --> Language Class Initialized
INFO - 2020-04-14 04:31:09 --> Loader Class Initialized
INFO - 2020-04-14 04:31:09 --> Helper loaded: url_helper
INFO - 2020-04-14 04:31:09 --> Helper loaded: form_helper
INFO - 2020-04-14 04:31:09 --> Helper loaded: file_helper
INFO - 2020-04-14 04:31:09 --> Database Driver Class Initialized
DEBUG - 2020-04-14 04:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-14 04:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-14 04:31:09 --> Form Validation Class Initialized
INFO - 2020-04-14 04:31:09 --> Email Class Initialized
INFO - 2020-04-14 04:31:09 --> Controller Class Initialized
INFO - 2020-04-14 04:31:09 --> Model "Mainpagedata" initialized
DEBUG - 2020-04-14 04:31:09 --> __construct;, {"cache-control":"no-cache","Postman-Token":"d9f8823a-e519-40d9-8dde-478c90f2bbae","User-Agent":"PostmanRuntime\/7.3.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=uuckq97dgh8oksc4tt7qjh0i5mfco7pc","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------304266341982226749634324","content-length":"299","Connection":"close"}
INFO - 2020-04-14 04:31:09 --> Final output sent to browser
DEBUG - 2020-04-14 04:31:09 --> Total execution time: 0.2755
INFO - 2020-04-14 04:32:17 --> Config Class Initialized
INFO - 2020-04-14 04:32:17 --> Hooks Class Initialized
DEBUG - 2020-04-14 04:32:17 --> UTF-8 Support Enabled
INFO - 2020-04-14 04:32:17 --> Utf8 Class Initialized
INFO - 2020-04-14 04:32:17 --> URI Class Initialized
INFO - 2020-04-14 04:32:17 --> Router Class Initialized
INFO - 2020-04-14 04:32:17 --> Output Class Initialized
INFO - 2020-04-14 04:32:17 --> Security Class Initialized
DEBUG - 2020-04-14 04:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 04:32:17 --> Input Class Initialized
INFO - 2020-04-14 04:32:17 --> Language Class Initialized
INFO - 2020-04-14 04:32:17 --> Loader Class Initialized
INFO - 2020-04-14 04:32:17 --> Helper loaded: url_helper
INFO - 2020-04-14 04:32:17 --> Helper loaded: form_helper
INFO - 2020-04-14 04:32:17 --> Helper loaded: file_helper
INFO - 2020-04-14 04:32:17 --> Database Driver Class Initialized
DEBUG - 2020-04-14 04:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-14 04:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-14 04:32:17 --> Form Validation Class Initialized
INFO - 2020-04-14 04:32:17 --> Email Class Initialized
INFO - 2020-04-14 04:32:17 --> Controller Class Initialized
INFO - 2020-04-14 04:32:17 --> Model "Mainpagedata" initialized
DEBUG - 2020-04-14 04:32:17 --> __construct;, {"cache-control":"no-cache","Postman-Token":"918f7bd6-63b3-4abd-a6be-dbbf28918d8c","User-Agent":"PostmanRuntime\/7.3.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=uuckq97dgh8oksc4tt7qjh0i5mfco7pc","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------301735631054594258136583","content-length":"299","Connection":"close"}
INFO - 2020-04-14 04:32:17 --> Final output sent to browser
DEBUG - 2020-04-14 04:32:17 --> Total execution time: 0.3318
INFO - 2020-04-14 04:34:56 --> Config Class Initialized
INFO - 2020-04-14 04:34:57 --> Hooks Class Initialized
DEBUG - 2020-04-14 04:34:57 --> UTF-8 Support Enabled
INFO - 2020-04-14 04:34:57 --> Utf8 Class Initialized
INFO - 2020-04-14 04:34:57 --> URI Class Initialized
INFO - 2020-04-14 04:34:57 --> Router Class Initialized
INFO - 2020-04-14 04:34:57 --> Output Class Initialized
INFO - 2020-04-14 04:34:57 --> Security Class Initialized
DEBUG - 2020-04-14 04:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 04:34:57 --> Input Class Initialized
INFO - 2020-04-14 04:34:57 --> Language Class Initialized
INFO - 2020-04-14 04:34:57 --> Loader Class Initialized
INFO - 2020-04-14 04:34:57 --> Helper loaded: url_helper
INFO - 2020-04-14 04:34:57 --> Helper loaded: form_helper
INFO - 2020-04-14 04:34:57 --> Helper loaded: file_helper
INFO - 2020-04-14 04:34:57 --> Database Driver Class Initialized
DEBUG - 2020-04-14 04:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-14 04:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-14 04:34:57 --> Form Validation Class Initialized
INFO - 2020-04-14 04:34:57 --> Email Class Initialized
INFO - 2020-04-14 04:34:57 --> Controller Class Initialized
INFO - 2020-04-14 04:34:57 --> Model "Mainpagedata" initialized
DEBUG - 2020-04-14 04:34:57 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNSIsImVtYWlsIjoiY2hlbmdAb3V0bG9vay5jb20ifQ.PvwOmo_g9Qg_Ld4v1-o-QX1d7ATQNFp4nZDqBONfU_4","cache-control":"no-cache","Postman-Token":"ccc762d6-6ab9-429c-803e-7d15a613d0a4","User-Agent":"PostmanRuntime\/7.3.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=uuckq97dgh8oksc4tt7qjh0i5mfco7pc","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------459059530742474765112317","content-length":"299","Connection":"close"}
ERROR - 2020-04-14 04:34:57 --> Query error: Table 'bonsais.token_record' doesn't exist - Invalid query: SELECT *
FROM `token_record`
WHERE `user_id` = '5'
INFO - 2020-04-14 04:34:57 --> Language file loaded: language/english/db_lang.php
INFO - 2020-04-14 04:35:46 --> Config Class Initialized
INFO - 2020-04-14 04:35:46 --> Hooks Class Initialized
DEBUG - 2020-04-14 04:35:46 --> UTF-8 Support Enabled
INFO - 2020-04-14 04:35:46 --> Utf8 Class Initialized
INFO - 2020-04-14 04:35:46 --> URI Class Initialized
INFO - 2020-04-14 04:35:46 --> Router Class Initialized
INFO - 2020-04-14 04:35:46 --> Output Class Initialized
INFO - 2020-04-14 04:35:46 --> Security Class Initialized
DEBUG - 2020-04-14 04:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 04:35:46 --> Input Class Initialized
INFO - 2020-04-14 04:35:46 --> Language Class Initialized
INFO - 2020-04-14 04:35:46 --> Loader Class Initialized
INFO - 2020-04-14 04:35:46 --> Helper loaded: url_helper
INFO - 2020-04-14 04:35:46 --> Helper loaded: form_helper
INFO - 2020-04-14 04:35:46 --> Helper loaded: file_helper
INFO - 2020-04-14 04:35:46 --> Database Driver Class Initialized
DEBUG - 2020-04-14 04:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-14 04:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-14 04:35:46 --> Form Validation Class Initialized
INFO - 2020-04-14 04:35:46 --> Email Class Initialized
INFO - 2020-04-14 04:35:46 --> Controller Class Initialized
INFO - 2020-04-14 04:35:46 --> Model "Mainpagedata" initialized
DEBUG - 2020-04-14 04:35:46 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNSIsImVtYWlsIjoiY2hlbmdAb3V0bG9vay5jb20ifQ.PvwOmo_g9Qg_Ld4v1-o-QX1d7ATQNFp4nZDqBONfU_4","cache-control":"no-cache","Postman-Token":"2f6ef0c4-d4db-4da8-b8f3-eaaefebb10a5","User-Agent":"PostmanRuntime\/7.3.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=uuckq97dgh8oksc4tt7qjh0i5mfco7pc","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------660297136083859946292303","content-length":"299","Connection":"close"}
ERROR - 2020-04-14 04:35:46 --> Severity: Notice --> Undefined variable: de C:\xampp\htdocs\bonsais\application\models\Mainpagedata.php 144
ERROR - 2020-04-14 04:35:46 --> Query error: Unknown column 'device_token' in 'field list' - Invalid query: INSERT INTO `token_records` (`user_id`, `device_token`) VALUES ('5', NULL)
INFO - 2020-04-14 04:35:46 --> Language file loaded: language/english/db_lang.php
INFO - 2020-04-14 04:38:52 --> Config Class Initialized
INFO - 2020-04-14 04:38:52 --> Hooks Class Initialized
DEBUG - 2020-04-14 04:38:52 --> UTF-8 Support Enabled
INFO - 2020-04-14 04:38:52 --> Utf8 Class Initialized
INFO - 2020-04-14 04:38:52 --> URI Class Initialized
INFO - 2020-04-14 04:38:52 --> Router Class Initialized
INFO - 2020-04-14 04:38:52 --> Output Class Initialized
INFO - 2020-04-14 04:38:52 --> Security Class Initialized
DEBUG - 2020-04-14 04:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 04:38:52 --> Input Class Initialized
INFO - 2020-04-14 04:38:52 --> Language Class Initialized
INFO - 2020-04-14 04:38:53 --> Loader Class Initialized
INFO - 2020-04-14 04:38:53 --> Helper loaded: url_helper
INFO - 2020-04-14 04:38:53 --> Helper loaded: form_helper
INFO - 2020-04-14 04:38:53 --> Helper loaded: file_helper
INFO - 2020-04-14 04:38:53 --> Database Driver Class Initialized
DEBUG - 2020-04-14 04:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-14 04:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-14 04:38:53 --> Form Validation Class Initialized
INFO - 2020-04-14 04:38:53 --> Email Class Initialized
INFO - 2020-04-14 04:38:53 --> Controller Class Initialized
INFO - 2020-04-14 04:38:53 --> Model "Mainpagedata" initialized
DEBUG - 2020-04-14 04:38:53 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNSIsImVtYWlsIjoiY2hlbmdAb3V0bG9vay5jb20ifQ.PvwOmo_g9Qg_Ld4v1-o-QX1d7ATQNFp4nZDqBONfU_4","cache-control":"no-cache","Postman-Token":"f9eea724-3d7c-4877-aa33-8efc12f08a7f","User-Agent":"PostmanRuntime\/7.3.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=5hvveokogriueg4o8cg9evhvehtvlj23","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------730710736667225833012329","content-length":"299","Connection":"close"}
INFO - 2020-04-14 04:38:53 --> Final output sent to browser
DEBUG - 2020-04-14 04:38:53 --> Total execution time: 0.2859
INFO - 2020-04-14 04:39:19 --> Config Class Initialized
INFO - 2020-04-14 04:39:19 --> Hooks Class Initialized
DEBUG - 2020-04-14 04:39:19 --> UTF-8 Support Enabled
INFO - 2020-04-14 04:39:19 --> Utf8 Class Initialized
INFO - 2020-04-14 04:39:19 --> URI Class Initialized
INFO - 2020-04-14 04:39:19 --> Router Class Initialized
INFO - 2020-04-14 04:39:19 --> Output Class Initialized
INFO - 2020-04-14 04:39:19 --> Security Class Initialized
DEBUG - 2020-04-14 04:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 04:39:19 --> Input Class Initialized
INFO - 2020-04-14 04:39:19 --> Language Class Initialized
INFO - 2020-04-14 04:39:19 --> Loader Class Initialized
INFO - 2020-04-14 04:39:19 --> Helper loaded: url_helper
INFO - 2020-04-14 04:39:19 --> Helper loaded: form_helper
INFO - 2020-04-14 04:39:19 --> Helper loaded: file_helper
INFO - 2020-04-14 04:39:19 --> Database Driver Class Initialized
DEBUG - 2020-04-14 04:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-14 04:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-14 04:39:19 --> Form Validation Class Initialized
INFO - 2020-04-14 04:39:19 --> Email Class Initialized
INFO - 2020-04-14 04:39:19 --> Controller Class Initialized
INFO - 2020-04-14 04:39:19 --> Model "Mainpagedata" initialized
DEBUG - 2020-04-14 04:39:19 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNSIsImVtYWlsIjoiY2hlbmdAb3V0bG9vay5jb20ifQ.PvwOmo_g9Qg_Ld4v1-o-QX1d7ATQNFp4nZDqBONfU_4","cache-control":"no-cache","Postman-Token":"7ba1b418-03c7-453b-9174-c9468f87bdc9","User-Agent":"PostmanRuntime\/7.3.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=5hvveokogriueg4o8cg9evhvehtvlj23","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------388449393258745368013755","content-length":"155","Connection":"close"}
ERROR - 2020-04-14 04:39:19 --> Severity: Notice --> Undefined index: token C:\xampp\htdocs\bonsais\application\models\Mainpagedata.php 132
INFO - 2020-04-14 04:39:19 --> Final output sent to browser
DEBUG - 2020-04-14 04:39:19 --> Total execution time: 0.2996
INFO - 2020-04-14 04:39:50 --> Config Class Initialized
INFO - 2020-04-14 04:39:50 --> Hooks Class Initialized
DEBUG - 2020-04-14 04:39:51 --> UTF-8 Support Enabled
INFO - 2020-04-14 04:39:51 --> Utf8 Class Initialized
INFO - 2020-04-14 04:39:51 --> URI Class Initialized
INFO - 2020-04-14 04:39:51 --> Router Class Initialized
INFO - 2020-04-14 04:39:51 --> Output Class Initialized
INFO - 2020-04-14 04:39:51 --> Security Class Initialized
DEBUG - 2020-04-14 04:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 04:39:51 --> Input Class Initialized
INFO - 2020-04-14 04:39:51 --> Language Class Initialized
INFO - 2020-04-14 04:39:51 --> Loader Class Initialized
INFO - 2020-04-14 04:39:51 --> Helper loaded: url_helper
INFO - 2020-04-14 04:39:51 --> Helper loaded: form_helper
INFO - 2020-04-14 04:39:51 --> Helper loaded: file_helper
INFO - 2020-04-14 04:39:51 --> Database Driver Class Initialized
DEBUG - 2020-04-14 04:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-14 04:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-14 04:39:51 --> Form Validation Class Initialized
INFO - 2020-04-14 04:39:51 --> Email Class Initialized
INFO - 2020-04-14 04:39:51 --> Controller Class Initialized
INFO - 2020-04-14 04:39:51 --> Model "Mainpagedata" initialized
DEBUG - 2020-04-14 04:39:51 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNSIsImVtYWlsIjoiY2hlbmdAb3V0bG9vay5jb20ifQ.PvwOmo_g9Qg_Ld4v1-o-QX1d7ATQNFp4nZDqBONfU_4","cache-control":"no-cache","Postman-Token":"c8fa8c5e-68cf-433f-913c-5768fbbee04f","User-Agent":"PostmanRuntime\/7.3.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=5hvveokogriueg4o8cg9evhvehtvlj23","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------602159855496247964706249","content-length":"299","Connection":"close"}
INFO - 2020-04-14 04:39:51 --> Final output sent to browser
DEBUG - 2020-04-14 04:39:51 --> Total execution time: 0.2805
INFO - 2020-04-14 04:46:08 --> Config Class Initialized
INFO - 2020-04-14 04:46:08 --> Hooks Class Initialized
DEBUG - 2020-04-14 04:46:08 --> UTF-8 Support Enabled
INFO - 2020-04-14 04:46:08 --> Utf8 Class Initialized
INFO - 2020-04-14 04:46:08 --> URI Class Initialized
INFO - 2020-04-14 04:46:08 --> Router Class Initialized
INFO - 2020-04-14 04:46:08 --> Output Class Initialized
INFO - 2020-04-14 04:46:08 --> Security Class Initialized
DEBUG - 2020-04-14 04:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 04:46:08 --> Input Class Initialized
INFO - 2020-04-14 04:46:08 --> Language Class Initialized
INFO - 2020-04-14 04:46:08 --> Loader Class Initialized
INFO - 2020-04-14 04:46:08 --> Helper loaded: url_helper
INFO - 2020-04-14 04:46:08 --> Helper loaded: form_helper
INFO - 2020-04-14 04:46:08 --> Helper loaded: file_helper
INFO - 2020-04-14 04:46:08 --> Database Driver Class Initialized
DEBUG - 2020-04-14 04:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-14 04:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-14 04:46:08 --> Form Validation Class Initialized
INFO - 2020-04-14 04:46:08 --> Email Class Initialized
INFO - 2020-04-14 04:46:08 --> Controller Class Initialized
INFO - 2020-04-14 04:46:08 --> Model "Mainpagedata" initialized
DEBUG - 2020-04-14 04:46:08 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNSIsImVtYWlsIjoiY2hlbmdAb3V0bG9vay5jb20ifQ.PvwOmo_g9Qg_Ld4v1-o-QX1d7ATQNFp4nZDqBONfU_4","cache-control":"no-cache","Postman-Token":"5cacbfa4-6655-41fe-a00b-571628d849e1","User-Agent":"PostmanRuntime\/7.3.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=5hvveokogriueg4o8cg9evhvehtvlj23","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------465988649888612417723479","content-length":"405","Connection":"close"}
INFO - 2020-04-14 04:46:08 --> Final output sent to browser
DEBUG - 2020-04-14 04:46:08 --> Total execution time: 0.2785
INFO - 2020-04-14 04:48:47 --> Config Class Initialized
INFO - 2020-04-14 04:48:47 --> Hooks Class Initialized
DEBUG - 2020-04-14 04:48:47 --> UTF-8 Support Enabled
INFO - 2020-04-14 04:48:47 --> Utf8 Class Initialized
INFO - 2020-04-14 04:48:47 --> URI Class Initialized
INFO - 2020-04-14 04:48:47 --> Router Class Initialized
INFO - 2020-04-14 04:48:47 --> Output Class Initialized
INFO - 2020-04-14 04:48:47 --> Security Class Initialized
DEBUG - 2020-04-14 04:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 04:48:47 --> Input Class Initialized
INFO - 2020-04-14 04:48:47 --> Language Class Initialized
INFO - 2020-04-14 04:48:47 --> Loader Class Initialized
INFO - 2020-04-14 04:48:47 --> Helper loaded: url_helper
INFO - 2020-04-14 04:48:47 --> Helper loaded: form_helper
INFO - 2020-04-14 04:48:47 --> Helper loaded: file_helper
INFO - 2020-04-14 04:48:47 --> Database Driver Class Initialized
DEBUG - 2020-04-14 04:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-14 04:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-14 04:48:47 --> Form Validation Class Initialized
INFO - 2020-04-14 04:48:47 --> Email Class Initialized
INFO - 2020-04-14 04:48:47 --> Controller Class Initialized
INFO - 2020-04-14 04:48:47 --> Model "Mainpagedata" initialized
DEBUG - 2020-04-14 04:48:47 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNSIsImVtYWlsIjoiY2hlbmdAb3V0bG9vay5jb20ifQ.PvwOmo_g9Qg_Ld4v1-o-QX1d7ATQNFp4nZDqBONfU_4","Content-Type":"multipart\/form-data; boundary=--------------------------512494830682785933154101","cache-control":"no-cache","Postman-Token":"285a2675-2893-4945-8508-3997e41901f0","User-Agent":"PostmanRuntime\/7.3.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=rs512r8k9q5tkqcgoiemlnjunbed4aou","accept-encoding":"gzip, deflate","content-length":"523","Connection":"close"}
INFO - 2020-04-14 04:48:47 --> Final output sent to browser
DEBUG - 2020-04-14 04:48:47 --> Total execution time: 0.2889
INFO - 2020-04-14 04:50:57 --> Config Class Initialized
INFO - 2020-04-14 04:50:57 --> Hooks Class Initialized
DEBUG - 2020-04-14 04:50:57 --> UTF-8 Support Enabled
INFO - 2020-04-14 04:50:57 --> Utf8 Class Initialized
INFO - 2020-04-14 04:50:57 --> URI Class Initialized
INFO - 2020-04-14 04:50:57 --> Router Class Initialized
INFO - 2020-04-14 04:50:57 --> Output Class Initialized
INFO - 2020-04-14 04:50:57 --> Security Class Initialized
DEBUG - 2020-04-14 04:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 04:50:57 --> Input Class Initialized
INFO - 2020-04-14 04:50:57 --> Language Class Initialized
INFO - 2020-04-14 04:50:57 --> Loader Class Initialized
INFO - 2020-04-14 04:50:57 --> Helper loaded: url_helper
INFO - 2020-04-14 04:50:57 --> Helper loaded: form_helper
INFO - 2020-04-14 04:50:57 --> Helper loaded: file_helper
INFO - 2020-04-14 04:50:57 --> Database Driver Class Initialized
DEBUG - 2020-04-14 04:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-14 04:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-14 04:50:58 --> Form Validation Class Initialized
INFO - 2020-04-14 04:50:58 --> Email Class Initialized
INFO - 2020-04-14 04:50:58 --> Controller Class Initialized
INFO - 2020-04-14 04:50:58 --> Model "Mainpagedata" initialized
DEBUG - 2020-04-14 04:50:58 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNSIsImVtYWlsIjoiY2hlbmdAb3V0bG9vay5jb20ifQ.PvwOmo_g9Qg_Ld4v1-o-QX1d7ATQNFp4nZDqBONfU_4","Content-Type":"multipart\/form-data; boundary=--------------------------251465462781824368993974","cache-control":"no-cache","Postman-Token":"e4a0391f-69aa-4ff8-a776-31a9ffe31e38","User-Agent":"PostmanRuntime\/7.3.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=rs512r8k9q5tkqcgoiemlnjunbed4aou","accept-encoding":"gzip, deflate","content-length":"741","Connection":"close"}
INFO - 2020-04-14 04:50:58 --> Final output sent to browser
DEBUG - 2020-04-14 04:50:58 --> Total execution time: 0.2826
INFO - 2020-04-14 06:24:06 --> Config Class Initialized
INFO - 2020-04-14 06:24:06 --> Hooks Class Initialized
DEBUG - 2020-04-14 06:24:06 --> UTF-8 Support Enabled
INFO - 2020-04-14 06:24:06 --> Utf8 Class Initialized
INFO - 2020-04-14 06:24:06 --> URI Class Initialized
INFO - 2020-04-14 06:24:06 --> Router Class Initialized
INFO - 2020-04-14 06:24:06 --> Output Class Initialized
INFO - 2020-04-14 06:24:06 --> Security Class Initialized
DEBUG - 2020-04-14 06:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 06:24:06 --> Input Class Initialized
INFO - 2020-04-14 06:24:06 --> Language Class Initialized
INFO - 2020-04-14 06:24:08 --> Loader Class Initialized
INFO - 2020-04-14 06:24:08 --> Helper loaded: url_helper
INFO - 2020-04-14 06:24:08 --> Helper loaded: form_helper
INFO - 2020-04-14 06:24:08 --> Helper loaded: file_helper
INFO - 2020-04-14 06:24:08 --> Database Driver Class Initialized
DEBUG - 2020-04-14 06:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-14 06:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-14 06:24:08 --> Form Validation Class Initialized
INFO - 2020-04-14 06:24:08 --> Email Class Initialized
INFO - 2020-04-14 06:24:08 --> Controller Class Initialized
INFO - 2020-04-14 06:24:08 --> Model "Mainpagedata" initialized
DEBUG - 2020-04-14 06:24:08 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNSIsImVtYWlsIjoiY2hlbmdAb3V0bG9vay5jb20ifQ.PvwOmo_g9Qg_Ld4v1-o-QX1d7ATQNFp4nZDqBONfU_4","Content-Type":"multipart\/form-data; boundary=--------------------------394909617587880643968633","cache-control":"no-cache","Postman-Token":"5365595f-a3f5-4e28-819b-698ea702961b","User-Agent":"PostmanRuntime\/7.3.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=rs512r8k9q5tkqcgoiemlnjunbed4aou","accept-encoding":"gzip, deflate","content-length":"741","Connection":"close"}
INFO - 2020-04-14 06:24:08 --> Final output sent to browser
DEBUG - 2020-04-14 06:24:08 --> Total execution time: 1.9723
INFO - 2020-04-14 06:43:24 --> Config Class Initialized
INFO - 2020-04-14 06:43:24 --> Hooks Class Initialized
DEBUG - 2020-04-14 06:43:24 --> UTF-8 Support Enabled
INFO - 2020-04-14 06:43:24 --> Utf8 Class Initialized
INFO - 2020-04-14 06:43:24 --> URI Class Initialized
INFO - 2020-04-14 06:43:24 --> Router Class Initialized
INFO - 2020-04-14 06:43:25 --> Output Class Initialized
INFO - 2020-04-14 06:43:25 --> Security Class Initialized
DEBUG - 2020-04-14 06:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 06:43:25 --> Input Class Initialized
INFO - 2020-04-14 06:43:25 --> Language Class Initialized
INFO - 2020-04-14 06:43:25 --> Loader Class Initialized
INFO - 2020-04-14 06:43:25 --> Helper loaded: url_helper
INFO - 2020-04-14 06:43:25 --> Helper loaded: form_helper
INFO - 2020-04-14 06:43:25 --> Helper loaded: file_helper
INFO - 2020-04-14 06:43:25 --> Database Driver Class Initialized
DEBUG - 2020-04-14 06:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-14 06:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-14 06:43:25 --> Form Validation Class Initialized
INFO - 2020-04-14 06:43:25 --> Email Class Initialized
INFO - 2020-04-14 06:43:25 --> Controller Class Initialized
INFO - 2020-04-14 06:43:25 --> Model "Mainpagedata" initialized
DEBUG - 2020-04-14 06:43:25 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNSIsImVtYWlsIjoiY2hlbmdAb3V0bG9vay5jb20ifQ.PvwOmo_g9Qg_Ld4v1-o-QX1d7ATQNFp4nZDqBONfU_4","cache-control":"no-cache","Postman-Token":"e604e3c2-9f15-4324-bb3c-aba168877568","User-Agent":"PostmanRuntime\/7.3.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=iia2hdb6vdt7pupr6h7iqccuc8tm4pdd","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------846776112354238147591866","content-length":"155","Connection":"close"}
ERROR - 2020-04-14 06:43:25 --> Severity: error --> Exception: Too few arguments to function Mainpagedata::saveDeviceToken(), 1 passed in C:\xampp\htdocs\bonsais\application\controllers\Webservice.php on line 168 and exactly 2 expected C:\xampp\htdocs\bonsais\application\models\Mainpagedata.php 130
INFO - 2020-04-14 06:45:00 --> Config Class Initialized
INFO - 2020-04-14 06:45:00 --> Hooks Class Initialized
DEBUG - 2020-04-14 06:45:00 --> UTF-8 Support Enabled
INFO - 2020-04-14 06:45:00 --> Utf8 Class Initialized
INFO - 2020-04-14 06:45:01 --> URI Class Initialized
INFO - 2020-04-14 06:45:01 --> Router Class Initialized
INFO - 2020-04-14 06:45:01 --> Output Class Initialized
INFO - 2020-04-14 06:45:01 --> Security Class Initialized
DEBUG - 2020-04-14 06:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 06:45:01 --> Input Class Initialized
INFO - 2020-04-14 06:45:01 --> Language Class Initialized
INFO - 2020-04-14 06:45:01 --> Loader Class Initialized
INFO - 2020-04-14 06:45:01 --> Helper loaded: url_helper
INFO - 2020-04-14 06:45:01 --> Helper loaded: form_helper
INFO - 2020-04-14 06:45:01 --> Helper loaded: file_helper
INFO - 2020-04-14 06:45:01 --> Database Driver Class Initialized
DEBUG - 2020-04-14 06:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-14 06:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-14 06:45:01 --> Form Validation Class Initialized
INFO - 2020-04-14 06:45:01 --> Email Class Initialized
INFO - 2020-04-14 06:45:01 --> Controller Class Initialized
INFO - 2020-04-14 06:45:01 --> Model "Mainpagedata" initialized
DEBUG - 2020-04-14 06:45:01 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNSIsImVtYWlsIjoiY2hlbmdAb3V0bG9vay5jb20ifQ.PvwOmo_g9Qg_Ld4v1-o-QX1d7ATQNFp4nZDqBONfU_4","cache-control":"no-cache","Postman-Token":"f6cea9d0-53be-4a6a-b799-aee6b0d3d6cd","User-Agent":"PostmanRuntime\/7.3.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=u595p9n7kkmhko4mbc8s9jinp651uj4j","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------053795540297121575292974","content-length":"155","Connection":"close"}
ERROR - 2020-04-14 06:45:01 --> Severity: error --> Exception: Too few arguments to function Mainpagedata::saveDeviceToken(), 1 passed in C:\xampp\htdocs\bonsais\application\controllers\Webservice.php on line 168 and exactly 2 expected C:\xampp\htdocs\bonsais\application\models\Mainpagedata.php 130
INFO - 2020-04-14 06:45:20 --> Config Class Initialized
INFO - 2020-04-14 06:45:20 --> Hooks Class Initialized
DEBUG - 2020-04-14 06:45:20 --> UTF-8 Support Enabled
INFO - 2020-04-14 06:45:20 --> Utf8 Class Initialized
INFO - 2020-04-14 06:45:20 --> URI Class Initialized
INFO - 2020-04-14 06:45:20 --> Router Class Initialized
INFO - 2020-04-14 06:45:20 --> Output Class Initialized
INFO - 2020-04-14 06:45:20 --> Security Class Initialized
DEBUG - 2020-04-14 06:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 06:45:20 --> Input Class Initialized
INFO - 2020-04-14 06:45:20 --> Language Class Initialized
INFO - 2020-04-14 06:45:20 --> Loader Class Initialized
INFO - 2020-04-14 06:45:20 --> Helper loaded: url_helper
INFO - 2020-04-14 06:45:20 --> Helper loaded: form_helper
INFO - 2020-04-14 06:45:20 --> Helper loaded: file_helper
INFO - 2020-04-14 06:45:20 --> Database Driver Class Initialized
DEBUG - 2020-04-14 06:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-14 06:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-14 06:45:20 --> Form Validation Class Initialized
INFO - 2020-04-14 06:45:20 --> Email Class Initialized
INFO - 2020-04-14 06:45:20 --> Controller Class Initialized
INFO - 2020-04-14 06:45:20 --> Model "Mainpagedata" initialized
DEBUG - 2020-04-14 06:45:20 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNSIsImVtYWlsIjoiY2hlbmdAb3V0bG9vay5jb20ifQ.PvwOmo_g9Qg_Ld4v1-o-QX1d7ATQNFp4nZDqBONfU_4","cache-control":"no-cache","Postman-Token":"1e4f5bc7-c23f-4883-8db1-4d9d75cb93b6","User-Agent":"PostmanRuntime\/7.3.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=u595p9n7kkmhko4mbc8s9jinp651uj4j","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------556501626202937996359702","content-length":"155","Connection":"close"}
ERROR - 2020-04-14 06:45:20 --> Severity: error --> Exception: Too few arguments to function Mainpagedata::saveDeviceToken(), 1 passed in C:\xampp\htdocs\bonsais\application\controllers\Webservice.php on line 168 and exactly 2 expected C:\xampp\htdocs\bonsais\application\models\Mainpagedata.php 130
INFO - 2020-04-14 06:47:22 --> Config Class Initialized
INFO - 2020-04-14 06:47:22 --> Hooks Class Initialized
DEBUG - 2020-04-14 06:47:22 --> UTF-8 Support Enabled
INFO - 2020-04-14 06:47:22 --> Utf8 Class Initialized
INFO - 2020-04-14 06:47:22 --> URI Class Initialized
INFO - 2020-04-14 06:47:22 --> Router Class Initialized
INFO - 2020-04-14 06:47:22 --> Output Class Initialized
INFO - 2020-04-14 06:47:22 --> Security Class Initialized
DEBUG - 2020-04-14 06:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 06:47:22 --> Input Class Initialized
INFO - 2020-04-14 06:47:22 --> Language Class Initialized
INFO - 2020-04-14 06:47:22 --> Loader Class Initialized
INFO - 2020-04-14 06:47:22 --> Helper loaded: url_helper
INFO - 2020-04-14 06:47:22 --> Helper loaded: form_helper
INFO - 2020-04-14 06:47:22 --> Helper loaded: file_helper
INFO - 2020-04-14 06:47:22 --> Database Driver Class Initialized
DEBUG - 2020-04-14 06:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-14 06:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-14 06:47:22 --> Form Validation Class Initialized
INFO - 2020-04-14 06:47:22 --> Email Class Initialized
INFO - 2020-04-14 06:47:22 --> Controller Class Initialized
INFO - 2020-04-14 06:47:22 --> Model "Mainpagedata" initialized
DEBUG - 2020-04-14 06:47:22 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNSIsImVtYWlsIjoiY2hlbmdAb3V0bG9vay5jb20ifQ.PvwOmo_g9Qg_Ld4v1-o-QX1d7ATQNFp4nZDqBONfU_4","cache-control":"no-cache","Postman-Token":"cd9d11ed-4ea9-4473-b886-c213ba99dcc4","User-Agent":"PostmanRuntime\/7.3.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=u595p9n7kkmhko4mbc8s9jinp651uj4j","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------994703898898210715828720","content-length":"155","Connection":"close"}
ERROR - 2020-04-14 06:47:22 --> Severity: error --> Exception: Too few arguments to function Mainpagedata::saveDeviceToken(), 1 passed in C:\xampp\htdocs\bonsais\application\controllers\Webservice.php on line 168 and exactly 2 expected C:\xampp\htdocs\bonsais\application\models\Mainpagedata.php 130
INFO - 2020-04-14 06:48:11 --> Config Class Initialized
INFO - 2020-04-14 06:48:11 --> Hooks Class Initialized
DEBUG - 2020-04-14 06:48:11 --> UTF-8 Support Enabled
INFO - 2020-04-14 06:48:11 --> Utf8 Class Initialized
INFO - 2020-04-14 06:48:11 --> URI Class Initialized
INFO - 2020-04-14 06:48:11 --> Router Class Initialized
INFO - 2020-04-14 06:48:11 --> Output Class Initialized
INFO - 2020-04-14 06:48:11 --> Security Class Initialized
DEBUG - 2020-04-14 06:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-14 06:48:11 --> Input Class Initialized
INFO - 2020-04-14 06:48:11 --> Language Class Initialized
INFO - 2020-04-14 06:48:11 --> Loader Class Initialized
INFO - 2020-04-14 06:48:11 --> Helper loaded: url_helper
INFO - 2020-04-14 06:48:11 --> Helper loaded: form_helper
INFO - 2020-04-14 06:48:11 --> Helper loaded: file_helper
INFO - 2020-04-14 06:48:11 --> Database Driver Class Initialized
DEBUG - 2020-04-14 06:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-04-14 06:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-04-14 06:48:11 --> Form Validation Class Initialized
INFO - 2020-04-14 06:48:11 --> Email Class Initialized
INFO - 2020-04-14 06:48:11 --> Controller Class Initialized
INFO - 2020-04-14 06:48:11 --> Model "Mainpagedata" initialized
DEBUG - 2020-04-14 06:48:11 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiNSIsImVtYWlsIjoiY2hlbmdAb3V0bG9vay5jb20ifQ.PvwOmo_g9Qg_Ld4v1-o-QX1d7ATQNFp4nZDqBONfU_4","cache-control":"no-cache","Postman-Token":"0fb3b1f5-cfce-4197-a224-18e63a2faac4","User-Agent":"PostmanRuntime\/7.3.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=u595p9n7kkmhko4mbc8s9jinp651uj4j","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------869931006413762322037224","content-length":"155","Connection":"close"}
INFO - 2020-04-14 06:48:11 --> Final output sent to browser
DEBUG - 2020-04-14 06:48:11 --> Total execution time: 0.3043
