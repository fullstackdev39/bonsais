<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-09 17:03:00 --> Config Class Initialized
INFO - 2020-02-09 17:03:00 --> Hooks Class Initialized
DEBUG - 2020-02-09 17:03:00 --> UTF-8 Support Enabled
INFO - 2020-02-09 17:03:00 --> Utf8 Class Initialized
INFO - 2020-02-09 17:03:00 --> URI Class Initialized
DEBUG - 2020-02-09 17:03:00 --> No URI present. Default controller set.
INFO - 2020-02-09 17:03:00 --> Router Class Initialized
INFO - 2020-02-09 17:03:00 --> Output Class Initialized
INFO - 2020-02-09 17:03:00 --> Security Class Initialized
DEBUG - 2020-02-09 17:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 17:03:00 --> Input Class Initialized
INFO - 2020-02-09 17:03:00 --> Language Class Initialized
INFO - 2020-02-09 17:03:00 --> Loader Class Initialized
INFO - 2020-02-09 17:03:00 --> Helper loaded: url_helper
INFO - 2020-02-09 17:03:00 --> Helper loaded: form_helper
INFO - 2020-02-09 17:03:00 --> Helper loaded: file_helper
INFO - 2020-02-09 17:03:00 --> Database Driver Class Initialized
DEBUG - 2020-02-09 17:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 17:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 17:03:00 --> Form Validation Class Initialized
INFO - 2020-02-09 17:03:00 --> Email Class Initialized
INFO - 2020-02-09 17:03:00 --> Controller Class Initialized
INFO - 2020-02-09 17:03:00 --> Model "Adminmodel" initialized
INFO - 2020-02-09 17:03:00 --> File loaded: C:\xampp\htdocs\Flegigs\application\views\login.php
INFO - 2020-02-09 17:03:00 --> Final output sent to browser
DEBUG - 2020-02-09 17:03:00 --> Total execution time: 0.2527
INFO - 2020-02-09 17:03:36 --> Config Class Initialized
INFO - 2020-02-09 17:03:36 --> Hooks Class Initialized
DEBUG - 2020-02-09 17:03:37 --> UTF-8 Support Enabled
INFO - 2020-02-09 17:03:37 --> Utf8 Class Initialized
INFO - 2020-02-09 17:03:37 --> URI Class Initialized
INFO - 2020-02-09 17:03:37 --> Router Class Initialized
INFO - 2020-02-09 17:03:37 --> Output Class Initialized
INFO - 2020-02-09 17:03:37 --> Security Class Initialized
DEBUG - 2020-02-09 17:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 17:03:37 --> Input Class Initialized
INFO - 2020-02-09 17:03:37 --> Language Class Initialized
INFO - 2020-02-09 17:03:37 --> Loader Class Initialized
INFO - 2020-02-09 17:03:37 --> Helper loaded: url_helper
INFO - 2020-02-09 17:03:37 --> Helper loaded: form_helper
INFO - 2020-02-09 17:03:37 --> Helper loaded: file_helper
INFO - 2020-02-09 17:03:37 --> Database Driver Class Initialized
DEBUG - 2020-02-09 17:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 17:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 17:03:37 --> Form Validation Class Initialized
INFO - 2020-02-09 17:03:37 --> Email Class Initialized
INFO - 2020-02-09 17:03:37 --> Controller Class Initialized
INFO - 2020-02-09 17:03:37 --> Model "Adminmodel" initialized
INFO - 2020-02-09 17:03:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-02-09 17:03:37 --> Config Class Initialized
INFO - 2020-02-09 17:03:37 --> Hooks Class Initialized
DEBUG - 2020-02-09 17:03:37 --> UTF-8 Support Enabled
INFO - 2020-02-09 17:03:37 --> Utf8 Class Initialized
INFO - 2020-02-09 17:03:37 --> URI Class Initialized
DEBUG - 2020-02-09 17:03:37 --> No URI present. Default controller set.
INFO - 2020-02-09 17:03:37 --> Router Class Initialized
INFO - 2020-02-09 17:03:37 --> Output Class Initialized
INFO - 2020-02-09 17:03:37 --> Security Class Initialized
DEBUG - 2020-02-09 17:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 17:03:37 --> Input Class Initialized
INFO - 2020-02-09 17:03:37 --> Language Class Initialized
INFO - 2020-02-09 17:03:37 --> Loader Class Initialized
INFO - 2020-02-09 17:03:37 --> Helper loaded: url_helper
INFO - 2020-02-09 17:03:37 --> Helper loaded: form_helper
INFO - 2020-02-09 17:03:37 --> Helper loaded: file_helper
INFO - 2020-02-09 17:03:37 --> Database Driver Class Initialized
DEBUG - 2020-02-09 17:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 17:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 17:03:37 --> Form Validation Class Initialized
INFO - 2020-02-09 17:03:37 --> Email Class Initialized
INFO - 2020-02-09 17:03:37 --> Controller Class Initialized
INFO - 2020-02-09 17:03:37 --> Model "Adminmodel" initialized
INFO - 2020-02-09 17:03:37 --> File loaded: C:\xampp\htdocs\Flegigs\application\views\login.php
INFO - 2020-02-09 17:03:37 --> Final output sent to browser
DEBUG - 2020-02-09 17:03:37 --> Total execution time: 0.2400
INFO - 2020-02-09 17:06:34 --> Config Class Initialized
INFO - 2020-02-09 17:06:34 --> Hooks Class Initialized
DEBUG - 2020-02-09 17:06:34 --> UTF-8 Support Enabled
INFO - 2020-02-09 17:06:34 --> Utf8 Class Initialized
INFO - 2020-02-09 17:06:34 --> URI Class Initialized
INFO - 2020-02-09 17:06:34 --> Router Class Initialized
INFO - 2020-02-09 17:06:34 --> Output Class Initialized
INFO - 2020-02-09 17:06:34 --> Security Class Initialized
DEBUG - 2020-02-09 17:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 17:06:34 --> Input Class Initialized
INFO - 2020-02-09 17:06:34 --> Language Class Initialized
INFO - 2020-02-09 17:06:34 --> Loader Class Initialized
INFO - 2020-02-09 17:06:34 --> Helper loaded: url_helper
INFO - 2020-02-09 17:06:34 --> Helper loaded: form_helper
INFO - 2020-02-09 17:06:34 --> Helper loaded: file_helper
INFO - 2020-02-09 17:06:34 --> Database Driver Class Initialized
DEBUG - 2020-02-09 17:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 17:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 17:06:34 --> Form Validation Class Initialized
INFO - 2020-02-09 17:06:34 --> Email Class Initialized
INFO - 2020-02-09 17:06:34 --> Controller Class Initialized
INFO - 2020-02-09 17:06:34 --> Model "Adminmodel" initialized
INFO - 2020-02-09 17:06:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-02-09 17:07:27 --> Config Class Initialized
INFO - 2020-02-09 17:07:27 --> Hooks Class Initialized
DEBUG - 2020-02-09 17:07:27 --> UTF-8 Support Enabled
INFO - 2020-02-09 17:07:27 --> Utf8 Class Initialized
INFO - 2020-02-09 17:07:27 --> URI Class Initialized
DEBUG - 2020-02-09 17:07:27 --> No URI present. Default controller set.
INFO - 2020-02-09 17:07:27 --> Router Class Initialized
INFO - 2020-02-09 17:07:27 --> Output Class Initialized
INFO - 2020-02-09 17:07:27 --> Security Class Initialized
DEBUG - 2020-02-09 17:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 17:07:27 --> Input Class Initialized
INFO - 2020-02-09 17:07:27 --> Language Class Initialized
INFO - 2020-02-09 17:07:27 --> Loader Class Initialized
INFO - 2020-02-09 17:07:27 --> Helper loaded: url_helper
INFO - 2020-02-09 17:07:27 --> Helper loaded: form_helper
INFO - 2020-02-09 17:07:27 --> Helper loaded: file_helper
INFO - 2020-02-09 17:07:27 --> Database Driver Class Initialized
DEBUG - 2020-02-09 17:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 17:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 17:07:27 --> Form Validation Class Initialized
INFO - 2020-02-09 17:07:27 --> Email Class Initialized
INFO - 2020-02-09 17:07:27 --> Controller Class Initialized
INFO - 2020-02-09 17:07:27 --> Model "Adminmodel" initialized
INFO - 2020-02-09 17:07:27 --> File loaded: C:\xampp\htdocs\Flegigs\application\views\login.php
INFO - 2020-02-09 17:07:27 --> Final output sent to browser
DEBUG - 2020-02-09 17:07:27 --> Total execution time: 0.2455
INFO - 2020-02-09 17:07:42 --> Config Class Initialized
INFO - 2020-02-09 17:07:42 --> Hooks Class Initialized
DEBUG - 2020-02-09 17:07:42 --> UTF-8 Support Enabled
INFO - 2020-02-09 17:07:42 --> Utf8 Class Initialized
INFO - 2020-02-09 17:07:42 --> URI Class Initialized
INFO - 2020-02-09 17:07:42 --> Router Class Initialized
INFO - 2020-02-09 17:07:42 --> Output Class Initialized
INFO - 2020-02-09 17:07:42 --> Security Class Initialized
DEBUG - 2020-02-09 17:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 17:07:42 --> Input Class Initialized
INFO - 2020-02-09 17:07:42 --> Language Class Initialized
INFO - 2020-02-09 17:07:42 --> Loader Class Initialized
INFO - 2020-02-09 17:07:42 --> Helper loaded: url_helper
INFO - 2020-02-09 17:07:42 --> Helper loaded: form_helper
INFO - 2020-02-09 17:07:42 --> Helper loaded: file_helper
INFO - 2020-02-09 17:07:42 --> Database Driver Class Initialized
DEBUG - 2020-02-09 17:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 17:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 17:07:42 --> Form Validation Class Initialized
INFO - 2020-02-09 17:07:42 --> Email Class Initialized
INFO - 2020-02-09 17:07:42 --> Controller Class Initialized
INFO - 2020-02-09 17:07:42 --> Model "Adminmodel" initialized
INFO - 2020-02-09 17:07:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-02-09 17:07:42 --> Config Class Initialized
INFO - 2020-02-09 17:07:42 --> Hooks Class Initialized
DEBUG - 2020-02-09 17:07:42 --> UTF-8 Support Enabled
INFO - 2020-02-09 17:07:42 --> Utf8 Class Initialized
INFO - 2020-02-09 17:07:42 --> URI Class Initialized
INFO - 2020-02-09 17:07:42 --> Router Class Initialized
INFO - 2020-02-09 17:07:42 --> Output Class Initialized
INFO - 2020-02-09 17:07:42 --> Security Class Initialized
DEBUG - 2020-02-09 17:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 17:07:43 --> Input Class Initialized
INFO - 2020-02-09 17:07:43 --> Language Class Initialized
INFO - 2020-02-09 17:07:43 --> Loader Class Initialized
INFO - 2020-02-09 17:07:43 --> Helper loaded: url_helper
INFO - 2020-02-09 17:07:43 --> Helper loaded: form_helper
INFO - 2020-02-09 17:07:43 --> Helper loaded: file_helper
INFO - 2020-02-09 17:07:43 --> Database Driver Class Initialized
DEBUG - 2020-02-09 17:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 17:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 17:07:43 --> Form Validation Class Initialized
INFO - 2020-02-09 17:07:43 --> Email Class Initialized
INFO - 2020-02-09 17:07:43 --> Controller Class Initialized
INFO - 2020-02-09 17:07:43 --> Model "Adminmodel" initialized
INFO - 2020-02-09 17:07:43 --> File loaded: C:\xampp\htdocs\Flegigs\application\views\incl/header.php
INFO - 2020-02-09 17:07:43 --> File loaded: C:\xampp\htdocs\Flegigs\application\views\incl/menu.php
INFO - 2020-02-09 17:07:43 --> File loaded: C:\xampp\htdocs\Flegigs\application\views\menu/user_manage.php
INFO - 2020-02-09 17:07:43 --> File loaded: C:\xampp\htdocs\Flegigs\application\views\incl/footer.php
INFO - 2020-02-09 17:07:43 --> Final output sent to browser
DEBUG - 2020-02-09 17:07:43 --> Total execution time: 0.2666
INFO - 2020-02-09 17:09:47 --> Config Class Initialized
INFO - 2020-02-09 17:09:47 --> Hooks Class Initialized
DEBUG - 2020-02-09 17:09:47 --> UTF-8 Support Enabled
INFO - 2020-02-09 17:09:47 --> Utf8 Class Initialized
INFO - 2020-02-09 17:09:47 --> URI Class Initialized
INFO - 2020-02-09 17:09:47 --> Router Class Initialized
INFO - 2020-02-09 17:09:47 --> Output Class Initialized
INFO - 2020-02-09 17:09:47 --> Security Class Initialized
DEBUG - 2020-02-09 17:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 17:09:47 --> Input Class Initialized
INFO - 2020-02-09 17:09:48 --> Language Class Initialized
INFO - 2020-02-09 17:09:48 --> Loader Class Initialized
INFO - 2020-02-09 17:09:48 --> Helper loaded: url_helper
INFO - 2020-02-09 17:09:48 --> Helper loaded: form_helper
INFO - 2020-02-09 17:09:48 --> Helper loaded: file_helper
INFO - 2020-02-09 17:09:48 --> Database Driver Class Initialized
DEBUG - 2020-02-09 17:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 17:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 17:09:48 --> Form Validation Class Initialized
INFO - 2020-02-09 17:09:48 --> Email Class Initialized
INFO - 2020-02-09 17:09:48 --> Controller Class Initialized
INFO - 2020-02-09 17:09:48 --> Model "Mainpagedata" initialized
DEBUG - 2020-02-09 17:09:48 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMyIsInByb2ZpbGVfaWQiOiIzIiwiZW1haWwiOiJ2aXZlay5tbGluZGlhQGdtYWlsLmNvbSJ9.vqCIzw-9Is74ZpoP6_LnOW-eiN_6MkIEJOvtTBtVaD0","cache-control":"no-cache","Postman-Token":"c08b9149-b49d-40d0-8e33-d4b6ac3e925a","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------734765607094079120161758","content-length":"870","Connection":"keep-alive"}
INFO - 2020-02-09 17:09:48 --> Final output sent to browser
DEBUG - 2020-02-09 17:09:48 --> Total execution time: 0.2848
INFO - 2020-02-09 17:10:12 --> Config Class Initialized
INFO - 2020-02-09 17:10:12 --> Hooks Class Initialized
DEBUG - 2020-02-09 17:10:12 --> UTF-8 Support Enabled
INFO - 2020-02-09 17:10:12 --> Utf8 Class Initialized
INFO - 2020-02-09 17:10:12 --> URI Class Initialized
INFO - 2020-02-09 17:10:12 --> Router Class Initialized
INFO - 2020-02-09 17:10:12 --> Output Class Initialized
INFO - 2020-02-09 17:10:12 --> Security Class Initialized
DEBUG - 2020-02-09 17:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 17:10:12 --> Input Class Initialized
INFO - 2020-02-09 17:10:12 --> Language Class Initialized
INFO - 2020-02-09 17:10:12 --> Loader Class Initialized
INFO - 2020-02-09 17:10:12 --> Helper loaded: url_helper
INFO - 2020-02-09 17:10:12 --> Helper loaded: form_helper
INFO - 2020-02-09 17:10:12 --> Helper loaded: file_helper
INFO - 2020-02-09 17:10:12 --> Database Driver Class Initialized
DEBUG - 2020-02-09 17:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 17:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 17:10:12 --> Form Validation Class Initialized
INFO - 2020-02-09 17:10:12 --> Email Class Initialized
INFO - 2020-02-09 17:10:12 --> Controller Class Initialized
INFO - 2020-02-09 17:10:12 --> Model "Mainpagedata" initialized
DEBUG - 2020-02-09 17:10:12 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMyIsInByb2ZpbGVfaWQiOiIzIiwiZW1haWwiOiJ2aXZlay5tbGluZGlhQGdtYWlsLmNvbSJ9.vqCIzw-9Is74ZpoP6_LnOW-eiN_6MkIEJOvtTBtVaD0","cache-control":"no-cache","Postman-Token":"8a81642e-7161-415c-9da6-0aa642b35146","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=0am8pmluvlsah36tr70m7piou15k3ohg","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------381785414093047757636387","content-length":"870","Connection":"keep-alive"}
INFO - 2020-02-09 17:10:12 --> Final output sent to browser
DEBUG - 2020-02-09 17:10:12 --> Total execution time: 0.2891
INFO - 2020-02-09 17:11:11 --> Config Class Initialized
INFO - 2020-02-09 17:11:11 --> Hooks Class Initialized
DEBUG - 2020-02-09 17:11:11 --> UTF-8 Support Enabled
INFO - 2020-02-09 17:11:11 --> Utf8 Class Initialized
INFO - 2020-02-09 17:11:11 --> URI Class Initialized
INFO - 2020-02-09 17:11:11 --> Router Class Initialized
INFO - 2020-02-09 17:11:11 --> Output Class Initialized
INFO - 2020-02-09 17:11:11 --> Security Class Initialized
DEBUG - 2020-02-09 17:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 17:11:11 --> Input Class Initialized
INFO - 2020-02-09 17:11:11 --> Language Class Initialized
INFO - 2020-02-09 17:11:11 --> Loader Class Initialized
INFO - 2020-02-09 17:11:11 --> Helper loaded: url_helper
INFO - 2020-02-09 17:11:11 --> Helper loaded: form_helper
INFO - 2020-02-09 17:11:11 --> Helper loaded: file_helper
INFO - 2020-02-09 17:11:11 --> Database Driver Class Initialized
DEBUG - 2020-02-09 17:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 17:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 17:11:11 --> Form Validation Class Initialized
INFO - 2020-02-09 17:11:11 --> Email Class Initialized
INFO - 2020-02-09 17:11:11 --> Controller Class Initialized
INFO - 2020-02-09 17:11:11 --> Model "Mainpagedata" initialized
DEBUG - 2020-02-09 17:11:11 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMyIsInByb2ZpbGVfaWQiOiIzIiwiZW1haWwiOiJ2aXZlay5tbGluZGlhQGdtYWlsLmNvbSJ9.vqCIzw-9Is74ZpoP6_LnOW-eiN_6MkIEJOvtTBtVaD0","cache-control":"no-cache","Postman-Token":"66a20b31-479a-465d-9e9c-0dea3c5348d7","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=0am8pmluvlsah36tr70m7piou15k3ohg","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------532965965115433909409159","content-length":"870","Connection":"keep-alive"}
INFO - 2020-02-09 17:11:11 --> Final output sent to browser
DEBUG - 2020-02-09 17:11:11 --> Total execution time: 0.2702
INFO - 2020-02-09 17:21:18 --> Config Class Initialized
INFO - 2020-02-09 17:21:18 --> Hooks Class Initialized
DEBUG - 2020-02-09 17:21:18 --> UTF-8 Support Enabled
INFO - 2020-02-09 17:21:18 --> Utf8 Class Initialized
INFO - 2020-02-09 17:21:18 --> URI Class Initialized
INFO - 2020-02-09 17:21:18 --> Router Class Initialized
INFO - 2020-02-09 17:21:18 --> Output Class Initialized
INFO - 2020-02-09 17:21:18 --> Security Class Initialized
DEBUG - 2020-02-09 17:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 17:21:18 --> Input Class Initialized
INFO - 2020-02-09 17:21:18 --> Language Class Initialized
INFO - 2020-02-09 17:21:18 --> Loader Class Initialized
INFO - 2020-02-09 17:21:18 --> Helper loaded: url_helper
INFO - 2020-02-09 17:21:18 --> Helper loaded: form_helper
INFO - 2020-02-09 17:21:18 --> Helper loaded: file_helper
INFO - 2020-02-09 17:21:18 --> Database Driver Class Initialized
DEBUG - 2020-02-09 17:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 17:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 17:21:18 --> Form Validation Class Initialized
INFO - 2020-02-09 17:21:18 --> Email Class Initialized
INFO - 2020-02-09 17:21:18 --> Controller Class Initialized
INFO - 2020-02-09 17:21:18 --> Model "Mainpagedata" initialized
DEBUG - 2020-02-09 17:21:18 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMyIsInByb2ZpbGVfaWQiOiIzIiwiZW1haWwiOiJ2aXZlay5tbGluZGlhQGdtYWlsLmNvbSJ9.vqCIzw-9Is74ZpoP6_LnOW-eiN_6MkIEJOvtTBtVaD0","cache-control":"no-cache","Postman-Token":"974b90d2-b4b6-45ac-84e6-36872d26f35a","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=0am8pmluvlsah36tr70m7piou15k3ohg","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------121081558963475393759169","content-length":"870","Connection":"keep-alive"}
INFO - 2020-02-09 17:21:18 --> Final output sent to browser
DEBUG - 2020-02-09 17:21:18 --> Total execution time: 0.2589
INFO - 2020-02-09 17:21:27 --> Config Class Initialized
INFO - 2020-02-09 17:21:27 --> Hooks Class Initialized
DEBUG - 2020-02-09 17:21:27 --> UTF-8 Support Enabled
INFO - 2020-02-09 17:21:27 --> Utf8 Class Initialized
INFO - 2020-02-09 17:21:27 --> URI Class Initialized
INFO - 2020-02-09 17:21:27 --> Router Class Initialized
INFO - 2020-02-09 17:21:27 --> Output Class Initialized
INFO - 2020-02-09 17:21:27 --> Security Class Initialized
DEBUG - 2020-02-09 17:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-09 17:21:27 --> Input Class Initialized
INFO - 2020-02-09 17:21:27 --> Language Class Initialized
INFO - 2020-02-09 17:21:27 --> Loader Class Initialized
INFO - 2020-02-09 17:21:27 --> Helper loaded: url_helper
INFO - 2020-02-09 17:21:27 --> Helper loaded: form_helper
INFO - 2020-02-09 17:21:27 --> Helper loaded: file_helper
INFO - 2020-02-09 17:21:27 --> Database Driver Class Initialized
DEBUG - 2020-02-09 17:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-09 17:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-09 17:21:27 --> Form Validation Class Initialized
INFO - 2020-02-09 17:21:27 --> Email Class Initialized
INFO - 2020-02-09 17:21:27 --> Controller Class Initialized
INFO - 2020-02-09 17:21:27 --> Model "Mainpagedata" initialized
DEBUG - 2020-02-09 17:21:27 --> __construct;, {"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMyIsInByb2ZpbGVfaWQiOiIzIiwiZW1haWwiOiJ2aXZlay5tbGluZGlhQGdtYWlsLmNvbSJ9.vqCIzw-9Is74ZpoP6_LnOW-eiN_6MkIEJOvtTBtVaD0","cache-control":"no-cache","Postman-Token":"b9017f68-627c-4757-9619-cdadf9850142","User-Agent":"PostmanRuntime\/7.6.0","Accept":"*\/*","Host":"localhost","cookie":"ci_session=bqnpgr137uh0jkg0n44vh27nhnm9sc51","accept-encoding":"gzip, deflate","content-type":"multipart\/form-data; boundary=--------------------------996033063579814741425100","content-length":"870","Connection":"keep-alive"}
INFO - 2020-02-09 17:21:27 --> Final output sent to browser
DEBUG - 2020-02-09 17:21:27 --> Total execution time: 0.2822
